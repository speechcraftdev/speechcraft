from __future__ import annotations

import unittest

from speaker_ts_eval.buckeye_safecut_benchmark import (
    _build_boundary_safety_by_pipeline_stage,
    _build_reference_safe_regions,
    _build_corrected_safe_regions,
    _phone_clearances_ms,
    _policy_flags,
    _vad_frame_geometry_from_env,
    _weighted_interval_schedule,
)


class BuckeyeSafeCutBenchmarkTests(unittest.TestCase):
    def test_vad_geometry_defaults_to_current_overlap_8ms(self) -> None:
        from unittest.mock import patch

        with patch.dict("os.environ", {}, clear=True):
            backend, window_samples, hop_samples, offsets = _vad_frame_geometry_from_env()
        self.assertEqual(backend, "torch_current")
        self.assertEqual(window_samples, 512)
        self.assertEqual(hop_samples, 256)
        self.assertEqual(offsets, (0, 128))

    def test_vad_geometry_accepts_four_sequential_8ms_override(self) -> None:
        from unittest.mock import patch

        env = {
            "SPEAKER_TS_EVAL_VAD_BACKEND": "silero_official_onnx",
            "SPEAKER_TS_EVAL_VAD_WINDOW_SAMPLES": "512",
            "SPEAKER_TS_EVAL_VAD_HOP_SAMPLES": "512",
            "SPEAKER_TS_EVAL_VAD_OFFSETS": "0,128,256,384",
        }
        with patch.dict("os.environ", env, clear=True):
            backend, window_samples, hop_samples, offsets = _vad_frame_geometry_from_env()
        self.assertEqual(backend, "silero_official_onnx")
        self.assertEqual(window_samples, 512)
        self.assertEqual(hop_samples, 512)
        self.assertEqual(offsets, (0, 128, 256, 384))

    def test_vad_geometry_rejects_offset_at_or_beyond_hop(self) -> None:
        from unittest.mock import patch

        env = {
            "SPEAKER_TS_EVAL_VAD_HOP_SAMPLES": "512",
            "SPEAKER_TS_EVAL_VAD_OFFSETS": "0,512",
        }
        with patch.dict("os.environ", env, clear=True):
            with self.assertRaises(ValueError):
                _vad_frame_geometry_from_env()

    def test_phone_clearances_boundary_touching_is_safe(self) -> None:
        prev_phone = {"start_sec": 0.0, "end_sec": 1.0}
        next_phone = {"start_sec": 1.2, "end_sec": 1.5}
        prev_ms, next_ms, nearest_ms = _phone_clearances_ms(
            1.0,
            overlapping_phone=None,
            prev_phone=prev_phone,
            next_phone=next_phone,
        )
        self.assertEqual(prev_ms, 0.0)
        self.assertAlmostEqual(next_ms, 200.0)
        self.assertEqual(nearest_ms, 0.0)

    def test_phone_clearances_inside_phone_is_unsafe(self) -> None:
        overlapping_phone = {"start_sec": 1.0, "end_sec": 1.4}
        prev_ms, next_ms, nearest_ms = _phone_clearances_ms(
            1.2,
            overlapping_phone=overlapping_phone,
            prev_phone=None,
            next_phone=None,
        )
        self.assertEqual(prev_ms, 0.0)
        self.assertEqual(next_ms, 0.0)
        self.assertLess(nearest_ms, 0.0)

    def test_reference_safe_regions_merge_contiguous_non_speech(self) -> None:
        words = {
            "rec": [
                {"recording_id": "rec", "normalized_label": "hello", "start_sec": "0.0", "end_sec": "0.5", "is_lexical_word": "True"},
                {"recording_id": "rec", "normalized_label": "world", "start_sec": "1.0", "end_sec": "1.5", "is_lexical_word": "True"},
            ]
        }
        phones = {
            "rec": [
                {"speaker_id": "s01", "recording_id": "rec", "raw_label": "hh", "normalized_label": "hh", "start_sec": "0.0", "end_sec": "0.2", "is_speech_phone": "True"},
                {"speaker_id": "s01", "recording_id": "rec", "raw_label": "SIL", "normalized_label": "SIL", "start_sec": "0.2", "end_sec": "0.4", "is_speech_phone": "False"},
                {"speaker_id": "s01", "recording_id": "rec", "raw_label": "SIL", "normalized_label": "SIL", "start_sec": "0.4", "end_sec": "0.6", "is_speech_phone": "False"},
                {"speaker_id": "s01", "recording_id": "rec", "raw_label": "w", "normalized_label": "w", "start_sec": "0.6", "end_sec": "1.0", "is_speech_phone": "True"},
            ]
        }
        regions = _build_reference_safe_regions(words, phones)
        self.assertEqual(len(regions), 1)
        self.assertAlmostEqual(float(regions[0]["start_sec"]), 0.2)
        self.assertAlmostEqual(float(regions[0]["end_sec"]), 0.6)

    def test_interviewer_speech_never_safe_under_any_policy(self) -> None:
        flags = _policy_flags("interviewer_speech")
        self.assertFalse(flags["strict"])
        self.assertFalse(flags["moderate"])
        self.assertFalse(flags["permissive"])

    def test_laughter_noise_uncertain_not_safe_under_strict_or_moderate(self) -> None:
        for region_type in ("laughter", "noise", "uncertain", "boundary_marker"):
            flags = _policy_flags(region_type)
            self.assertFalse(flags["strict"])
            self.assertFalse(flags["moderate"])

    def test_unused_accepted_cutpoints_not_counted_as_final_boundaries(self) -> None:
        current_eval_rows = [
            {
                "cutpoint_id": "c1",
                "inside_reference_word": False,
                "inside_reference_phone": False,
                "unsafe_at_20ms_guard": False,
                "unsafe_at_50ms_guard": False,
                "unsafe_at_100ms_guard": False,
            },
            {
                "cutpoint_id": "c2",
                "inside_reference_word": True,
                "inside_reference_phone": True,
                "unsafe_at_20ms_guard": True,
                "unsafe_at_50ms_guard": True,
                "unsafe_at_100ms_guard": True,
            },
        ]
        candidate_review_manifest = [
            {"start_cutpoint_ref": "c1", "end_cutpoint_ref": "c1"},
        ]
        rows = _build_boundary_safety_by_pipeline_stage(
            current_eval_rows=current_eval_rows,
            current_phone_overlap_rows=[],
            candidate_review_manifest=candidate_review_manifest,
        )
        final_row = next(row for row in rows if row["stage"] == "final_emitted_clip_boundaries")
        self.assertEqual(final_row["boundary_count"], 0)
        selected_row = next(row for row in rows if row["stage"] == "selected_candidate_boundaries")
        self.assertEqual(selected_row["boundary_count"], 2)

    def test_weighted_interval_schedule_uses_numeric_time(self) -> None:
        candidates = [
            {"start_sec": 0.0, "end_sec": 3.0, "weight": 3.0},
            {"start_sec": 3.0, "end_sec": 8.0, "weight": 5.0},
            {"start_sec": 0.0, "end_sec": 8.0, "weight": 7.0},
        ]
        selected = _weighted_interval_schedule(candidates)
        self.assertEqual(len(selected), 2)
        self.assertEqual(selected[0]["start_sec"], 0.0)
        self.assertEqual(selected[0]["end_sec"], 3.0)
        self.assertEqual(selected[1]["start_sec"], 3.0)
        self.assertEqual(selected[1]["end_sec"], 8.0)


if __name__ == "__main__":
    unittest.main()
