from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from speaker_ts_eval.buckeye_safecut_benchmark import (
    SourceInfo,
    _build_corrected_safe_regions,
    _build_reference_safe_regions,
)
from speaker_ts_eval.slicer_daddy_test import (
    AcousticDetector,
    AcousticDetectorContext,
    BenchmarkContexts,
    DetectorContext,
    DetectorRunResult,
    Clip,
    Cutpoint,
    CurrentProductionDetector,
    GreedyPacker,
    LinguisticDetectorContext,
    OptimalWeightedIntervalPacker,
    PackingConstraints,
    BenchmarkConfig,
    LocalProminenceRmsDetector,
    PercentileRmsDetector,
    AdaptiveLocalRmsDetector,
    VadLocalMinimaDetector,
    VadPercentileRmsDetector,
    WordGapAcousticHybridDetector,
    _boundary_safety_rows,
    _build_detector_scorecard,
    _build_pareto_frontier,
    _candidate_clip_weight,
    _generate_legal_candidate_clips,
    _compute_coverage_metrics,
    _dedupe_cutpoints,
    _duplication_metrics,
    _legacy_rms_threshold,
    _local_prominence_frames,
    _percentile_rms_threshold,
    _read_stage_durations_from_log,
    _safe_region_recall_rows,
)


class LegacyVadPercentileRmsDetector(AcousticDetector):
    name = "vad_percentile_rms"
    use_vad = True
    use_rms = True
    rms_mode = "percentile"


class SlicerDaddyTestTests(unittest.TestCase):
    def setUp(self) -> None:
        self.constraints = PackingConstraints(
            min_clip_sec=3.0,
            preferred_min_sec=6.0,
            preferred_max_sec=8.0,
            target_clip_sec=8.0,
            max_clip_sec=15.0,
            allow_overlap=False,
            max_overlap_sec=0.0,
            max_duplication_ratio=1.0,
            eligible_regions_by_recording={"rec": ((0.0, 100.0),)},
        )

    def _make_detector_contexts(
        self,
        *,
        words_by_buffer: dict[str, list[dict[str, str]]] | None = None,
        qc_by_buffer: dict[str, dict[str, object]] | None = None,
        buffer_by_id: dict[str, dict[str, object]] | None = None,
        audio_feature_cache: dict[str, dict[str, object]] | None = None,
        config: BenchmarkConfig | None = None,
    ) -> BenchmarkContexts:
        with tempfile.TemporaryDirectory() as tmpdir:
            pass
        benchmark_root = Path(tempfile.mkdtemp())
        source = SourceInfo("src", "rec", Path("/tmp/fake.wav"), 5.0, 16000, 80000)
        default_buffer = {
            "buffer_id": "buf",
            "source_audio_id": "src",
            "source_start_sec": 0.0,
            "source_end_sec": 1.0,
            "trusted_start_sec": 0.0,
            "trusted_end_sec": 1.0,
        }
        buffer_rows = {"buf": default_buffer} if buffer_by_id is None else buffer_by_id
        benchmark_config = BenchmarkConfig() if config is None else config
        feature_cache = (
            {
                "rec": {
                    "frames": [
                        {"window_start_sec": 0.00, "window_end_sec": 0.05, "center_sec": 0.025, "speech_prob": 0.05, "rms_dbfs": -50.0, "voicing_score": 0.4},
                        {"window_start_sec": 0.05, "window_end_sec": 0.10, "center_sec": 0.075, "speech_prob": 0.5, "rms_dbfs": -40.0, "voicing_score": 0.7},
                        {"window_start_sec": 0.15, "window_end_sec": 0.20, "center_sec": 0.175, "speech_prob": 0.04, "rms_dbfs": -48.0, "voicing_score": 0.35},
                        {"window_start_sec": 0.20, "window_end_sec": 0.25, "center_sec": 0.225, "speech_prob": 0.5, "rms_dbfs": -39.0, "voicing_score": 0.7},
                    ],
                    "centers": [0.025, 0.075, 0.175, 0.225],
                }
            }
            if audio_feature_cache is None
            else audio_feature_cache
        )
        shared = DetectorContext(
            eval_run=benchmark_root,
            normalized_speaker_dir=benchmark_root,
            benchmark_root=benchmark_root,
            config=benchmark_config,
            sources={"src": source},
            buffer_by_id=buffer_rows,
            lexical_words_by_recording={"rec": []},
            speech_phones_by_recording={"rec": []},
            corrected_safe_regions=[],
            reference_words=[],
            reference_phones=[],
        )
        acoustic = AcousticDetectorContext(
            benchmark_root=benchmark_root,
            config=benchmark_config,
            sources={"src": source},
            buffer_by_id=buffer_rows,
            audio_feature_cache=feature_cache,
            profiler={},
        )
        linguistic = LinguisticDetectorContext(
            benchmark_root=benchmark_root,
            config=benchmark_config,
            speechcraft_config={"cutpoint_left_word_edge_guard_ms": 30, "cutpoint_right_word_edge_guard_ms": 30},
            sources={"src": source},
            buffer_by_id=buffer_rows,
            queue_by_id={},
            qc_by_buffer={} if qc_by_buffer is None else qc_by_buffer,
            words_by_buffer={} if words_by_buffer is None else words_by_buffer,
            current_cuts_by_buffer={},
            candidate_review_manifest=[],
            audio_feature_cache=feature_cache,
            stage_durations_sec={},
            profiler={},
        )
        return BenchmarkContexts(shared=shared, acoustic=acoustic, linguistic=linguistic)

    def _make_vad_percentile_contexts(
        self,
        *,
        frames_by_recording: dict[str, list[tuple[float, float, float, float, float]]],
        buffers: dict[str, tuple[str, float, float]],
        config: BenchmarkConfig | None = None,
    ) -> BenchmarkContexts:
        benchmark_root = Path(tempfile.mkdtemp())
        sources = {
            f"src_{recording_id}": SourceInfo(
                f"src_{recording_id}",
                recording_id,
                Path(f"/tmp/{recording_id}.wav"),
                max((end for _, end, _, _, _ in frames), default=0.0),
                16000,
                int(max((end for _, end, _, _, _ in frames), default=0.0) * 16000),
            )
            for recording_id, frames in frames_by_recording.items()
        }
        buffer_rows = {
            buffer_id: {
                "buffer_id": buffer_id,
                "source_audio_id": f"src_{recording_id}",
                "source_start_sec": start,
                "source_end_sec": end,
                "trusted_start_sec": start,
                "trusted_end_sec": end,
            }
            for buffer_id, (recording_id, start, end) in buffers.items()
        }
        feature_cache = {}
        for recording_id, rows in frames_by_recording.items():
            frame_rows = [
                {
                    "window_start_sec": start,
                    "window_end_sec": end,
                    "center_sec": round((start + end) / 2.0, 6),
                    "speech_prob": speech_prob,
                    "rms_dbfs": rms_dbfs,
                    "voicing_score": voicing_score,
                    "offset_samples": 0,
                }
                for start, end, speech_prob, rms_dbfs, voicing_score in rows
            ]
            feature_cache[recording_id] = {
                "frames": frame_rows,
                "centers": [row["center_sec"] for row in frame_rows],
            }
        benchmark_config = config or BenchmarkConfig(vad_min_run_ms=1.0)
        shared = DetectorContext(
            eval_run=benchmark_root,
            normalized_speaker_dir=benchmark_root,
            benchmark_root=benchmark_root,
            config=benchmark_config,
            sources=sources,
            buffer_by_id=buffer_rows,
            lexical_words_by_recording={recording_id: [] for recording_id in frames_by_recording},
            speech_phones_by_recording={recording_id: [] for recording_id in frames_by_recording},
            corrected_safe_regions=[],
            reference_words=[],
            reference_phones=[],
        )
        acoustic = AcousticDetectorContext(
            benchmark_root=benchmark_root,
            config=benchmark_config,
            sources=sources,
            buffer_by_id=buffer_rows,
            audio_feature_cache=feature_cache,
            profiler={},
        )
        linguistic = LinguisticDetectorContext(
            benchmark_root=benchmark_root,
            config=benchmark_config,
            speechcraft_config={},
            sources=sources,
            buffer_by_id=buffer_rows,
            queue_by_id={},
            qc_by_buffer={},
            words_by_buffer={},
            current_cuts_by_buffer={},
            candidate_review_manifest=[],
            audio_feature_cache=feature_cache,
            stage_durations_sec={},
            profiler={},
        )
        return BenchmarkContexts(shared=shared, acoustic=acoustic, linguistic=linguistic)

    def _assert_vad_percentile_equivalent(
        self,
        *,
        frames_by_recording: dict[str, list[tuple[float, float, float, float, float]]],
        buffers: dict[str, tuple[str, float, float]],
        config: BenchmarkConfig | None = None,
    ) -> None:
        legacy_contexts = self._make_vad_percentile_contexts(frames_by_recording=frames_by_recording, buffers=buffers, config=config)
        optimized_contexts = self._make_vad_percentile_contexts(frames_by_recording=frames_by_recording, buffers=buffers, config=config)
        legacy_cuts = LegacyVadPercentileRmsDetector().find_cutpoints(legacy_contexts).cutpoints
        optimized_cuts = VadPercentileRmsDetector().find_cutpoints(optimized_contexts).cutpoints
        self.assertEqual([self._cutpoint_signature(cut) for cut in legacy_cuts], [self._cutpoint_signature(cut) for cut in optimized_cuts])
        eligible = {}
        for _, (recording_id, start, end) in buffers.items():
            eligible.setdefault(recording_id, []).append((start, end))
        constraints = PackingConstraints(
            min_clip_sec=0.05,
            preferred_min_sec=0.05,
            preferred_max_sec=1.0,
            target_clip_sec=0.5,
            max_clip_sec=20.0,
            allow_overlap=False,
            max_overlap_sec=0.0,
            max_duplication_ratio=1.0,
            eligible_regions_by_recording={recording_id: tuple(regions) for recording_id, regions in eligible.items()},
        )
        packer = OptimalWeightedIntervalPacker()
        legacy_clips = packer.pack(duration_sec=20.0, cutpoints=legacy_cuts, constraints=constraints)
        optimized_clips = packer.pack(duration_sec=20.0, cutpoints=optimized_cuts, constraints=constraints)
        self.assertEqual([self._clip_signature(clip) for clip in legacy_clips], [self._clip_signature(clip) for clip in optimized_clips])

    def _cutpoint_signature(self, cut: Cutpoint) -> tuple[object, ...]:
        return (
            cut.detector_name,
            cut.source_id,
            cut.recording_id,
            cut.buffer_id,
            cut.cutpoint_id,
            cut.time_sec,
            cut.interval_start_sec,
            cut.interval_end_sec,
            cut.score,
            cut.vad_min,
            cut.vad_mean,
            cut.vad_longest_below_0_1_ms,
            cut.vad_longest_below_0_2_ms,
            cut.rms_min_dbfs,
            cut.rms_mean_dbfs,
            cut.voicing_min,
            cut.voicing_mean,
            cut.is_buffer_edge_candidate,
            cut.metadata,
        )

    def _clip_signature(self, clip: Clip) -> tuple[object, ...]:
        return (
            clip.detector_name,
            clip.packer_name,
            clip.source_id,
            clip.recording_id,
            clip.buffer_id,
            clip.clip_id,
            clip.start_sec,
            clip.end_sec,
            clip.duration_sec,
            clip.start_cutpoint_id,
            clip.end_cutpoint_id,
            clip.selected_weight,
            clip.selected_boundary_count,
        )

    def test_vad_percentile_optimized_matches_legacy_full_file_buffer(self) -> None:
        frames = [
            (0.00, 0.08, 0.04, -54.0, 0.2),
            (0.08, 0.16, 0.50, -35.0, 0.8),
            (0.80, 0.88, 0.03, -55.0, 0.2),
            (0.88, 0.96, 0.04, -56.0, 0.2),
            (4.00, 4.08, 0.02, -60.0, 0.1),
            (4.08, 4.16, 0.60, -30.0, 0.9),
        ]
        self._assert_vad_percentile_equivalent(
            frames_by_recording={"rec": frames},
            buffers={"buf": ("rec", 0.0, 5.0)},
        )

    def test_vad_percentile_optimized_matches_legacy_multiple_buffers_same_recording(self) -> None:
        frames = [
            (0.00, 0.08, 0.04, -54.0, 0.2),
            (1.00, 1.08, 0.03, -55.0, 0.2),
            (5.00, 5.08, 0.04, -56.0, 0.2),
            (6.00, 6.08, 0.03, -57.0, 0.2),
        ]
        self._assert_vad_percentile_equivalent(
            frames_by_recording={"rec": frames},
            buffers={"buf_a": ("rec", 0.0, 2.0), "buf_b": ("rec", 5.0, 7.0)},
        )

    def test_vad_percentile_optimized_matches_legacy_multiple_recordings(self) -> None:
        self._assert_vad_percentile_equivalent(
            frames_by_recording={
                "rec_a": [(0.00, 0.08, 0.04, -54.0, 0.2), (1.00, 1.08, 0.03, -55.0, 0.2)],
                "rec_b": [(0.00, 0.08, 0.02, -60.0, 0.1), (1.00, 1.08, 0.04, -58.0, 0.2)],
            },
            buffers={"buf_a": ("rec_a", 0.0, 2.0), "buf_b": ("rec_b", 0.0, 2.0)},
        )

    def test_vad_percentile_optimized_matches_legacy_adjacent_buffers(self) -> None:
        frames = [
            (0.90, 0.98, 0.04, -54.0, 0.2),
            (1.00, 1.08, 0.03, -55.0, 0.2),
            (1.08, 1.16, 0.04, -56.0, 0.2),
        ]
        self._assert_vad_percentile_equivalent(
            frames_by_recording={"rec": frames},
            buffers={"buf_a": ("rec", 0.0, 1.0), "buf_b": ("rec", 1.0, 2.0)},
        )

    def test_vad_percentile_optimized_matches_legacy_empty_and_no_candidate_buffers(self) -> None:
        self._assert_vad_percentile_equivalent(
            frames_by_recording={"rec": [(0.00, 0.08, 0.80, -20.0, 0.9), (0.10, 0.18, 0.90, -19.0, 0.9)]},
            buffers={"empty": ("rec", 5.0, 6.0), "no_candidate": ("rec", 0.0, 1.0)},
        )

    def test_vad_percentile_optimized_matches_legacy_single_accepted_frame(self) -> None:
        self._assert_vad_percentile_equivalent(
            frames_by_recording={"rec": [(0.00, 0.08, 0.04, -54.0, 0.2)]},
            buffers={"buf": ("rec", 0.0, 1.0)},
        )

    def test_vad_percentile_optimized_matches_legacy_equal_probability_and_rms_tie(self) -> None:
        self._assert_vad_percentile_equivalent(
            frames_by_recording={
                "rec": [
                    (0.00, 0.08, 0.04, -54.0, 0.2),
                    (0.08, 0.16, 0.04, -54.0, 0.2),
                    (0.16, 0.24, 0.04, -54.0, 0.2),
                ]
            },
            buffers={"buf": ("rec", 0.0, 1.0)},
        )

    def test_union_coverage_does_not_double_count_overlap(self) -> None:
        clips = [
            Clip("det", "greedy", "src", "rec", "buf", "c1", 0.0, 5.0, 5.0, "a", "b", 1.0, 2),
            Clip("det", "greedy", "src", "rec", "buf", "c2", 4.0, 8.0, 4.0, "b", "c", 1.0, 2),
        ]
        lexical = {"rec": [{"start_sec": "0.0", "end_sec": "10.0"}]}
        phones = {"rec": [{"start_sec": "0.0", "end_sec": "10.0"}]}
        sources = {
            "src": SourceInfo("src", "rec", Path("/tmp/fake.wav"), 10.0, 16000, 160000),
        }
        row = _compute_coverage_metrics(
            detector_name="det",
            packer_name="greedy",
            clips=clips,
            lexical_words_by_recording=lexical,
            speech_phones_by_recording=phones,
            sources=sources,
        )[0]
        self.assertAlmostEqual(row["raw_timeline_union_coverage"], 0.8)
        self.assertAlmostEqual(row["emitted_duration_ratio"], 0.9)

    def test_reference_speech_coverage_counts_each_interval_once(self) -> None:
        clips = [
            Clip("det", "optimal", "src", "rec", "buf", "c1", 0.0, 5.0, 5.0, "a", "b", 1.0, 2),
            Clip("det", "optimal", "src", "rec", "buf", "c2", 4.0, 8.0, 4.0, "b", "c", 1.0, 2),
        ]
        lexical = {"rec": [{"start_sec": "1.0", "end_sec": "7.0"}]}
        phones = {"rec": [{"start_sec": "1.0", "end_sec": "7.0"}]}
        sources = {
            "src": SourceInfo("src", "rec", Path("/tmp/fake.wav"), 10.0, 16000, 160000),
        }
        row = _compute_coverage_metrics(
            detector_name="det",
            packer_name="optimal",
            clips=clips,
            lexical_words_by_recording=lexical,
            speech_phones_by_recording=phones,
            sources=sources,
        )[0]
        self.assertAlmostEqual(row["reference_lexical_word_coverage"], 1.0)
        self.assertAlmostEqual(row["repeated_reference_lexical_word_speech_sec"], 1.0)

    def test_exact_boundary_touching_is_safe(self) -> None:
        cut = Cutpoint("det", "src", "rec", "buf", "cut1", 1.0, 0.8, 1.2, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {})
        rows, _ = _boundary_safety_rows(
            detector_name="det",
            packer_name="greedy",
            cutpoints=[cut],
            clips=[],
            lexical_words_by_recording={"rec": []},
            speech_phones_by_recording={"rec": [{"normalized_label": "aa", "start_sec": "0.5", "end_sec": "1.0"}]},
        )
        proposed = next(row for row in rows if row["stage"] == "proposed_cutpoints")
        self.assertFalse(proposed["inside_reference_phone"])

    def test_positive_duration_overlap_is_unsafe(self) -> None:
        cut = Cutpoint("det", "src", "rec", "buf", "cut1", 0.75, 0.7, 0.8, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {})
        rows, _ = _boundary_safety_rows(
            detector_name="det",
            packer_name="greedy",
            cutpoints=[cut],
            clips=[],
            lexical_words_by_recording={"rec": []},
            speech_phones_by_recording={"rec": [{"normalized_label": "aa", "start_sec": "0.5", "end_sec": "1.0"}]},
        )
        proposed = next(row for row in rows if row["stage"] == "proposed_cutpoints")
        self.assertTrue(proposed["inside_reference_phone"])

    def test_start_and_end_boundary_severity_directionality(self) -> None:
        cuts = [
            Cutpoint("det", "src", "rec", "buf", "s", 0.25, 0.2, 0.3, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf", "e", 0.75, 0.7, 0.8, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
        ]
        clips = [Clip("det", "greedy", "src", "rec", "buf", "clip", 0.25, 0.75, 0.5, "s", "e", 1.0, 2)]
        word = {"normalized_label": "hello", "start_sec": "0.0", "end_sec": "1.0"}
        rows, _ = _boundary_safety_rows(
            detector_name="det",
            packer_name="greedy",
            cutpoints=cuts,
            clips=clips,
            lexical_words_by_recording={"rec": [word]},
            speech_phones_by_recording={"rec": []},
        )
        start_row = next(row for row in rows if row["boundary_side"] == "clip_start")
        end_row = next(row for row in rows if row["boundary_side"] == "clip_end")
        self.assertAlmostEqual(start_row["discarded_word_fraction"], 0.25)
        self.assertAlmostEqual(start_row["preserved_word_fraction"], 0.75)
        self.assertAlmostEqual(end_row["discarded_word_fraction"], 0.25)
        self.assertAlmostEqual(end_row["preserved_word_fraction"], 0.75)

    def test_contiguous_safe_regions_counted_once(self) -> None:
        words = {"rec": [{"recording_id": "rec", "normalized_label": "hi", "start_sec": "0.0", "end_sec": "0.2", "is_lexical_word": "True"}]}
        phones = {"rec": [
            {"speaker_id": "s01", "recording_id": "rec", "raw_label": "hh", "normalized_label": "hh", "start_sec": "0.0", "end_sec": "0.1", "is_speech_phone": "True"},
            {"speaker_id": "s01", "recording_id": "rec", "raw_label": "SIL", "normalized_label": "SIL", "start_sec": "0.1", "end_sec": "0.3", "is_speech_phone": "False"},
            {"speaker_id": "s01", "recording_id": "rec", "raw_label": "SIL", "normalized_label": "SIL", "start_sec": "0.3", "end_sec": "0.5", "is_speech_phone": "False"},
        ]}
        safe_regions = _build_corrected_safe_regions(_build_reference_safe_regions(words, phones))
        cuts = [
            Cutpoint("det", "src", "rec", "buf", "c1", 0.2, 0.19, 0.21, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf", "c2", 0.4, 0.39, 0.41, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
        ]
        buffer_by_id = {
            "buf": {
                "buffer_id": "buf",
                "source_audio_id": "src",
                "source_start_sec": 0.0,
                "source_end_sec": 1.0,
                "trusted_start_sec": 0.0,
                "trusted_end_sec": 1.0,
            }
        }
        sources = {"src": SourceInfo("src", "rec", Path("/tmp/fake.wav"), 1.0, 16000, 16000)}
        rows = _safe_region_recall_rows(
            detector_name="det",
            cutpoints=cuts,
            corrected_safe_regions=safe_regions,
            operational_buffers={"buf"},
            buffer_by_id=buffer_by_id,
            sources=sources,
            min_region_ms_values=(20,),
        )
        self.assertEqual(rows[0]["eligible_safe_region_count"], 1)
        self.assertEqual(rows[0]["detected_safe_region_count"], 1)

    def test_identical_candidates_receive_identical_packing_treatment(self) -> None:
        cuts = [
            Cutpoint("det", "src", "rec", "buf", "a", 0.0, 0.0, 0.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf", "b", 4.0, 3.9, 4.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf", "c", 8.0, 7.9, 8.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
        ]
        greedy = GreedyPacker().pack(duration_sec=10.0, cutpoints=cuts, constraints=self.constraints)
        optimal = OptimalWeightedIntervalPacker().pack(duration_sec=10.0, cutpoints=cuts, constraints=self.constraints)
        self.assertEqual([(c.start_sec, c.end_sec) for c in greedy], [(0.0, 8.0)])
        self.assertEqual([(c.start_sec, c.end_sec) for c in optimal], [(0.0, 8.0)])

    def test_optimal_selected_clips_do_not_overlap(self) -> None:
        cuts = [
            Cutpoint("det", "src", "rec", "buf", "a", 0.0, 0.0, 0.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf", "b", 3.0, 2.9, 3.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf", "c", 5.0, 4.9, 5.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf", "d", 8.0, 7.9, 8.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
        ]
        clips = OptimalWeightedIntervalPacker().pack(duration_sec=10.0, cutpoints=cuts, constraints=self.constraints)
        self.assertTrue(all(left.end_sec <= right.start_sec for left, right in zip(clips, clips[1:])))

    def test_global_non_overlap_across_overlapping_buffers(self) -> None:
        cuts = [
            Cutpoint("det", "src", "rec", "buf_a", "a0", 0.0, 0.0, 0.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf_a", "a1", 4.0, 3.9, 4.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf_a", "a2", 8.0, 7.9, 8.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf_b", "b0", 3.0, 2.9, 3.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf_b", "b1", 7.0, 6.9, 7.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf_b", "b2", 11.0, 10.9, 11.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
        ]
        candidates, _ = _generate_legal_candidate_clips(cutpoints=cuts, constraints=self.constraints)
        self.assertGreaterEqual(len(candidates), 4)
        clips = OptimalWeightedIntervalPacker().pack(duration_sec=12.0, cutpoints=cuts, constraints=self.constraints)
        self.assertTrue(all(left.end_sec <= right.start_sec for left, right in zip(clips, clips[1:])))
        self.assertLessEqual(len([clip for clip in clips if clip.start_sec < 8.0]), 1)

    def test_duplicate_candidate_intervals_from_overlapping_buffers_are_deduplicated(self) -> None:
        cuts = [
            Cutpoint("det", "src", "rec", "buf_a", "a0", 0.0, 0.0, 0.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf_a", "a1", 4.0, 3.9, 4.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf_b", "b0", 0.0, 0.0, 0.1, 0.8, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf_b", "b1", 4.0, 3.9, 4.1, 0.8, None, None, None, None, None, None, None, None, 0.0, False, {}),
        ]
        candidates, deduped = _generate_legal_candidate_clips(cutpoints=cuts, constraints=self.constraints)
        self.assertEqual(len(candidates), 1)
        self.assertEqual(deduped, 3)
        self.assertEqual(candidates[0].buffer_id, "buf_a|buf_a")

    def test_candidate_generation_does_not_bridge_untrusted_gap(self) -> None:
        constraints = PackingConstraints(
            min_clip_sec=3.0,
            preferred_min_sec=6.0,
            preferred_max_sec=8.0,
            target_clip_sec=8.0,
            max_clip_sec=15.0,
            allow_overlap=False,
            max_overlap_sec=0.0,
            max_duplication_ratio=1.0,
            eligible_regions_by_recording={"rec": ((10.0, 14.0), (17.0, 22.0))},
        )
        cuts = [
            Cutpoint("det", "src", "rec", "buf_a", "a", 13.0, 12.9, 13.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf_b", "b", 20.0, 19.9, 20.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
        ]
        candidates, _ = _generate_legal_candidate_clips(cutpoints=cuts, constraints=constraints)
        self.assertEqual(candidates, [])

    def test_candidate_generation_fails_closed_without_eligible_regions(self) -> None:
        constraints = PackingConstraints(
            min_clip_sec=3.0,
            preferred_min_sec=6.0,
            preferred_max_sec=8.0,
            target_clip_sec=8.0,
            max_clip_sec=15.0,
            allow_overlap=False,
            max_overlap_sec=0.0,
            max_duplication_ratio=1.0,
        )
        cuts = [
            Cutpoint("det", "src", "rec", "buf", "a", 0.0, 0.0, 0.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf", "b", 8.0, 7.9, 8.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
        ]
        with self.assertRaises(ValueError):
            _generate_legal_candidate_clips(cutpoints=cuts, constraints=constraints)

    def test_candidate_generation_pairs_across_merged_overlapping_buffers(self) -> None:
        constraints = PackingConstraints(
            min_clip_sec=3.0,
            preferred_min_sec=6.0,
            preferred_max_sec=8.0,
            target_clip_sec=8.0,
            max_clip_sec=15.0,
            allow_overlap=False,
            max_overlap_sec=0.0,
            max_duplication_ratio=1.0,
            eligible_regions_by_recording={"rec": ((10.0, 22.0),)},
        )
        cuts = [
            Cutpoint("det", "src", "rec", "buf_a", "a", 13.0, 12.9, 13.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf_b", "b", 20.0, 19.9, 20.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
        ]
        candidates, _ = _generate_legal_candidate_clips(cutpoints=cuts, constraints=constraints)
        self.assertEqual([(row.start_sec, row.end_sec) for row in candidates], [(13.0, 20.0)])

    def test_common_candidate_weight_ignores_raw_detector_score(self) -> None:
        low_score = Cutpoint("det", "src", "rec", "buf", "low", 0.0, 0.0, 0.1, 0.1, None, None, None, None, None, None, None, None, 0.0, False, {})
        high_score = Cutpoint("det", "src", "rec", "buf", "high", 8.0, 7.9, 8.1, 100.0, None, None, None, None, None, None, None, None, 0.0, False, {})
        self.assertEqual(
            _candidate_clip_weight(duration_sec=8.0, constraints=self.constraints),
            _candidate_clip_weight(duration_sec=8.0, constraints=self.constraints),
        )
        self.assertNotEqual(low_score.score, high_score.score)

    def test_duration_weight_ordering_is_explicit(self) -> None:
        weights = {
            duration: _candidate_clip_weight(duration_sec=duration, constraints=self.constraints)
            for duration in (3.0, 6.0, 7.0, 8.0, 9.0, 10.0, 15.0)
        }
        self.assertGreater(weights[8.0], weights[7.0])
        self.assertGreater(weights[7.0], weights[6.0])
        self.assertGreater(weights[6.0], weights[9.0])
        self.assertGreater(weights[9.0], weights[10.0])
        self.assertGreater(weights[10.0], weights[15.0])
        self.assertGreater(weights[6.0], weights[3.0])

    def test_global_schedule_is_invariant_to_buffer_iteration_order(self) -> None:
        cuts_a = [
            Cutpoint("det", "src", "rec", "buf_a", "a0", 0.0, 0.0, 0.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf_a", "a1", 4.0, 3.9, 4.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf_b", "b0", 4.0, 3.9, 4.1, 0.9, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf_b", "b1", 8.0, 7.9, 8.1, 0.9, None, None, None, None, None, None, None, None, 0.0, False, {}),
        ]
        cuts_b = list(reversed(cuts_a))
        clips_a = GreedyPacker().pack(duration_sec=10.0, cutpoints=cuts_a, constraints=self.constraints)
        clips_b = GreedyPacker().pack(duration_sec=10.0, cutpoints=cuts_b, constraints=self.constraints)
        self.assertEqual([(clip.start_sec, clip.end_sec) for clip in clips_a], [(clip.start_sec, clip.end_sec) for clip in clips_b])

    def test_duplicate_ratio_is_numerically_correct(self) -> None:
        clips = [
            Clip("det", "greedy", "src", "rec", "buf", "c1", 0.0, 4.0, 4.0, "a", "b", 1.0, 2),
            Clip("det", "greedy", "src", "rec", "buf", "c2", 2.0, 6.0, 4.0, "b", "c", 1.0, 2),
        ]
        row = _duplication_metrics(detector_name="det", packer_name="greedy", clips=clips)
        self.assertAlmostEqual(row["duplication_ratio"], 8.0 / 6.0, places=6)

    def test_stage_level_boundary_counts_reconcile(self) -> None:
        cuts = [
            Cutpoint("det", "src", "rec", "buf", "a", 0.0, 0.0, 0.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf", "b", 4.0, 3.9, 4.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf", "c", 8.0, 7.9, 8.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
        ]
        clips = [
            Clip("det", "greedy", "src", "rec", "buf", "clip1", 0.0, 4.0, 4.0, "a", "b", 1.0, 2),
            Clip("det", "greedy", "src", "rec", "buf", "clip2", 4.0, 8.0, 4.0, "b", "c", 1.0, 2),
        ]
        rows, severity = _boundary_safety_rows(
            detector_name="det",
            packer_name="greedy",
            cutpoints=cuts,
            clips=clips,
            lexical_words_by_recording={"rec": []},
            speech_phones_by_recording={"rec": []},
        )
        final_all = next(row for row in severity if row["stage"] == "final_emitted_boundaries" and row["boundary_side"] == "all")
        selected_all = next(row for row in severity if row["stage"] == "selected_cutpoints" and row["boundary_side"] == "all")
        self.assertEqual(final_all["boundary_count"], 4)
        self.assertEqual(selected_all["boundary_count"], 3)
        self.assertEqual(sum(row["stage"] == "final_emitted_boundaries" for row in rows), 4)

    def test_stage_duration_log_parser(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            log_path = Path(tmpdir) / "dataset_worker.log"
            log_path.write_text(
                "\n".join(
                    [
                        "2026-07-14T11:46:46.700250+00:00 source_audio completed summary={}",
                        "2026-07-14T11:46:47.700250+00:00 vad completed summary={}",
                        "2026-07-14T11:46:49.200250+00:00 asr completed summary={}",
                    ]
                )
            )
            rows = _read_stage_durations_from_log(log_path)
            self.assertAlmostEqual(rows["vad"], 1.0)
            self.assertAlmostEqual(rows["asr"], 1.5)

    def test_deduped_cutpoints_are_deterministic(self) -> None:
        cuts = [
            Cutpoint("det", "src", "rec", "buf", "b", 1.0001, 1.0, 1.1, 0.2, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf", "a", 1.0000, 0.9, 1.1, 0.1, None, None, None, None, None, None, None, None, 0.0, False, {}),
        ]
        deduped = _dedupe_cutpoints(cuts)
        self.assertEqual(len(deduped), 1)
        self.assertEqual(deduped[0].cutpoint_id, "b")
        self.assertEqual(deduped[0].metadata["support_count"], 2)
        self.assertEqual(deduped[0].metadata["contributing_cutpoint_ids"], ["a", "b"])

    def test_detectors_with_different_candidate_spaces_do_not_silently_collapse(self) -> None:
        contexts = self._make_detector_contexts(
            audio_feature_cache={
                "rec": {
                    "frames": [
                        {"window_start_sec": 0.00, "window_end_sec": 0.05, "center_sec": 0.025, "speech_prob": 0.6, "rms_dbfs": -30.0, "voicing_score": 0.8},
                        {"window_start_sec": 0.10, "window_end_sec": 0.15, "center_sec": 0.125, "speech_prob": 0.05, "rms_dbfs": -50.0, "voicing_score": 0.4},
                        {"window_start_sec": 0.15, "window_end_sec": 0.20, "center_sec": 0.175, "speech_prob": 0.04, "rms_dbfs": -49.0, "voicing_score": 0.35},
                        {"window_start_sec": 0.30, "window_end_sec": 0.35, "center_sec": 0.325, "speech_prob": 0.04, "rms_dbfs": -48.0, "voicing_score": 0.35},
                        {"window_start_sec": 0.35, "window_end_sec": 0.40, "center_sec": 0.375, "speech_prob": 0.6, "rms_dbfs": -30.0, "voicing_score": 0.8},
                    ],
                    "centers": [0.025, 0.125, 0.175, 0.325, 0.375],
                }
            },
            words_by_buffer={
                "buf": [
                    {"id": "w1", "source_start_sec": "0.00", "source_end_sec": "0.07"},
                    {"id": "w2", "source_start_sec": "0.23", "source_end_sec": "0.29"},
                ]
            }
        )
        vad_result = VadLocalMinimaDetector().find_cutpoints(contexts)
        hybrid_result = WordGapAcousticHybridDetector().find_cutpoints(contexts)
        self.assertEqual(len(vad_result.cutpoints), 2)
        self.assertEqual(len(hybrid_result.cutpoints), 1)

    def test_acoustic_detectors_emit_candidates_without_aligned_words(self) -> None:
        contexts = self._make_detector_contexts(words_by_buffer={})
        result = VadLocalMinimaDetector().find_cutpoints(contexts)
        self.assertGreater(len(result.cutpoints), 0)
        self.assertFalse(result.uses_aligned_words)

    def test_percentile_rms_is_stable_to_single_extreme_outlier(self) -> None:
        config = BenchmarkConfig(percentile_rms_percentile=10.0, percentile_rms_margin_db=3.0)
        frames = [
            {"rms_dbfs": -120.0},
            {"rms_dbfs": -56.0},
            {"rms_dbfs": -55.0},
            {"rms_dbfs": -54.0},
            {"rms_dbfs": -20.0},
            {"rms_dbfs": -18.0},
        ]
        legacy = _legacy_rms_threshold(frames, config)
        percentile = _percentile_rms_threshold(frames, config)
        self.assertLess(legacy, -100.0)
        self.assertGreater(percentile, -90.0)

    def test_prominence_only_local_rms_survives_global_gain_shift(self) -> None:
        config = BenchmarkConfig(
            local_prominence_context_frames=2,
            local_prominence_absolute_ceiling_dbfs=0.0,
            local_prominence_min_prominence_db=4.0,
        )
        base = [
            {"window_start_sec": "0.00", "window_end_sec": "0.05", "rms_dbfs": "-20.0", "speech_prob": "0.8"},
            {"window_start_sec": "0.05", "window_end_sec": "0.10", "rms_dbfs": "-21.0", "speech_prob": "0.8"},
            {"window_start_sec": "0.10", "window_end_sec": "0.15", "rms_dbfs": "-36.0", "speech_prob": "0.05"},
            {"window_start_sec": "0.15", "window_end_sec": "0.20", "rms_dbfs": "-21.0", "speech_prob": "0.8"},
            {"window_start_sec": "0.20", "window_end_sec": "0.25", "rms_dbfs": "-20.0", "speech_prob": "0.8"},
        ]
        shifted = [{**row, "rms_dbfs": str(float(row["rms_dbfs"]) + 12.0)} for row in base]
        base_centers = [(row["window_start_sec"], row["window_end_sec"]) for row in _local_prominence_frames(base, config, require_vad=False)]
        shifted_centers = [(row["window_start_sec"], row["window_end_sec"]) for row in _local_prominence_frames(shifted, config, require_vad=False)]
        self.assertEqual(base_centers, shifted_centers)

    def test_default_local_prominence_absolute_ceiling_rejects_gain_shifted_pause(self) -> None:
        config = BenchmarkConfig(
            local_prominence_context_frames=2,
            local_prominence_absolute_ceiling_dbfs=-38.0,
            local_prominence_min_prominence_db=4.0,
        )
        base = [
            {"window_start_sec": "0.00", "window_end_sec": "0.05", "rms_dbfs": "-20.0", "speech_prob": "0.8"},
            {"window_start_sec": "0.05", "window_end_sec": "0.10", "rms_dbfs": "-21.0", "speech_prob": "0.8"},
            {"window_start_sec": "0.10", "window_end_sec": "0.15", "rms_dbfs": "-42.0", "speech_prob": "0.05"},
            {"window_start_sec": "0.15", "window_end_sec": "0.20", "rms_dbfs": "-21.0", "speech_prob": "0.8"},
            {"window_start_sec": "0.20", "window_end_sec": "0.25", "rms_dbfs": "-20.0", "speech_prob": "0.8"},
        ]
        shifted = [{**row, "rms_dbfs": str(float(row["rms_dbfs"]) + 12.0)} for row in base]
        self.assertEqual(len(_local_prominence_frames(base, config, require_vad=False)), 1)
        self.assertEqual(len(_local_prominence_frames(shifted, config, require_vad=False)), 0)

    def test_adaptive_lowest_rms_placement_selects_valley_not_run_center(self) -> None:
        detector = AdaptiveLocalRmsDetector()
        contexts = self._make_detector_contexts(
            config=BenchmarkConfig(
                adaptive_rms_local_context_frames=3,
                adaptive_rms_min_valley_duration_ms=40.0,
                adaptive_rms_absolute_threshold_dbfs=-30.0,
                adaptive_rms_min_prominence_db=4.0,
                adaptive_rms_cut_placement="lowest_rms_frame",
            ),
            audio_feature_cache={
                "rec": {
                    "frames": [
                        {"window_start_sec": 0.00, "window_end_sec": 0.05, "center_sec": 0.025, "speech_prob": 0.5, "rms_dbfs": -20.0, "voicing_score": 0.8},
                        {"window_start_sec": 0.05, "window_end_sec": 0.10, "center_sec": 0.075, "speech_prob": 0.1, "rms_dbfs": -48.0, "voicing_score": 0.3},
                        {"window_start_sec": 0.10, "window_end_sec": 0.15, "center_sec": 0.125, "speech_prob": 0.1, "rms_dbfs": -40.0, "voicing_score": 0.3},
                        {"window_start_sec": 0.15, "window_end_sec": 0.20, "center_sec": 0.175, "speech_prob": 0.1, "rms_dbfs": -41.0, "voicing_score": 0.3},
                        {"window_start_sec": 0.20, "window_end_sec": 0.25, "center_sec": 0.225, "speech_prob": 0.5, "rms_dbfs": -20.0, "voicing_score": 0.8},
                    ],
                    "centers": [0.025, 0.075, 0.125, 0.175, 0.225],
                }
            },
        )
        result = detector.find_cutpoints(contexts)
        self.assertEqual([cut.time_sec for cut in result.cutpoints], [0.075])

    def test_safe_region_operational_recall_uses_trusted_bounds(self) -> None:
        rows = _safe_region_recall_rows(
            detector_name="det",
            cutpoints=[],
            corrected_safe_regions=[
                {"recording_id": "rec", "start_sec": 0.05, "end_sec": 0.15, "duration_ms": 100.0, "strict_eligible": True, "moderate_eligible": True},
                {"recording_id": "rec", "start_sec": 0.25, "end_sec": 0.35, "duration_ms": 100.0, "strict_eligible": True, "moderate_eligible": True},
            ],
            operational_buffers={"buf"},
            buffer_by_id={
                "buf": {
                    "buffer_id": "buf",
                    "source_audio_id": "src",
                    "source_start_sec": 0.0,
                    "source_end_sec": 1.0,
                    "trusted_start_sec": 0.2,
                    "trusted_end_sec": 0.4,
                }
            },
            sources={"src": SourceInfo("src", "rec", Path("audio.wav"), 1.0, 16000, 16000)},
            min_region_ms_values=(40,),
        )
        strict = next(row for row in rows if row["policy"] == "strict")
        self.assertEqual(strict["eligible_safe_region_count"], 2)
        self.assertEqual(strict["eligible_operational_safe_region_count"], 1)

    def test_acoustic_detectors_ignore_fatal_alignment_qc(self) -> None:
        contexts = self._make_detector_contexts(qc_by_buffer={"buf": {"automatic_cutpoints_disabled": True, "fatal_reason_codes": ["no_aligned_words"]}})
        result = VadLocalMinimaDetector().find_cutpoints(contexts)
        self.assertGreater(len(result.cutpoints), 0)
        self.assertFalse(result.uses_alignment_qc)

    def test_current_production_searched_buffers_follow_operational_qc(self) -> None:
        base = self._make_detector_contexts(
            qc_by_buffer={
                "buf_a": {"automatic_cutpoints_disabled": False, "fatal_reason_codes": []},
                "buf_b": {"automatic_cutpoints_disabled": False, "fatal_reason_codes": ["no_aligned_words"]},
                "buf_c": {"automatic_cutpoints_disabled": True, "fatal_reason_codes": []},
            },
            buffer_by_id={
                "buf_a": {"buffer_id": "buf_a", "source_audio_id": "src", "source_start_sec": 0.0, "source_end_sec": 1.0, "trusted_start_sec": 0.0, "trusted_end_sec": 1.0},
                "buf_b": {"buffer_id": "buf_b", "source_audio_id": "src", "source_start_sec": 1.0, "source_end_sec": 2.0, "trusted_start_sec": 1.0, "trusted_end_sec": 2.0},
                "buf_c": {"buffer_id": "buf_c", "source_audio_id": "src", "source_start_sec": 2.0, "source_end_sec": 3.0, "trusted_start_sec": 2.0, "trusted_end_sec": 3.0},
            },
        )
        linguistic = LinguisticDetectorContext(
            benchmark_root=base.linguistic.benchmark_root,
            config=base.linguistic.config,
            speechcraft_config=base.linguistic.speechcraft_config,
            sources=base.linguistic.sources,
            buffer_by_id=base.linguistic.buffer_by_id,
            queue_by_id=base.linguistic.queue_by_id,
            qc_by_buffer=base.linguistic.qc_by_buffer,
            words_by_buffer=base.linguistic.words_by_buffer,
            current_cuts_by_buffer={"buf_a": []},
            candidate_review_manifest=base.linguistic.candidate_review_manifest,
            audio_feature_cache=base.linguistic.audio_feature_cache,
            stage_durations_sec=base.linguistic.stage_durations_sec,
            profiler=base.linguistic.profiler,
        )
        contexts = BenchmarkContexts(shared=base.shared, acoustic=base.acoustic, linguistic=linguistic)
        result = CurrentProductionDetector().find_cutpoints(contexts)
        self.assertEqual(result.searched_buffer_ids, frozenset({"buf_a"}))

    def test_perturbing_aligned_words_does_not_change_acoustic_output(self) -> None:
        base = self._make_detector_contexts(words_by_buffer={"buf": [{"id": "w1", "source_start_sec": "0.2", "source_end_sec": "0.3"}]})
        perturbed = self._make_detector_contexts(words_by_buffer={"buf": [{"id": "w1", "source_start_sec": "0.6", "source_end_sec": "0.7"}]})
        base_times = [cut.time_sec for cut in VadLocalMinimaDetector().find_cutpoints(base).cutpoints]
        perturbed_times = [cut.time_sec for cut in VadLocalMinimaDetector().find_cutpoints(perturbed).cutpoints]
        self.assertEqual(base_times, perturbed_times)

    def test_whole_buffer_search_finds_valleys_outside_mfa_word_gaps(self) -> None:
        contexts = self._make_detector_contexts(
            words_by_buffer={
                "buf": [
                    {"id": "w1", "source_start_sec": "0.08", "source_end_sec": "0.12"},
                    {"id": "w2", "source_start_sec": "0.13", "source_end_sec": "0.17"},
                ]
            },
            audio_feature_cache={
                "rec": {
                    "frames": [
                        {"window_start_sec": 0.00, "window_end_sec": 0.05, "center_sec": 0.025, "speech_prob": 0.60, "rms_dbfs": -30.0, "voicing_score": 0.8},
                        {"window_start_sec": 0.20, "window_end_sec": 0.25, "center_sec": 0.225, "speech_prob": 0.04, "rms_dbfs": -55.0, "voicing_score": 0.3},
                        {"window_start_sec": 0.25, "window_end_sec": 0.30, "center_sec": 0.275, "speech_prob": 0.60, "rms_dbfs": -30.0, "voicing_score": 0.8},
                    ],
                    "centers": [0.025, 0.225, 0.275],
                }
            },
        )
        result = VadLocalMinimaDetector().find_cutpoints(contexts)
        self.assertIn(0.225, [cut.time_sec for cut in result.cutpoints])

    def test_invalid_zero_output_configuration_is_excluded_from_pareto(self) -> None:
        rows = _build_detector_scorecard(
            coverage_rows=[
                {"detector_name": "bad", "packer_name": "greedy", "unique_reference_speech_phone_sec": 0.0, "reference_speech_phone_coverage": 0.0, "raw_timeline_union_coverage": 0.0, "emitted_duration_ratio": 0.0},
                {"detector_name": "good", "packer_name": "greedy", "unique_reference_speech_phone_sec": 1.0, "reference_speech_phone_coverage": 0.2, "raw_timeline_union_coverage": 0.2, "emitted_duration_ratio": 0.2},
            ],
            shape_rows=[
                {"detector_name": "bad", "packer_name": "greedy", "clip_count": 0, "pct_inside_preferred_range": 0.0},
                {"detector_name": "good", "packer_name": "greedy", "clip_count": 5, "pct_inside_preferred_range": 0.5},
            ],
            duplication_rows=[
                {"detector_name": "bad", "packer_name": "greedy", "duplication_ratio": 1.0},
                {"detector_name": "good", "packer_name": "greedy", "duplication_ratio": 1.0},
            ],
            safe_region_rows=[
                {"detector_name": "bad", "policy": "strict", "min_region_ms": 40, "safe_region_recall_all": 0.0},
                {"detector_name": "good", "policy": "strict", "min_region_ms": 40, "safe_region_recall_all": 0.1},
            ],
            boundary_rows=[],
            severity_rows=[
                {"detector_name": "bad", "packer_name": "greedy", "stage": "final_emitted_boundaries", "boundary_side": "all", "boundary_count": 0, "inside_word_rate": 0.0, "inside_phone_rate": 0.0, "median_phone_leak_depth_sec": None, "p95_phone_leak_depth_sec": None},
                {"detector_name": "good", "packer_name": "greedy", "stage": "final_emitted_boundaries", "boundary_side": "all", "boundary_count": 20, "inside_word_rate": 0.1, "inside_phone_rate": 0.1, "median_phone_leak_depth_sec": 0.01, "p95_phone_leak_depth_sec": 0.02},
            ],
            compute_rows=[
                {"detector_name": "bad", "real_time_factor": 0.01, "peak_rss_mb": None, "total_pre_asr_buffer_duration_sec": 10.0},
                {"detector_name": "good", "real_time_factor": 0.02, "peak_rss_mb": None, "total_pre_asr_buffer_duration_sec": 10.0},
            ],
            detector_results={
                "bad": DetectorRunResult([], None, frozenset(), 0.0, 0, False, False, False, False, ""),
                "good": DetectorRunResult([], None, frozenset({"buf"}), 5.0, 1, False, False, False, False, ""),
            },
            config=BenchmarkConfig(minimum_boundaries_for_pareto=10, minimum_clips_for_pareto=1),
        )
        frontier = _build_pareto_frontier(rows)
        bad = next(row for row in frontier if row["detector_name"] == "bad")
        self.assertEqual(bad["pareto_basis"], "excluded_invalid_configuration")
        self.assertFalse(bad["pareto_optimal_pre_perceptual"])


if __name__ == "__main__":
    unittest.main()
