from __future__ import annotations

import json
import math
import os
import random
import resource
import hashlib
import statistics
import time
import wave
import zipfile
from bisect import bisect_left, bisect_right
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass, field, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Protocol

from .buckeye_safecut_benchmark import (
    DEFAULT_PHONE_GUARD_MS,
    DEFAULT_SAFE_REGION_MIN_MS,
    DEFAULT_VAD_MIN_RUN_MS,
    DEFAULT_VAD_THRESHOLD,
    EPSILON_SEC,
    SourceInfo,
    _as_bool,
    _as_float,
    _build_corrected_safe_regions,
    _build_reference_safe_regions,
    _compute_recording_vad_frames,
    _group_by,
    _index_frames,
    _load_sources,
    _phone_clearances_ms,
    _read_csv,
    _read_json,
    _slice_indexed_frames,
)
from .intervals import intersection_duration, merge_intervals, overlap_duration
from .io_utils import read_json, read_jsonl, write_csv, write_json


STRICT_SAFE_TYPES = {"silence", "pause"}
MODERATE_SAFE_TYPES = STRICT_SAFE_TYPES | {"breath"}
PREFERRED_RANGE = (6.0, 8.0)
LISTENING_BUCKETS = (
    "outside_all_phones",
    "inside_phone_0_10ms",
    "inside_phone_10_20ms",
    "inside_phone_20_50ms",
    "inside_phone_50_100ms",
    "inside_phone_gt_100ms",
)


@dataclass(frozen=True)
class BenchmarkConfig:
    min_clip_sec: float = 3.0
    preferred_min_sec: float = 6.0
    preferred_max_sec: float = 8.0
    target_clip_sec: float = 8.0
    max_clip_sec: float = 15.0
    allow_overlap: bool = False
    max_overlap_sec: float = 0.0
    max_duplication_ratio: float = 1.0
    deterministic_seed: int = 0
    safe_region_min_ms_values: tuple[int, ...] = (20, 40, 60, 80, 100)
    guard_ms_values: tuple[int, ...] = (10, 20, 50, 100)
    listening_sample_per_bucket: int = 3
    minimum_boundaries_for_pareto: int = 10
    minimum_clips_for_pareto: int = 1
    vad_threshold: float = DEFAULT_VAD_THRESHOLD
    vad_min_run_ms: float = DEFAULT_VAD_MIN_RUN_MS
    legacy_rms_min_margin_db: float = 3.0
    percentile_rms_percentile: float = 10.0
    percentile_rms_margin_db: float = 3.0
    local_prominence_context_frames: int = 25
    local_prominence_absolute_ceiling_dbfs: float = -38.0
    local_prominence_min_prominence_db: float = 4.0
    adaptive_rms_local_context_frames: int = 25
    adaptive_rms_min_valley_duration_ms: float = 80.0
    adaptive_rms_min_prominence_db: float = 4.0
    adaptive_rms_absolute_threshold_dbfs: float = -38.0
    adaptive_rms_min_separation_ms: float = 80.0
    adaptive_rms_cut_placement: str = "lowest_rms_frame"
    rms_vad_veto_mean_threshold: float = 0.6
    rms_vad_veto_min_threshold: float = 0.3


@dataclass(frozen=True)
class PackingConstraints:
    min_clip_sec: float
    preferred_min_sec: float
    preferred_max_sec: float
    target_clip_sec: float
    max_clip_sec: float
    allow_overlap: bool
    max_overlap_sec: float
    max_duplication_ratio: float
    eligible_regions_by_recording: dict[str, tuple[tuple[float, float], ...]] = field(default_factory=dict)


@dataclass(frozen=True)
class Cutpoint:
    detector_name: str
    source_id: str
    recording_id: str
    buffer_id: str
    cutpoint_id: str
    time_sec: float
    interval_start_sec: float
    interval_end_sec: float
    score: float
    vad_min: float | None
    vad_mean: float | None
    vad_longest_below_0_1_ms: float | None
    vad_longest_below_0_2_ms: float | None
    rms_min_dbfs: float | None
    rms_mean_dbfs: float | None
    voicing_min: float | None
    voicing_mean: float | None
    compute_time_sec: float
    is_buffer_edge_candidate: bool
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class Clip:
    detector_name: str
    packer_name: str
    source_id: str
    recording_id: str
    buffer_id: str
    clip_id: str
    start_sec: float
    end_sec: float
    duration_sec: float
    start_cutpoint_id: str
    end_cutpoint_id: str
    selected_weight: float
    selected_boundary_count: int


@dataclass(frozen=True)
class CandidateClip:
    detector_name: str
    source_id: str
    recording_id: str
    buffer_id: str
    candidate_id: str
    start_sec: float
    end_sec: float
    duration_sec: float
    start_cutpoint_id: str
    end_cutpoint_id: str
    weight: float


@dataclass(frozen=True)
class ComputeMetric:
    detector_name: str
    wall_clock_sec: float
    cpu_time_sec: float
    gpu_time_sec: float | None
    peak_rss_mb: float | None
    peak_gpu_memory_mb: float | None
    real_time_factor: float | None
    model_init_time_sec: float | None
    per_hour_audio_cost_sec: float | None
    external_model_dependencies: tuple[str, ...]
    notes: str = ""
    cold_audio_decode_sec: float | None = None
    cold_rms_extraction_sec: float | None = None
    cold_vad_model_load_sec: float | None = None
    cold_vad_inference_sec: float | None = None
    cold_voicing_extraction_sec: float | None = None
    cold_candidate_generation_sec: float | None = None
    cold_packing_sec: float | None = None
    warm_audio_decode_sec: float | None = None
    warm_rms_extraction_sec: float | None = None
    warm_vad_model_load_sec: float | None = None
    warm_vad_inference_sec: float | None = None
    warm_voicing_extraction_sec: float | None = None
    warm_candidate_generation_sec: float | None = None
    warm_packing_sec: float | None = None


@dataclass
class DetectorContext:
    eval_run: Path
    normalized_speaker_dir: Path
    benchmark_root: Path
    config: BenchmarkConfig
    sources: dict[str, SourceInfo]
    buffer_by_id: dict[str, dict[str, Any]]
    lexical_words_by_recording: dict[str, list[dict[str, Any]]]
    speech_phones_by_recording: dict[str, list[dict[str, Any]]]
    corrected_safe_regions: list[dict[str, Any]]
    reference_words: list[dict[str, Any]]
    reference_phones: list[dict[str, Any]]


@dataclass
class AcousticDetectorContext:
    benchmark_root: Path
    config: BenchmarkConfig
    sources: dict[str, SourceInfo]
    buffer_by_id: dict[str, dict[str, Any]]
    audio_feature_cache: dict[str, dict[str, Any]]
    profiler: dict[str, Any]


@dataclass
class LinguisticDetectorContext:
    benchmark_root: Path
    config: BenchmarkConfig
    speechcraft_config: dict[str, Any]
    sources: dict[str, SourceInfo]
    buffer_by_id: dict[str, dict[str, Any]]
    queue_by_id: dict[str, dict[str, Any]]
    qc_by_buffer: dict[str, dict[str, Any]]
    words_by_buffer: dict[str, list[dict[str, Any]]]
    current_cuts_by_buffer: dict[str, list[dict[str, Any]]]
    candidate_review_manifest: list[dict[str, Any]]
    audio_feature_cache: dict[str, dict[str, Any]]
    stage_durations_sec: dict[str, float]
    profiler: dict[str, Any]


@dataclass(frozen=True)
class BenchmarkContexts:
    shared: DetectorContext
    acoustic: AcousticDetectorContext
    linguistic: LinguisticDetectorContext


@dataclass(frozen=True)
class DetectorRunResult:
    cutpoints: list[Cutpoint]
    compute_metric: ComputeMetric
    searched_buffer_ids: frozenset[str]
    searched_duration_sec: float
    searched_interval_count: int
    uses_asr: bool
    uses_mfa: bool
    uses_aligned_words: bool
    uses_alignment_qc: bool
    validity_notes: str = ""


class CutpointDetector(Protocol):
    name: str

    def find_cutpoints(self, contexts: BenchmarkContexts) -> DetectorRunResult:
        ...


class ClipPacker(Protocol):
    name: str

    def pack(
        self,
        *,
        duration_sec: float,
        cutpoints: list[Cutpoint],
        constraints: PackingConstraints,
    ) -> list[Clip]:
        ...


class SlicerEvaluator:
    def __init__(self, context: DetectorContext) -> None:
        self.context = context

    def evaluate(
        self,
        *,
        detector_name: str,
        packer_name: str,
        clips: list[Clip],
        cutpoints: list[Cutpoint],
        operational_buffers: set[str],
    ) -> dict[str, list[dict[str, Any]]]:
        coverage_rows = _compute_coverage_metrics(
            detector_name=detector_name,
            packer_name=packer_name,
            clips=clips,
            lexical_words_by_recording=self.context.lexical_words_by_recording,
            speech_phones_by_recording=self.context.speech_phones_by_recording,
            sources=self.context.sources,
        )
        shape_rows = [_clip_shape_metrics(detector_name=detector_name, packer_name=packer_name, clips=clips, config=self.context.config)]
        duplication_rows = [_duplication_metrics(detector_name=detector_name, packer_name=packer_name, clips=clips)]
        boundary_rows, severity_rows = _boundary_safety_rows(
            detector_name=detector_name,
            packer_name=packer_name,
            cutpoints=cutpoints,
            clips=clips,
            lexical_words_by_recording=self.context.lexical_words_by_recording,
            speech_phones_by_recording=self.context.speech_phones_by_recording,
        )
        safe_region_rows = _safe_region_recall_rows(
            detector_name=detector_name,
            cutpoints=cutpoints,
            corrected_safe_regions=self.context.corrected_safe_regions,
            operational_buffers=operational_buffers,
            buffer_by_id=self.context.buffer_by_id,
            sources=self.context.sources,
            min_region_ms_values=self.context.config.safe_region_min_ms_values,
        )
        return {
            "coverage": coverage_rows,
            "shape": shape_rows,
            "duplication": duplication_rows,
            "boundary_safety": boundary_rows,
            "boundary_severity": severity_rows,
            "safe_region_recall": safe_region_rows,
        }


class CurrentProductionDetector:
    name = "current_production"

    def find_cutpoints(self, contexts: BenchmarkContexts) -> DetectorRunResult:
        context = contexts.linguistic
        stage_durations = context.stage_durations_sec
        cuts: list[Cutpoint] = []
        searched_buffer_ids: set[str] = {
            buffer_id
            for buffer_id, qc_row in context.qc_by_buffer.items()
            if not _as_bool(qc_row.get("automatic_cutpoints_disabled"))
            and not qc_row.get("fatal_reason_codes")
        }
        for buffer_id, rows in context.current_cuts_by_buffer.items():
            buffer = context.buffer_by_id[buffer_id]
            source = context.sources[str(buffer["source_audio_id"])]
            words = {str(row["id"]): row for row in context.words_by_buffer.get(buffer_id, [])}
            for row in rows:
                interval_start = float(buffer["source_start_sec"]) + (int(row["candidate_start_local_sample"]) / source.sample_rate)
                interval_end = float(buffer["source_start_sec"]) + (int(row["candidate_end_local_sample"]) / source.sample_rate)
                cut_time = int(row["source_sample"]) / source.sample_rate
                stats = _window_feature_stats(context.audio_feature_cache[source.recording_id], cut_time - 0.05, cut_time + 0.05)
                score = -float(row.get("valley_dbfs") or 0.0)
                cuts.append(
                    Cutpoint(
                        detector_name=self.name,
                        source_id=source.source_audio_id,
                        recording_id=source.recording_id,
                        buffer_id=buffer_id,
                        cutpoint_id=str(row["id"]),
                        time_sec=round(cut_time, 6),
                        interval_start_sec=round(interval_start, 6),
                        interval_end_sec=round(interval_end, 6),
                        score=score,
                        vad_min=stats["vad_min"],
                        vad_mean=stats["vad_mean"],
                        vad_longest_below_0_1_ms=stats["vad_longest_below_0_1_ms"],
                        vad_longest_below_0_2_ms=stats["vad_longest_below_0_2_ms"],
                        rms_min_dbfs=stats["rms_min_dbfs"],
                        rms_mean_dbfs=stats["rms_mean_dbfs"],
                        voicing_min=stats["voicing_min"],
                        voicing_mean=stats["voicing_mean"],
                        compute_time_sec=0.0,
                        is_buffer_edge_candidate=False,
                        metadata={
                            "left_word": row.get("left_word", ""),
                            "right_word": row.get("right_word", ""),
                            "gap_duration_ms": round(float(row.get("gap_duration_sec", 0.0)) * 1000.0, 3),
                            "usable_gap_ms": round(float(row.get("usable_gap_sec", 0.0)) * 1000.0, 3),
                            "valley_dbfs": row.get("valley_dbfs"),
                            "noise_floor_dbfs": row.get("noise_floor_dbfs"),
                            "left_word_id": row.get("left_word_id", ""),
                            "right_word_id": row.get("right_word_id", ""),
                            "buffer_warning_reason_codes": row.get("buffer_warning_reason_codes", []),
                        },
                    )
                )
        metric = ComputeMetric(
            detector_name=self.name,
            wall_clock_sec=round(
                stage_durations.get("asr", 0.0)
                + stage_durations.get("normalization", 0.0)
                + stage_durations.get("mfa", 0.0)
                + stage_durations.get("alignment_qc", 0.0)
                + stage_durations.get("safe_cutpoints", 0.0),
                6,
            ),
            cpu_time_sec=0.0,
            gpu_time_sec=stage_durations.get("asr"),
            peak_rss_mb=None,
            peak_gpu_memory_mb=None,
            real_time_factor=_safe_divide(
                stage_durations.get("asr", 0.0)
                + stage_durations.get("normalization", 0.0)
                + stage_durations.get("mfa", 0.0)
                + stage_durations.get("alignment_qc", 0.0)
                + stage_durations.get("safe_cutpoints", 0.0),
                _total_source_duration(context.sources),
            ),
            model_init_time_sec=None,
            per_hour_audio_cost_sec=_safe_divide(
                3600.0
                * (
                    stage_durations.get("asr", 0.0)
                    + stage_durations.get("normalization", 0.0)
                    + stage_durations.get("mfa", 0.0)
                    + stage_durations.get("alignment_qc", 0.0)
                    + stage_durations.get("safe_cutpoints", 0.0)
                ),
                _total_source_duration(context.sources),
            ),
            external_model_dependencies=("faster-whisper:small.en", "mfa:english_us_mfa", "mfa:english_mfa"),
            notes="Derived from existing Speechcraft run stage timings; warm steady-state and incremental memory unavailable.",
            cold_audio_decode_sec=stage_durations.get("audio_variants"),
            cold_rms_extraction_sec=None,
            cold_vad_model_load_sec=None,
            cold_vad_inference_sec=stage_durations.get("vad"),
            cold_voicing_extraction_sec=None,
            cold_candidate_generation_sec=round(stage_durations.get("alignment_qc", 0.0) + stage_durations.get("safe_cutpoints", 0.0), 6),
            cold_packing_sec=stage_durations.get("candidate_review_clips"),
            warm_audio_decode_sec=None,
            warm_rms_extraction_sec=None,
            warm_vad_model_load_sec=None,
            warm_vad_inference_sec=None,
            warm_voicing_extraction_sec=None,
            warm_candidate_generation_sec=None,
            warm_packing_sec=None,
        )
        searched_duration_sec = _buffer_union_duration(
            buffer_ids=searched_buffer_ids,
            buffer_by_id=context.buffer_by_id,
            sources=context.sources,
        )
        return DetectorRunResult(
            cutpoints=cuts,
            compute_metric=metric,
            searched_buffer_ids=frozenset(searched_buffer_ids),
            searched_duration_sec=round(searched_duration_sec, 6),
            searched_interval_count=len(searched_buffer_ids),
            uses_asr=True,
            uses_mfa=True,
            uses_aligned_words=True,
            uses_alignment_qc=True,
            validity_notes="Current production path uses existing Speechcraft ASR, MFA, alignment QC, and accepted SafeCutPoints.",
        )


class AcousticDetector:
    name = "acoustic"
    use_vad: bool = False
    use_rms: bool = False
    use_voicing: bool = False
    rms_mode: str = "legacy_min_plus_margin"
    include_edges: bool = False
    use_single_best_per_region: bool = False
    cut_placement: str = "default"

    def find_cutpoints(self, contexts: BenchmarkContexts) -> DetectorRunResult:
        context = contexts.acoustic
        self._benchmark_config = context.config
        start_wall = time.perf_counter()
        start_cpu = time.process_time()
        cuts: list[Cutpoint] = []
        rejection_rows: list[dict[str, Any]] = []
        diagnostic_rows: list[dict[str, Any]] = []
        searched_buffer_ids: set[str] = set()
        for buffer_id, buffer in sorted(context.buffer_by_id.items()):
            source = context.sources[str(buffer["source_audio_id"])]
            features = context.audio_feature_cache[source.recording_id]
            trusted_start = float(buffer["trusted_start_sec"])
            trusted_end = float(buffer["trusted_end_sec"])
            if trusted_end - trusted_start < float(context.config.vad_min_run_ms) / 1000.0:
                rejection_rows.append(
                    _detector_trace_row(
                        detector_name=self.name,
                        recording_id=source.recording_id,
                        buffer_id=buffer_id,
                        reason="trusted_buffer_too_short",
                        count=1,
                    )
                )
                continue
            searched_buffer_ids.add(buffer_id)
            regions = [(trusted_start, trusted_end, False)]
            for region_index, (region_start, region_end, is_edge) in enumerate(regions):
                region_frames = _slice_feature_frames(features, region_start, region_end)
                if not region_frames:
                    rejection_rows.append(
                        _detector_trace_row(
                            detector_name=self.name,
                            recording_id=source.recording_id,
                            buffer_id=buffer_id,
                            reason="no_region_frames",
                            count=1,
                        )
                    )
                    continue
                region_cuts, region_trace = self._cuts_for_region(
                    detector_name=self.name,
                    source=source,
                    buffer_id=buffer_id,
                    region_index=region_index,
                    region_start=region_start,
                    region_end=region_end,
                    is_edge=is_edge,
                    region_frames=region_frames,
                    exclude_region_edge_runs=False,
                )
                cuts.extend(region_cuts)
                diagnostic_rows.append(
                    _acoustic_buffer_diagnostic_row(
                        detector_name=self.name,
                        recording_id=source.recording_id,
                        buffer_id=buffer_id,
                        trusted_duration_sec=trusted_end - trusted_start,
                        region_frames=region_frames,
                        accepted_cutpoint_count=len(region_cuts),
                        trace=region_trace,
                        config=context.config,
                        use_vad=self.use_vad,
                        use_rms=self.use_rms,
                        rms_mode=self.rms_mode,
                    )
                )
                for reason, count in region_trace.items():
                    rejection_rows.append(
                        _detector_trace_row(
                            detector_name=self.name,
                            recording_id=source.recording_id,
                            buffer_id=buffer_id,
                            reason=reason,
                            count=count,
                        )
                    )
        wall = time.perf_counter() - start_wall
        cpu = time.process_time() - start_cpu
        dependencies = []
        notes = []
        if self.use_vad:
            dependencies.append("silero-vad")
            notes.append("Detector evaluation used benchmark VAD feature cache; uncached timings are reported separately.")
        if self.use_rms:
            dependencies.append("audio-rms")
        if self.use_voicing:
            dependencies.append("voicing-heuristic")
            notes.append("Voicing is a ZCR-derived cut-placement preference, not a voiced-speech veto.")
        metric = _acoustic_compute_metric(
            detector=self,
            context=context,
            candidate_generation_sec=wall,
            packing_sec=0.0,
            dependencies=tuple(dependencies),
            notes="; ".join(notes),
        )
        _append_detector_trace_rows(context.benchmark_root / "tables" / "detector_rejection_trace.csv", rejection_rows)
        _append_acoustic_buffer_diagnostics(
            context.benchmark_root / "tables" / "acoustic_detector_buffer_diagnostics.csv",
            diagnostic_rows,
        )
        deduped = _dedupe_cutpoints(cuts)
        return DetectorRunResult(
            cutpoints=deduped,
            compute_metric=metric,
            searched_buffer_ids=frozenset(searched_buffer_ids),
            searched_duration_sec=round(
                _buffer_union_duration(buffer_ids=searched_buffer_ids, buffer_by_id=context.buffer_by_id, sources=context.sources),
                6,
            ),
            searched_interval_count=len(searched_buffer_ids),
            uses_asr=False,
            uses_mfa=False,
            uses_aligned_words=False,
            uses_alignment_qc=False,
            validity_notes="Whole-buffer acoustic search over trusted pre-ASR processing buffers only.",
        )

    def _cuts_for_region(
        self,
        *,
        detector_name: str,
        source: SourceInfo,
        buffer_id: str,
        region_index: int,
        region_start: float,
        region_end: float,
        is_edge: bool,
        region_frames: list[dict[str, Any]],
        exclude_region_edge_runs: bool = True,
    ) -> tuple[list[Cutpoint], Counter[str]]:
        trace: Counter[str] = Counter()
        trace["regions_seen"] += 1
        if self.use_vad:
            config = getattr(self, "_benchmark_config", BenchmarkConfig())
            selected_frames = [row for row in region_frames if float(row["speech_prob"]) < config.vad_threshold]
            if not selected_frames:
                trace["no_frames_below_vad_threshold"] += 1
                return [], trace
        else:
            rms_values = [float(row["rms_dbfs"]) for row in region_frames]
            if not rms_values:
                trace["no_rms_frames"] += 1
                return [], trace
            config = getattr(self, "_benchmark_config", BenchmarkConfig())
            rms_threshold = self._rms_threshold(region_frames, config)
            selected_frames = [row for row in region_frames if float(row["rms_dbfs"]) <= rms_threshold]
            if not selected_frames:
                trace["no_frames_below_rms_threshold"] += 1
                return [], trace
        if self.use_rms:
            rms_values = [float(row["rms_dbfs"]) for row in region_frames]
            if not rms_values:
                trace["missing_rms_for_rms_filter"] += 1
                return [], trace
            config = getattr(self, "_benchmark_config", BenchmarkConfig())
            rms_threshold = self._rms_threshold(region_frames, config)
            selected_frames = [row for row in selected_frames if float(row["rms_dbfs"]) <= rms_threshold]
            if not selected_frames:
                trace["all_frames_rejected_by_rms_threshold"] += 1
                return [], trace
        preferred_frames = selected_frames
        if self.use_voicing:
            low_voicing = [row for row in selected_frames if float(row["voicing_score"]) <= 0.85]
            if low_voicing:
                preferred_frames = low_voicing
                trace["voicing_preferred_frames_available"] += 1
            else:
                trace["voicing_preferred_frames_missing_fallback_to_vad_rms"] += 1
        if not selected_frames:
            trace["no_selected_frames"] += 1
            return [], trace
        if self.use_single_best_per_region:
            cut = self._build_cutpoint(
                detector_name=detector_name,
                source=source,
                buffer_id=buffer_id,
                region_index=region_index,
                run_index=0,
                is_edge=is_edge,
                region_frames=region_frames,
                run_frames=preferred_frames,
                run_start=region_start,
                run_end=region_end,
            )
            trace["accepted_single_region_cutpoint"] += 1
            return [cut], trace
        runs = merge_intervals(
            [(float(row["window_start_sec"]), float(row["window_end_sec"])) for row in selected_frames],
            epsilon_sec=0.0,
        )
        cuts: list[Cutpoint] = []
        for run_index, (run_start, run_end) in enumerate(runs):
            run_ms = (run_end - run_start) * 1000.0
            config = getattr(self, "_benchmark_config", BenchmarkConfig())
            if run_ms < config.vad_min_run_ms:
                trace["run_below_min_duration"] += 1
                continue
            run_frames = [
                row
                for row in preferred_frames
                if overlap_duration(float(row["window_start_sec"]), float(row["window_end_sec"]), run_start, run_end) > EPSILON_SEC
            ]
            if not run_frames:
                trace["empty_run_after_filters"] += 1
                continue
            touches_left_edge = run_start <= region_start + EPSILON_SEC
            touches_right_edge = run_end >= region_end - EPSILON_SEC
            if exclude_region_edge_runs and (touches_left_edge or touches_right_edge) and not self.include_edges:
                trace["run_touches_buffer_edge_excluded"] += 1
                continue
            cuts.append(
                self._build_cutpoint(
                    detector_name=detector_name,
                    source=source,
                    buffer_id=buffer_id,
                    region_index=region_index,
                    run_index=run_index,
                    is_edge=is_edge,
                    region_frames=region_frames,
                    run_frames=run_frames,
                    run_start=run_start,
                    run_end=run_end,
                )
            )
            trace["accepted_run_cutpoint"] += 1
        if self.include_edges:
            cuts.extend(
                self._edge_cutpoints(
                    detector_name=detector_name,
                    source=source,
                    buffer_id=buffer_id,
                    region_index=region_index,
                    region_start=region_start,
                    region_end=region_end,
                    selected_frames=preferred_frames,
                    trace=trace,
                )
            )
        if not cuts:
            trace["region_produced_zero_cutpoints"] += 1
        return cuts, trace

    def _rms_threshold(self, frames: list[dict[str, Any]], config: BenchmarkConfig) -> float:
        if self.rms_mode == "percentile":
            return _percentile_rms_threshold(frames, config)
        return _legacy_rms_threshold(frames, config)

    def _edge_cutpoints(
        self,
        *,
        detector_name: str,
        source: SourceInfo,
        buffer_id: str,
        region_index: int,
        region_start: float,
        region_end: float,
        selected_frames: list[dict[str, Any]],
        trace: Counter[str],
    ) -> list[Cutpoint]:
        edge_cuts: list[Cutpoint] = []
        left_frames = [
            row for row in selected_frames if float(row["window_start_sec"]) <= region_start + EPSILON_SEC
        ]
        right_frames = [
            row for row in selected_frames if float(row["window_end_sec"]) >= region_end - EPSILON_SEC
        ]
        for side, edge_time, edge_frames in (
            ("left", region_start, left_frames),
            ("right", region_end, right_frames),
        ):
            if not edge_frames:
                trace[f"no_{side}_edge_frames"] += 1
                continue
            stats = _stats_from_frames(edge_frames)
            cut_id = f"{buffer_id}-{detector_name}-{region_index:04d}-{side}-edge-{int(round(edge_time * 1000.0))}"
            edge_cuts.append(
                Cutpoint(
                    detector_name=detector_name,
                    source_id=source.source_audio_id,
                    recording_id=source.recording_id,
                    buffer_id=buffer_id,
                    cutpoint_id=cut_id,
                    time_sec=round(edge_time, 6),
                    interval_start_sec=round(min(float(row["window_start_sec"]) for row in edge_frames), 6),
                    interval_end_sec=round(max(float(row["window_end_sec"]) for row in edge_frames), 6),
                    score=round(
                        _candidate_score(
                            speech_prob=min(float(row["speech_prob"]) for row in edge_frames),
                            rms_dbfs=min(float(row["rms_dbfs"]) for row in edge_frames),
                            voicing_score=min(float(row["voicing_score"]) for row in edge_frames),
                            use_vad=self.use_vad,
                            use_rms=self.use_rms,
                            use_voicing=self.use_voicing,
                        ),
                        6,
                    ),
                    vad_min=stats["vad_min"],
                    vad_mean=stats["vad_mean"],
                    vad_longest_below_0_1_ms=stats["vad_longest_below_0_1_ms"],
                    vad_longest_below_0_2_ms=stats["vad_longest_below_0_2_ms"],
                    rms_min_dbfs=stats["rms_min_dbfs"],
                    rms_mean_dbfs=stats["rms_mean_dbfs"],
                    voicing_min=stats["voicing_min"],
                    voicing_mean=stats["voicing_mean"],
                    compute_time_sec=0.0,
                    is_buffer_edge_candidate=True,
                    metadata={"edge_side": side, "selected_center_sec": round(edge_time, 6)},
                )
            )
            trace[f"accepted_{side}_edge_cutpoint"] += 1
        return edge_cuts

    def _build_cutpoint(
        self,
        *,
        detector_name: str,
        source: SourceInfo,
        buffer_id: str,
        region_index: int,
        run_index: int,
        is_edge: bool,
        region_frames: list[dict[str, Any]],
        run_frames: list[dict[str, Any]],
        run_start: float,
        run_end: float,
    ) -> Cutpoint:
        valley = min(
            run_frames,
            key=lambda row: self._cut_placement_key(row, run_start=run_start, run_end=run_end),
        )
        stats = _stats_from_frames(run_frames)
        score = _candidate_score(
            speech_prob=float(valley["speech_prob"]),
            rms_dbfs=float(valley["rms_dbfs"]),
            voicing_score=float(valley["voicing_score"]),
            use_vad=self.use_vad,
            use_rms=self.use_rms,
            use_voicing=self.use_voicing,
        )
        center = float(valley["center_sec"])
        run_ms = (run_end - run_start) * 1000.0
        cut_id = f"{buffer_id}-{detector_name}-{region_index:04d}-{run_index:04d}-{int(round(center * 1000.0))}"
        return Cutpoint(
            detector_name=detector_name,
            source_id=source.source_audio_id,
            recording_id=source.recording_id,
            buffer_id=buffer_id,
            cutpoint_id=cut_id,
            time_sec=round(center, 6),
            interval_start_sec=round(run_start, 6),
            interval_end_sec=round(run_end, 6),
            score=round(score, 6),
            vad_min=stats["vad_min"],
            vad_mean=stats["vad_mean"],
            vad_longest_below_0_1_ms=stats["vad_longest_below_0_1_ms"],
            vad_longest_below_0_2_ms=stats["vad_longest_below_0_2_ms"],
            rms_min_dbfs=stats["rms_min_dbfs"],
            rms_mean_dbfs=stats["rms_mean_dbfs"],
            voicing_min=stats["voicing_min"],
            voicing_mean=stats["voicing_mean"],
            compute_time_sec=0.0,
            is_buffer_edge_candidate=is_edge,
            metadata={
                "run_duration_ms": round(run_ms, 3),
                "selected_center_sec": round(center, 6),
            },
        )

    def _cut_placement_key(self, row: dict[str, Any], *, run_start: float, run_end: float) -> tuple[float, ...]:
        run_center = (run_start + run_end) / 2.0
        if self.cut_placement == "lowest_rms_frame":
            return (
                float(row["rms_dbfs"]),
                abs(float(row["center_sec"]) - run_center),
            )
        if self.cut_placement == "run_center":
            return (
                abs(float(row["center_sec"]) - run_center),
            )
        if self.cut_placement != "default":
            raise ValueError(f"unknown cut placement policy: {self.cut_placement}")
        return (
            0.0 if not self.use_vad else float(row["speech_prob"]),
            0.0 if not self.use_rms else float(row["rms_dbfs"]),
            0.0 if not self.use_voicing else float(row["voicing_score"]) * 0.5,
            abs(float(row["center_sec"]) - run_center),
        )


class VadLocalMinimaDetector(AcousticDetector):
    name = "vad_local_minima"
    use_vad = True


class RmsMinimaDetector(AcousticDetector):
    name = "legacy_rms_minima"
    use_rms = True


class VadRmsDetector(AcousticDetector):
    name = "legacy_vad_rms"
    use_vad = True
    use_rms = True


class PercentileRmsDetector(AcousticDetector):
    name = "percentile_rms"
    use_rms = True
    rms_mode = "percentile"


class VadPercentileRmsDetector(AcousticDetector):
    name = "vad_percentile_rms"
    use_vad = True
    use_rms = True
    rms_mode = "percentile"

    def find_cutpoints(self, contexts: BenchmarkContexts) -> DetectorRunResult:
        return _find_vad_percentile_rms_cutpoints_optimized(self, contexts)


def _find_vad_percentile_rms_cutpoints_optimized(
    detector: AcousticDetector,
    contexts: BenchmarkContexts,
) -> DetectorRunResult:
    import numpy as np

    context = contexts.acoustic
    detector._benchmark_config = context.config
    start_wall = time.perf_counter()
    start_cpu = time.process_time()
    cuts: list[Cutpoint] = []
    rejection_rows: list[dict[str, Any]] = []
    diagnostic_rows: list[dict[str, Any]] = []
    searched_buffer_ids: set[str] = set()
    timings: Counter[str] = Counter()
    arrays_by_recording: dict[str, dict[str, Any]] = {}

    def arrays_for(recording_id: str) -> dict[str, Any]:
        cached = arrays_by_recording.get(recording_id)
        if cached is not None:
            return cached
        started = time.perf_counter()
        frames = context.audio_feature_cache[recording_id]["frames"]
        cached = {
            "frames": frames,
            "centers": np.asarray([float(row["center_sec"]) for row in frames], dtype=np.float64),
            "starts": np.asarray([float(row["window_start_sec"]) for row in frames], dtype=np.float64),
            "ends": np.asarray([float(row["window_end_sec"]) for row in frames], dtype=np.float64),
            "probs": np.asarray([float(row["speech_prob"]) for row in frames], dtype=np.float64),
            "rms_dbfs": np.asarray([float(row["rms_dbfs"]) for row in frames], dtype=np.float64),
            "voicing": np.asarray([float(row["voicing_score"]) for row in frames], dtype=np.float64),
        }
        timings["frame_array_build_sec"] += time.perf_counter() - started
        arrays_by_recording[recording_id] = cached
        return cached

    for buffer_id, buffer in sorted(context.buffer_by_id.items()):
        source = context.sources[str(buffer["source_audio_id"])]
        trusted_start = float(buffer["trusted_start_sec"])
        trusted_end = float(buffer["trusted_end_sec"])
        if trusted_end - trusted_start < float(context.config.vad_min_run_ms) / 1000.0:
            rejection_rows.append(
                _detector_trace_row(
                    detector_name=detector.name,
                    recording_id=source.recording_id,
                    buffer_id=buffer_id,
                    reason="trusted_buffer_too_short",
                    count=1,
                )
            )
            continue
        searched_buffer_ids.add(buffer_id)
        data = arrays_for(source.recording_id)
        frames = data["frames"]
        centers = data["centers"]
        starts = data["starts"]
        ends = data["ends"]
        probs = data["probs"]
        rms_dbfs = data["rms_dbfs"]
        region_start = trusted_start
        region_end = trusted_end
        region_index = 0

        started = time.perf_counter()
        left = int(np.searchsorted(centers, region_start + EPSILON_SEC, side="right"))
        right = int(np.searchsorted(centers, region_end - EPSILON_SEC, side="left"))
        region_indices = np.arange(left, right, dtype=np.int64)
        region_frames = frames[left:right]
        timings["region_lookup_sec"] += time.perf_counter() - started
        if not region_frames:
            rejection_rows.append(
                _detector_trace_row(
                    detector_name=detector.name,
                    recording_id=source.recording_id,
                    buffer_id=buffer_id,
                    reason="no_region_frames",
                    count=1,
                )
            )
            continue

        trace: Counter[str] = Counter()
        trace["regions_seen"] += 1
        started = time.perf_counter()
        vad_mask = probs[region_indices] < float(context.config.vad_threshold)
        timings["vad_rms_mask_combination_sec"] += time.perf_counter() - started
        if not bool(vad_mask.any()):
            trace["no_frames_below_vad_threshold"] += 1
            diagnostic_rows.append(
                _acoustic_buffer_diagnostic_row(
                    detector_name=detector.name,
                    recording_id=source.recording_id,
                    buffer_id=buffer_id,
                    trusted_duration_sec=trusted_end - trusted_start,
                    region_frames=region_frames,
                    accepted_cutpoint_count=0,
                    trace=trace,
                    config=context.config,
                    use_vad=detector.use_vad,
                    use_rms=detector.use_rms,
                    rms_mode=detector.rms_mode,
                )
            )
            for reason, count in trace.items():
                rejection_rows.append(_detector_trace_row(detector_name=detector.name, recording_id=source.recording_id, buffer_id=buffer_id, reason=reason, count=count))
            continue

        started = time.perf_counter()
        rms_threshold = _percentile_value(
            [float(value) for value in rms_dbfs[region_indices]],
            float(context.config.percentile_rms_percentile),
        ) + float(context.config.percentile_rms_margin_db)
        timings["percentile_threshold_computation_sec"] += time.perf_counter() - started

        started = time.perf_counter()
        selected_positions = np.flatnonzero(vad_mask & (rms_dbfs[region_indices] <= rms_threshold))
        selected_indices = region_indices[selected_positions]
        timings["vad_rms_mask_combination_sec"] += time.perf_counter() - started
        if len(selected_indices) == 0:
            trace["all_frames_rejected_by_rms_threshold"] += 1
            diagnostic_rows.append(
                _acoustic_buffer_diagnostic_row(
                    detector_name=detector.name,
                    recording_id=source.recording_id,
                    buffer_id=buffer_id,
                    trusted_duration_sec=trusted_end - trusted_start,
                    region_frames=region_frames,
                    accepted_cutpoint_count=0,
                    trace=trace,
                    config=context.config,
                    use_vad=detector.use_vad,
                    use_rms=detector.use_rms,
                    rms_mode=detector.rms_mode,
                )
            )
            for reason, count in trace.items():
                rejection_rows.append(_detector_trace_row(detector_name=detector.name, recording_id=source.recording_id, buffer_id=buffer_id, reason=reason, count=count))
            continue

        started = time.perf_counter()
        runs: list[tuple[float, float, int, int]] = []
        run_start = float(starts[selected_indices[0]])
        run_end = float(ends[selected_indices[0]])
        first_pos = 0
        last_pos = 0
        for pos, idx in enumerate(selected_indices[1:], start=1):
            frame_start = float(starts[idx])
            frame_end = float(ends[idx])
            if frame_start <= run_end + EPSILON_SEC:
                run_end = max(run_end, frame_end)
                last_pos = pos
            else:
                runs.append((run_start, run_end, first_pos, last_pos))
                run_start = frame_start
                run_end = frame_end
                first_pos = pos
                last_pos = pos
        runs.append((run_start, run_end, first_pos, last_pos))
        timings["quiet_context_computation_sec"] += time.perf_counter() - started

        region_cuts: list[Cutpoint] = []
        for run_index, (run_start, run_end, first_pos, last_pos) in enumerate(runs):
            run_ms = (run_end - run_start) * 1000.0
            if run_ms < context.config.vad_min_run_ms:
                trace["run_below_min_duration"] += 1
                continue
            run_frames = [frames[int(idx)] for idx in selected_indices[first_pos : last_pos + 1]]
            if not run_frames:
                trace["empty_run_after_filters"] += 1
                continue
            started = time.perf_counter()
            region_cuts.append(
                detector._build_cutpoint(
                    detector_name=detector.name,
                    source=source,
                    buffer_id=buffer_id,
                    region_index=region_index,
                    run_index=run_index,
                    is_edge=False,
                    region_frames=region_frames,
                    run_frames=run_frames,
                    run_start=run_start,
                    run_end=run_end,
                )
            )
            timings["candidate_construction_sec"] += time.perf_counter() - started
            trace["accepted_run_cutpoint"] += 1
        if not region_cuts:
            trace["region_produced_zero_cutpoints"] += 1
        cuts.extend(region_cuts)
        diagnostic_rows.append(
            _acoustic_buffer_diagnostic_row(
                detector_name=detector.name,
                recording_id=source.recording_id,
                buffer_id=buffer_id,
                trusted_duration_sec=trusted_end - trusted_start,
                region_frames=region_frames,
                accepted_cutpoint_count=len(region_cuts),
                trace=trace,
                config=context.config,
                use_vad=detector.use_vad,
                use_rms=detector.use_rms,
                rms_mode=detector.rms_mode,
            )
        )
        for reason, count in trace.items():
            rejection_rows.append(_detector_trace_row(detector_name=detector.name, recording_id=source.recording_id, buffer_id=buffer_id, reason=reason, count=count))

    started = time.perf_counter()
    deduped = _dedupe_cutpoints(cuts)
    timings["candidate_deduplication_sec"] += time.perf_counter() - started
    context.benchmark_root.joinpath("tables").mkdir(parents=True, exist_ok=True)
    _append_detector_trace_rows(context.benchmark_root / "tables" / "detector_rejection_trace.csv", rejection_rows)
    _append_acoustic_buffer_diagnostics(
        context.benchmark_root / "tables" / "acoustic_detector_buffer_diagnostics.csv",
        diagnostic_rows,
    )
    context.profiler.setdefault("optimized_vad_percentile_rms_substages", {}).update(
        {key: round(value, 6) for key, value in timings.items()}
    )
    wall = time.perf_counter() - start_wall
    cpu = time.process_time() - start_cpu
    metric = _acoustic_compute_metric(
        detector=detector,
        context=context,
        candidate_generation_sec=wall,
        packing_sec=0.0,
        dependencies=("silero-vad", "audio-rms"),
        notes="Optimized NumPy cutpoint detection; audio feature extraction unchanged.",
    )
    return DetectorRunResult(
        cutpoints=deduped,
        compute_metric=replace(metric, cpu_time_sec=round(cpu, 6)),
        searched_buffer_ids=frozenset(searched_buffer_ids),
        searched_duration_sec=round(
            _buffer_union_duration(buffer_ids=searched_buffer_ids, buffer_by_id=context.buffer_by_id, sources=context.sources),
            6,
        ),
        searched_interval_count=len(searched_buffer_ids),
        uses_asr=False,
        uses_mfa=False,
        uses_aligned_words=False,
        uses_alignment_qc=False,
        validity_notes="Whole-buffer acoustic search over trusted pre-ASR processing buffers only.",
    )


class VadRmsVoicingDetector(AcousticDetector):
    name = "vad_rms_voicing"
    use_vad = True
    use_rms = True
    use_voicing = True


class LocalProminenceRmsDetector(AcousticDetector):
    name = "local_prominence_rms"
    use_rms = True
    cut_placement = "lowest_rms_frame"
    require_vad: bool = False

    def find_cutpoints(self, contexts: BenchmarkContexts) -> DetectorRunResult:
        self._benchmark_config = contexts.acoustic.config
        return super().find_cutpoints(contexts)

    def _cuts_for_region(
        self,
        *,
        detector_name: str,
        source: SourceInfo,
        buffer_id: str,
        region_index: int,
        region_start: float,
        region_end: float,
        is_edge: bool,
        region_frames: list[dict[str, Any]],
        exclude_region_edge_runs: bool = True,
    ) -> tuple[list[Cutpoint], Counter[str]]:
        trace: Counter[str] = Counter()
        trace["regions_seen"] += 1
        config = getattr(self, "_benchmark_config", BenchmarkConfig())
        selected_frames = _local_prominence_frames(region_frames, config, require_vad=self.require_vad)
        if not selected_frames:
            trace["no_frames_meeting_local_prominence_rule"] += 1
            return [], trace
        runs = merge_intervals(
            [(float(row["window_start_sec"]), float(row["window_end_sec"])) for row in selected_frames],
            epsilon_sec=0.0,
        )
        cuts: list[Cutpoint] = []
        for run_index, (run_start, run_end) in enumerate(runs):
            run_ms = (run_end - run_start) * 1000.0
            if run_ms < float(config.vad_min_run_ms):
                trace["local_prominence_run_below_min_duration"] += 1
                continue
            run_frames = [
                row
                for row in selected_frames
                if overlap_duration(float(row["window_start_sec"]), float(row["window_end_sec"]), run_start, run_end) > EPSILON_SEC
            ]
            if not run_frames:
                trace["local_prominence_empty_run"] += 1
                continue
            cut = self._build_cutpoint(
                detector_name=detector_name,
                source=source,
                buffer_id=buffer_id,
                region_index=region_index,
                run_index=run_index,
                is_edge=is_edge,
                region_frames=region_frames,
                run_frames=run_frames,
                run_start=run_start,
                run_end=run_end,
            )
            cut.metadata.update(
                {
                    "local_prominence_context_frames": int(config.local_prominence_context_frames),
                    "local_prominence_absolute_ceiling_dbfs": float(config.local_prominence_absolute_ceiling_dbfs),
                    "local_prominence_min_prominence_db": float(config.local_prominence_min_prominence_db),
                    "local_prominence_require_vad": self.require_vad,
                }
            )
            cuts.append(cut)
            trace["accepted_local_prominence_run_cutpoint"] += 1
        if not cuts:
            trace["region_produced_zero_cutpoints"] += 1
        return cuts, trace


class VadLocalProminenceRmsDetector(LocalProminenceRmsDetector):
    name = "vad_local_prominence_rms"
    require_vad = True


class AdaptiveLocalRmsDetector(AcousticDetector):
    name = "adaptive_local_rms_valleys"
    use_rms = True

    def find_cutpoints(self, contexts: BenchmarkContexts) -> DetectorRunResult:
        self._benchmark_config = contexts.acoustic.config
        return super().find_cutpoints(contexts)

    def _cuts_for_region(
        self,
        *,
        detector_name: str,
        source: SourceInfo,
        buffer_id: str,
        region_index: int,
        region_start: float,
        region_end: float,
        is_edge: bool,
        region_frames: list[dict[str, Any]],
        exclude_region_edge_runs: bool = True,
    ) -> tuple[list[Cutpoint], Counter[str]]:
        trace: Counter[str] = Counter()
        trace["regions_seen"] += 1
        cfg = getattr(self, "_benchmark_config", BenchmarkConfig())
        self.cut_placement = str(cfg.adaptive_rms_cut_placement)
        context_frames = max(1, int(cfg.adaptive_rms_local_context_frames))
        candidate_frames: list[dict[str, Any]] = []
        for index, row in enumerate(region_frames):
            left = max(0, index - context_frames)
            right = min(len(region_frames), index + context_frames + 1)
            neighborhood = region_frames[left:right]
            baseline = statistics.fmean(float(item["rms_dbfs"]) for item in neighborhood)
            rms_dbfs = float(row["rms_dbfs"])
            prominence = baseline - rms_dbfs
            if rms_dbfs <= float(cfg.adaptive_rms_absolute_threshold_dbfs) and prominence >= float(cfg.adaptive_rms_min_prominence_db):
                enriched = dict(row)
                enriched["local_rms_baseline_dbfs"] = round(baseline, 6)
                enriched["local_rms_prominence_db"] = round(prominence, 6)
                candidate_frames.append(enriched)
        if not candidate_frames:
            trace["no_frames_meeting_adaptive_rms_rule"] += 1
            return [], trace
        runs = merge_intervals(
            [(float(row["window_start_sec"]), float(row["window_end_sec"])) for row in candidate_frames],
            epsilon_sec=0.0,
        )
        cuts: list[Cutpoint] = []
        min_duration_ms = float(cfg.adaptive_rms_min_valley_duration_ms)
        for run_index, (run_start, run_end) in enumerate(runs):
            if ((run_end - run_start) * 1000.0) < min_duration_ms:
                trace["adaptive_rms_run_below_min_duration"] += 1
                continue
            run_frames = [
                row
                for row in candidate_frames
                if overlap_duration(float(row["window_start_sec"]), float(row["window_end_sec"]), run_start, run_end) > EPSILON_SEC
            ]
            if not run_frames:
                trace["adaptive_rms_empty_run"] += 1
                continue
            if exclude_region_edge_runs and not self.include_edges:
                touches_left_edge = run_start <= region_start + EPSILON_SEC
                touches_right_edge = run_end >= region_end - EPSILON_SEC
                if touches_left_edge or touches_right_edge:
                    trace["adaptive_rms_run_touches_buffer_edge_excluded"] += 1
                    continue
            cut = self._build_cutpoint(
                detector_name=detector_name,
                source=source,
                buffer_id=buffer_id,
                region_index=region_index,
                run_index=run_index,
                is_edge=is_edge,
                region_frames=region_frames,
                run_frames=run_frames,
                run_start=run_start,
                run_end=run_end,
            )
            prominence = max(float(row.get("local_rms_prominence_db", 0.0)) for row in run_frames)
            cut.metadata.update(
                {
                    "adaptive_local_context_frames": context_frames,
                    "adaptive_min_prominence_db": float(cfg.adaptive_rms_min_prominence_db),
                    "adaptive_absolute_threshold_dbfs": float(cfg.adaptive_rms_absolute_threshold_dbfs),
                    "adaptive_cut_placement": str(cfg.adaptive_rms_cut_placement),
                    "adaptive_max_prominence_db": round(prominence, 6),
                }
            )
            cuts.append(cut)
            trace["accepted_adaptive_rms_run_cutpoint"] += 1
        min_separation_sec = float(cfg.adaptive_rms_min_separation_ms) / 1000.0
        separated: list[Cutpoint] = []
        for cut in sorted(cuts, key=lambda row: (row.time_sec, -row.score, row.cutpoint_id)):
            if not separated or (cut.time_sec - separated[-1].time_sec) >= min_separation_sec - EPSILON_SEC:
                separated.append(cut)
            elif cut.score > separated[-1].score:
                separated[-1] = cut
                trace["adaptive_rms_replaced_close_candidate"] += 1
            else:
                trace["adaptive_rms_rejected_close_candidate"] += 1
        if not separated:
            trace["region_produced_zero_cutpoints"] += 1
        return separated, trace


class RmsVadVetoDetector(AcousticDetector):
    name = "rms_vad_veto"
    use_rms = True
    rms_mode = "percentile"

    def find_cutpoints(self, contexts: BenchmarkContexts) -> DetectorRunResult:
        self._benchmark_config = contexts.acoustic.config
        return super().find_cutpoints(contexts)

    def _cuts_for_region(
        self,
        *,
        detector_name: str,
        source: SourceInfo,
        buffer_id: str,
        region_index: int,
        region_start: float,
        region_end: float,
        is_edge: bool,
        region_frames: list[dict[str, Any]],
        exclude_region_edge_runs: bool = True,
    ) -> tuple[list[Cutpoint], Counter[str]]:
        trace: Counter[str] = Counter()
        trace["regions_seen"] += 1
        rms_values = [float(row["rms_dbfs"]) for row in region_frames]
        if not rms_values:
            trace["no_rms_frames"] += 1
            return [], trace
        cfg = getattr(self, "_benchmark_config", BenchmarkConfig())
        rms_threshold = self._rms_threshold(region_frames, cfg)
        selected_frames = [row for row in region_frames if float(row["rms_dbfs"]) <= rms_threshold]
        if not selected_frames:
            trace["no_frames_below_rms_threshold"] += 1
            return [], trace
        runs = merge_intervals(
            [(float(row["window_start_sec"]), float(row["window_end_sec"])) for row in selected_frames],
            epsilon_sec=0.0,
        )
        cuts: list[Cutpoint] = []
        for run_index, (run_start, run_end) in enumerate(runs):
            run_ms = (run_end - run_start) * 1000.0
            if run_ms < float(cfg.vad_min_run_ms):
                trace["run_below_min_duration"] += 1
                continue
            run_frames = [
                row
                for row in selected_frames
                if overlap_duration(float(row["window_start_sec"]), float(row["window_end_sec"]), run_start, run_end) > EPSILON_SEC
            ]
            if not run_frames:
                trace["empty_run_after_filters"] += 1
                continue
            mean_vad = statistics.fmean(float(row["speech_prob"]) for row in run_frames)
            min_vad = min(float(row["speech_prob"]) for row in run_frames)
            if mean_vad >= float(cfg.rms_vad_veto_mean_threshold) and min_vad >= float(cfg.rms_vad_veto_min_threshold):
                trace["vetoed_by_vad_speech_heavy"] += 1
                continue
            if exclude_region_edge_runs and not self.include_edges:
                touches_left_edge = run_start <= region_start + EPSILON_SEC
                touches_right_edge = run_end >= region_end - EPSILON_SEC
                if touches_left_edge or touches_right_edge:
                    trace["run_touches_buffer_edge_excluded"] += 1
                    continue
            cut = self._build_cutpoint(
                detector_name=detector_name,
                source=source,
                buffer_id=buffer_id,
                region_index=region_index,
                run_index=run_index,
                is_edge=is_edge,
                region_frames=region_frames,
                run_frames=run_frames,
                run_start=run_start,
                run_end=run_end,
            )
            cut.metadata.update(
                {
                    "rms_vad_veto_mean_threshold": float(cfg.rms_vad_veto_mean_threshold),
                    "rms_vad_veto_min_threshold": float(cfg.rms_vad_veto_min_threshold),
                    "run_vad_mean": round(mean_vad, 6),
                    "run_vad_min": round(min_vad, 6),
                }
            )
            cuts.append(cut)
            trace["accepted_rms_vad_veto_run_cutpoint"] += 1
        if not cuts:
            trace["region_produced_zero_cutpoints"] += 1
        return cuts, trace


class WordGapAcousticHybridDetector:
    name = "word_gap_acoustic_hybrid"
    use_single_best_per_region = True

    def find_cutpoints(self, contexts: BenchmarkContexts) -> DetectorRunResult:
        context = contexts.linguistic
        start_wall = time.perf_counter()
        start_cpu = time.process_time()
        cuts: list[Cutpoint] = []
        searched_buffer_ids: set[str] = set()
        rejection_rows: list[dict[str, Any]] = []
        left_guard_sec = float(context.speechcraft_config.get("cutpoint_left_word_edge_guard_ms", 30)) / 1000.0
        right_guard_sec = float(context.speechcraft_config.get("cutpoint_right_word_edge_guard_ms", 30)) / 1000.0
        min_region_sec = float(context.config.vad_min_run_ms) / 1000.0
        for buffer_id, buffer in sorted(context.buffer_by_id.items()):
            words = sorted(context.words_by_buffer.get(buffer_id, []), key=lambda row: float(row["source_start_sec"]))
            if len(words) < 2:
                rejection_rows.append(
                    _detector_trace_row(
                        detector_name=self.name,
                        recording_id=context.sources[str(buffer["source_audio_id"])].recording_id,
                        buffer_id=buffer_id,
                        reason="insufficient_aligned_words",
                        count=1,
                    )
                )
                continue
            source = context.sources[str(buffer["source_audio_id"])]
            features = context.audio_feature_cache[source.recording_id]
            regions = _allowed_regions(
                buffer=buffer,
                words=words,
                left_guard_sec=left_guard_sec,
                right_guard_sec=right_guard_sec,
                min_region_sec=min_region_sec,
                include_edges=False,
                gap_only=True,
            )
            if not regions:
                rejection_rows.append(
                    _detector_trace_row(
                        detector_name=self.name,
                        recording_id=source.recording_id,
                        buffer_id=buffer_id,
                        reason="no_valid_word_gap_regions",
                        count=1,
                    )
                )
                continue
            searched_buffer_ids.add(buffer_id)
            for region_index, (region_start, region_end, is_edge) in enumerate(regions):
                region_frames = _slice_feature_frames(features, region_start, region_end)
                if not region_frames:
                    rejection_rows.append(
                        _detector_trace_row(
                            detector_name=self.name,
                            recording_id=source.recording_id,
                            buffer_id=buffer_id,
                            reason="no_region_frames",
                            count=1,
                        )
                    )
                    continue
                region_cuts, region_trace = VadLocalMinimaDetector()._cuts_for_region(
                    detector_name=self.name,
                    source=source,
                    buffer_id=buffer_id,
                    region_index=region_index,
                    region_start=region_start,
                    region_end=region_end,
                    is_edge=is_edge,
                    region_frames=region_frames,
                    exclude_region_edge_runs=False,
                )
                if region_cuts:
                    region_cuts = region_cuts[:1]
                cuts.extend(region_cuts)
                for reason, count in region_trace.items():
                    rejection_rows.append(
                        _detector_trace_row(
                            detector_name=self.name,
                            recording_id=source.recording_id,
                            buffer_id=buffer_id,
                            reason=reason,
                            count=count,
                        )
                    )
        wall = time.perf_counter() - start_wall
        cpu = time.process_time() - start_cpu
        _append_detector_trace_rows(context.benchmark_root / "tables" / "detector_rejection_trace.csv", rejection_rows)
        metric = _acoustic_compute_metric(
            detector=VadLocalMinimaDetector(),
            context=contexts.acoustic,
            candidate_generation_sec=wall,
            packing_sec=0.0,
            dependencies=("silero-vad",),
            notes="Aligned-word-gap hybrid; candidate space depends on MFA-aligned word gaps.",
        )
        metric = ComputeMetric(**{**asdict(metric), "detector_name": self.name})
        return DetectorRunResult(
            cutpoints=_dedupe_cutpoints(cuts),
            compute_metric=metric,
            searched_buffer_ids=frozenset(searched_buffer_ids),
            searched_duration_sec=round(
                _buffer_union_duration(buffer_ids=searched_buffer_ids, buffer_by_id=context.buffer_by_id, sources=context.sources),
                6,
            ),
            searched_interval_count=len(searched_buffer_ids),
            uses_asr=True,
            uses_mfa=True,
            uses_aligned_words=True,
            uses_alignment_qc=False,
            validity_notes="Hybrid gap selector searches MFA-aligned word gaps only; not ASR-free.",
        )


class UnionDetector:
    def __init__(self, name: str, components: tuple[CutpointDetector, ...]) -> None:
        self.name = name
        self.components = components

    def find_cutpoints(self, contexts: BenchmarkContexts) -> DetectorRunResult:
        all_cuts: list[Cutpoint] = []
        wall = 0.0
        cpu = 0.0
        peak_rss = 0.0
        dependencies: list[str] = []
        notes: list[str] = []
        searched_buffer_ids: set[str] = set()
        uses_asr = False
        uses_mfa = False
        uses_aligned_words = False
        uses_alignment_qc = False
        for detector in self.components:
            result = detector.find_cutpoints(contexts)
            metric = result.compute_metric
            all_cuts.extend(result.cutpoints)
            wall += metric.wall_clock_sec
            cpu += metric.cpu_time_sec
            peak_rss = max(peak_rss, metric.peak_rss_mb or 0.0)
            dependencies.extend(metric.external_model_dependencies)
            searched_buffer_ids.update(result.searched_buffer_ids)
            uses_asr = uses_asr or result.uses_asr
            uses_mfa = uses_mfa or result.uses_mfa
            uses_aligned_words = uses_aligned_words or result.uses_aligned_words
            uses_alignment_qc = uses_alignment_qc or result.uses_alignment_qc
            if metric.notes:
                notes.append(f"{detector.name}: {metric.notes}")
            if result.validity_notes:
                notes.append(f"{detector.name}: {result.validity_notes}")
        deduped = [
            Cutpoint(
                detector_name=self.name,
                source_id=cut.source_id,
                recording_id=cut.recording_id,
                buffer_id=cut.buffer_id,
                cutpoint_id=f"{self.name}:{cut.cutpoint_id}",
                time_sec=cut.time_sec,
                interval_start_sec=cut.interval_start_sec,
                interval_end_sec=cut.interval_end_sec,
                score=cut.score,
                vad_min=cut.vad_min,
                vad_mean=cut.vad_mean,
                vad_longest_below_0_1_ms=cut.vad_longest_below_0_1_ms,
                vad_longest_below_0_2_ms=cut.vad_longest_below_0_2_ms,
                rms_min_dbfs=cut.rms_min_dbfs,
                rms_mean_dbfs=cut.rms_mean_dbfs,
                voicing_min=cut.voicing_min,
                voicing_mean=cut.voicing_mean,
                compute_time_sec=0.0,
                is_buffer_edge_candidate=cut.is_buffer_edge_candidate,
                metadata={**cut.metadata, "component_detector": cut.detector_name},
            )
            for cut in all_cuts
        ]
        metric = ComputeMetric(
            detector_name=self.name,
            wall_clock_sec=round(wall, 6),
            cpu_time_sec=round(cpu, 6),
            gpu_time_sec=None,
            peak_rss_mb=peak_rss or None,
            peak_gpu_memory_mb=None,
            real_time_factor=_safe_divide(wall, _total_source_duration(contexts.shared.sources)),
            model_init_time_sec=0.0,
            per_hour_audio_cost_sec=_safe_divide(3600.0 * wall, _total_source_duration(contexts.shared.sources)),
            external_model_dependencies=tuple(sorted(set(dependencies))),
            notes="; ".join(notes),
        )
        searched_duration_sec = _buffer_union_duration(
            buffer_ids=searched_buffer_ids,
            buffer_by_id=contexts.shared.buffer_by_id,
            sources=contexts.shared.sources,
        )
        return DetectorRunResult(
            cutpoints=_dedupe_cutpoints(deduped),
            compute_metric=metric,
            searched_buffer_ids=frozenset(searched_buffer_ids),
            searched_duration_sec=round(searched_duration_sec, 6),
            searched_interval_count=len(searched_buffer_ids),
            uses_asr=uses_asr,
            uses_mfa=uses_mfa,
            uses_aligned_words=uses_aligned_words,
            uses_alignment_qc=uses_alignment_qc,
            validity_notes="Union detector combines component candidate sets before packing.",
        )


class GreedyPacker:
    name = "greedy"

    def pack(
        self,
        *,
        duration_sec: float,
        cutpoints: list[Cutpoint],
        constraints: PackingConstraints,
    ) -> list[Clip]:
        del duration_sec
        candidates, _ = _generate_legal_candidate_clips(cutpoints=cutpoints, constraints=constraints)
        selected: list[CandidateClip] = []
        for _, rows in sorted(_group_candidate_clips_by_recording(candidates).items()):
            ordered = sorted(
                rows,
                key=lambda row: (
                    row.start_sec,
                    abs(row.duration_sec - constraints.target_clip_sec),
                    row.end_sec,
                    row.candidate_id,
                ),
            )
            current_end = float("-inf")
            for candidate in ordered:
                if constraints.allow_overlap:
                    if selected and candidate.start_sec < current_end - constraints.max_overlap_sec - EPSILON_SEC:
                        continue
                elif candidate.start_sec < current_end - EPSILON_SEC:
                    continue
                selected.append(candidate)
                current_end = max(current_end, candidate.end_sec)
        _assert_candidate_schedule(selected, max_overlap_sec=constraints.max_overlap_sec if constraints.allow_overlap else 0.0)
        return _clips_from_candidates(selected, packer_name=self.name)


class OptimalWeightedIntervalPacker:
    name = "optimal_weighted_interval"

    def pack(
        self,
        *,
        duration_sec: float,
        cutpoints: list[Cutpoint],
        constraints: PackingConstraints,
    ) -> list[Clip]:
        del duration_sec
        candidates, _ = _generate_legal_candidate_clips(cutpoints=cutpoints, constraints=constraints)
        selected: list[CandidateClip] = []
        for _, rows in sorted(_group_candidate_clips_by_recording(candidates).items()):
            selected.extend(
                _weighted_interval_schedule_candidate_clips(
                    rows,
                    max_overlap_sec=constraints.max_overlap_sec if constraints.allow_overlap else 0.0,
                )
            )
        _assert_candidate_schedule(selected, max_overlap_sec=constraints.max_overlap_sec if constraints.allow_overlap else 0.0)
        return _clips_from_candidates(selected, packer_name=self.name)


def run_slicer_daddy_test(
    *,
    eval_run: Path,
    normalized_speaker_dir: Path,
    out_root: Path,
) -> Path:
    reference_words = _read_csv(normalized_speaker_dir / "reference_words.csv")
    reference_phones = _read_csv(normalized_speaker_dir / "reference_phones.csv")
    sources = _load_sources(eval_run / "speechcraft_run" / "artifacts" / "source_audio_manifest.json")
    buffers = _read_json(eval_run / "speechcraft_run" / "artifacts" / "processing_buffers.json")
    queue_rows = _read_json(eval_run / "speechcraft_run" / "artifacts" / "asr_mfa_queue.json")
    aligned_words = read_jsonl(eval_run / "speechcraft_run" / "artifacts" / "aligned_words.jsonl")
    alignment_qc = _read_json(eval_run / "speechcraft_run" / "artifacts" / "alignment_qc_by_buffer.json")
    safe_cutpoints = read_jsonl(eval_run / "speechcraft_run" / "artifacts" / "safe_cutpoints.jsonl")
    candidate_review_manifest = _read_json(eval_run / "speechcraft_run" / "artifacts" / "candidate_review_manifest.json")
    speechcraft_config = read_json(eval_run / "speechcraft_run" / "config.json")
    runtime_versions = read_json(eval_run / "speechcraft_run" / "runtime_versions.json")
    status_json = read_json(eval_run / "speechcraft_run" / "status.json")
    dataset_log = eval_run / "speechcraft_run" / "logs" / "dataset_worker.log"

    lexical_words_by_recording = {
        key: [row for row in rows if _as_bool(row["is_lexical_word"])]
        for key, rows in _group_by(reference_words, "recording_id").items()
    }
    speech_phones_by_recording = {
        key: [row for row in rows if _as_bool(row["is_speech_phone"])]
        for key, rows in _group_by(reference_phones, "recording_id").items()
    }
    corrected_safe_regions = _build_corrected_safe_regions(
        _build_reference_safe_regions(
            _group_by(reference_words, "recording_id"),
            _group_by(reference_phones, "recording_id"),
        )
    )
    corrected_safe_regions_by_recording = _group_by(corrected_safe_regions, "recording_id")

    buffer_by_id = {str(row["buffer_id"]): row for row in buffers}
    queue_by_id = {str(row["buffer_id"]): row for row in queue_rows}
    qc_by_buffer = {str(row["buffer_id"]): row for row in alignment_qc}
    words_by_buffer = _group_by(aligned_words, "buffer_id")
    current_cuts_by_buffer = _group_by(safe_cutpoints, "buffer_id")

    stage_durations = _read_stage_durations_from_log(dataset_log)
    speaker_id = normalized_speaker_dir.name
    benchmark_name = f"{_timestamp_now()}_buckeye_{speaker_id}_slicer_daddy_test"
    output_root = out_root / benchmark_name
    if output_root.exists():
        raise FileExistsError(f"benchmark output directory already exists: {output_root}")
    tables_dir = output_root / "tables"
    metrics_dir = output_root / "metrics"
    audit_dir = output_root / "audit_audio"
    code_dir = output_root / "code_snapshot"
    for path in (tables_dir, metrics_dir, audit_dir, code_dir):
        path.mkdir(parents=True, exist_ok=True)

    config = BenchmarkConfig()
    frame_index_by_recording = {
        recording_id: _index_frames(frames)
        for recording_id, frames in _compute_recording_vad_frames(sources, metrics_dir / "vad_frame_cache").items()
    }
    audio_feature_cache = _build_audio_feature_cache(
        sources=sources,
        frame_index_by_recording=frame_index_by_recording,
        cache_dir=metrics_dir / "audio_feature_cache",
    )
    profiler = _profile_detector_pipelines(
        sources=sources,
        audio_feature_cache=audio_feature_cache,
        output_root=output_root,
    )

    shared_context = DetectorContext(
        eval_run=eval_run,
        normalized_speaker_dir=normalized_speaker_dir,
        benchmark_root=output_root,
        config=config,
        sources=sources,
        buffer_by_id=buffer_by_id,
        lexical_words_by_recording=lexical_words_by_recording,
        speech_phones_by_recording=speech_phones_by_recording,
        corrected_safe_regions=corrected_safe_regions,
        reference_words=reference_words,
        reference_phones=reference_phones,
    )
    acoustic_context = AcousticDetectorContext(
        benchmark_root=output_root,
        config=config,
        sources=sources,
        buffer_by_id=buffer_by_id,
        audio_feature_cache=audio_feature_cache,
        profiler=profiler,
    )
    linguistic_context = LinguisticDetectorContext(
        benchmark_root=output_root,
        config=config,
        speechcraft_config=speechcraft_config,
        sources=sources,
        buffer_by_id=buffer_by_id,
        queue_by_id=queue_by_id,
        qc_by_buffer=qc_by_buffer,
        words_by_buffer=words_by_buffer,
        current_cuts_by_buffer=current_cuts_by_buffer,
        candidate_review_manifest=candidate_review_manifest,
        audio_feature_cache=audio_feature_cache,
        stage_durations_sec=stage_durations,
        profiler=profiler,
    )
    contexts = BenchmarkContexts(
        shared=shared_context,
        acoustic=acoustic_context,
        linguistic=linguistic_context,
    )

    detectors: list[CutpointDetector] = [
        CurrentProductionDetector(),
        VadLocalMinimaDetector(),
        RmsMinimaDetector(),
        VadRmsDetector(),
        PercentileRmsDetector(),
        VadPercentileRmsDetector(),
        LocalProminenceRmsDetector(),
        VadLocalProminenceRmsDetector(),
        VadRmsVoicingDetector(),
        AdaptiveLocalRmsDetector(),
        RmsVadVetoDetector(),
        WordGapAcousticHybridDetector(),
        UnionDetector("current_plus_vad_union", (CurrentProductionDetector(), VadLocalMinimaDetector())),
        UnionDetector(
            "current_plus_vad_plus_buffer_edge",
            (CurrentProductionDetector(), _EdgeVadDetector()),
        ),
    ]
    packers: list[ClipPacker] = [GreedyPacker(), OptimalWeightedIntervalPacker()]

    cutpoints_by_detector: dict[str, list[Cutpoint]] = {}
    detector_results: dict[str, DetectorRunResult] = {}
    compute_rows: list[dict[str, Any]] = []
    evaluator = SlicerEvaluator(shared_context)
    coverage_rows: list[dict[str, Any]] = []
    shape_rows: list[dict[str, Any]] = []
    duplication_rows: list[dict[str, Any]] = []
    boundary_rows: list[dict[str, Any]] = []
    severity_rows: list[dict[str, Any]] = []
    safe_region_rows: list[dict[str, Any]] = []
    clip_rows: list[dict[str, Any]] = []
    packing_rows: list[dict[str, Any]] = []

    total_audio_sec = _total_source_duration(sources)

    for detector in detectors:
        result = detector.find_cutpoints(contexts)
        detector_results[detector.name] = result
        cutpoints_by_detector[detector.name] = result.cutpoints
        compute_rows.append(
            _compute_metric_row(
                result,
                total_audio_sec,
                len(buffer_by_id),
                _buffer_union_duration(buffer_ids=set(buffer_by_id), buffer_by_id=buffer_by_id, sources=sources),
            )
        )
    write_json(
        metrics_dir / "detector_run_context.json",
        {
            name: {
                "searched_buffer_ids": sorted(result.searched_buffer_ids),
                "searched_duration_sec": result.searched_duration_sec,
                "searched_interval_count": result.searched_interval_count,
                "uses_asr": result.uses_asr,
                "uses_mfa": result.uses_mfa,
                "uses_aligned_words": result.uses_aligned_words,
                "uses_alignment_qc": result.uses_alignment_qc,
                "validity_notes": result.validity_notes,
            }
            for name, result in detector_results.items()
        },
    )

    _validate_current_baseline(
        benchmark_root=output_root,
        eval_run=eval_run,
        cutpoints=cutpoints_by_detector["current_production"],
        corrected_safe_regions=corrected_safe_regions,
        buffer_by_id=buffer_by_id,
        sources=sources,
        lexical_words_by_recording=lexical_words_by_recording,
        speech_phones_by_recording=speech_phones_by_recording,
    )

    all_cutpoint_rows: list[dict[str, Any]] = []
    for detector_name, cuts in cutpoints_by_detector.items():
        for cut in cuts:
            all_cutpoint_rows.append(_cutpoint_row(cut))

    constraints = PackingConstraints(
        min_clip_sec=config.min_clip_sec,
        preferred_min_sec=config.preferred_min_sec,
        preferred_max_sec=config.preferred_max_sec,
        target_clip_sec=config.target_clip_sec,
        max_clip_sec=config.max_clip_sec,
        allow_overlap=config.allow_overlap,
        max_overlap_sec=config.max_overlap_sec,
        max_duplication_ratio=config.max_duplication_ratio,
        eligible_regions_by_recording=_eligible_regions_by_recording(
            buffer_ids=set(buffer_by_id),
            buffer_by_id=buffer_by_id,
            sources=sources,
        ),
    )

    for detector in detectors:
        result = detector_results[detector.name]
        cuts = result.cutpoints
        operational_buffers = set(result.searched_buffer_ids)
        for packer in packers:
            pack_started = time.perf_counter()
            candidate_clips, deduped_candidate_clip_count = _generate_legal_candidate_clips(
                cutpoints=cuts,
                constraints=constraints,
            )
            raw_candidate_clip_count = len(candidate_clips) + deduped_candidate_clip_count
            if raw_candidate_clip_count - len(candidate_clips) != deduped_candidate_clip_count:
                raise ValueError("candidate clip deduplication count does not reconcile")
            clips = packer.pack(duration_sec=total_audio_sec, cutpoints=cuts, constraints=constraints)
            pack_elapsed = time.perf_counter() - pack_started
            clip_rows.extend(_clip_rows_from_clips(clips))
            metrics = evaluator.evaluate(
                detector_name=detector.name,
                packer_name=packer.name,
                clips=clips,
                cutpoints=cuts,
                operational_buffers=operational_buffers,
            )
            coverage_rows.extend(metrics["coverage"])
            shape_rows.extend(metrics["shape"])
            duplication_rows.extend(metrics["duplication"])
            boundary_rows.extend(metrics["boundary_safety"])
            severity_rows.extend(metrics["boundary_severity"])
            safe_region_rows.extend(metrics["safe_region_recall"])
            packing_rows.append(
                _packing_summary_row(
                    detector_name=detector.name,
                    packer_name=packer.name,
                    cuts=cuts,
                    clips=clips,
                    coverage_rows=metrics["coverage"],
                    shape_row=metrics["shape"][0],
                    duplication_row=metrics["duplication"][0],
                    boundary_rows=metrics["boundary_safety"],
                    pack_elapsed_sec=pack_elapsed,
                    candidate_clip_count=len(candidate_clips),
                    candidate_clips_deduplicated_count=deduped_candidate_clip_count,
                )
            )

    scorecard_rows = _build_detector_scorecard(
        coverage_rows=coverage_rows,
        shape_rows=shape_rows,
        duplication_rows=duplication_rows,
        safe_region_rows=safe_region_rows,
        boundary_rows=boundary_rows,
        severity_rows=severity_rows,
        compute_rows=compute_rows,
        detector_results=detector_results,
        config=config,
    )
    pareto_rows = _build_pareto_frontier(scorecard_rows)
    listening_index_rows, listening_decode_rows = _build_listening_audit(
        output_root=output_root,
        clips_all=_rows_to_clips(clip_rows),
        boundary_rows=boundary_rows,
        reference_words_by_recording=lexical_words_by_recording,
        reference_phones_by_recording=speech_phones_by_recording,
        sources=sources,
        sample_per_bucket=config.listening_sample_per_bucket,
        seed=config.deterministic_seed,
    )

    write_csv(tables_dir / "cutpoints_all_detectors.csv", all_cutpoint_rows, fieldnames=list(all_cutpoint_rows[0].keys()))
    write_csv(tables_dir / "clips_all_detectors.csv", clip_rows, fieldnames=list(clip_rows[0].keys()))
    write_csv(tables_dir / "coverage_metrics.csv", coverage_rows, fieldnames=list(coverage_rows[0].keys()))
    write_csv(tables_dir / "clip_shape_metrics.csv", shape_rows, fieldnames=list(shape_rows[0].keys()))
    write_csv(tables_dir / "duplication_metrics.csv", duplication_rows, fieldnames=list(duplication_rows[0].keys()))
    write_csv(tables_dir / "boundary_safety_all_stages.csv", boundary_rows, fieldnames=list(boundary_rows[0].keys()))
    write_csv(tables_dir / "boundary_severity.csv", severity_rows, fieldnames=list(severity_rows[0].keys()))
    write_csv(tables_dir / "safe_region_recall.csv", safe_region_rows, fieldnames=list(safe_region_rows[0].keys()))
    write_csv(tables_dir / "packing_comparison.csv", packing_rows, fieldnames=list(packing_rows[0].keys()))
    write_csv(tables_dir / "compute_metrics.csv", compute_rows, fieldnames=list(compute_rows[0].keys()))
    write_csv(tables_dir / "detector_scorecard.csv", scorecard_rows, fieldnames=list(scorecard_rows[0].keys()))
    write_csv(tables_dir / "pareto_frontier.csv", pareto_rows, fieldnames=list(pareto_rows[0].keys()))
    actual_production_rows = _actual_production_clip_rows(
        candidate_review_manifest=candidate_review_manifest,
        sources=sources,
    )
    if actual_production_rows:
        write_csv(tables_dir / "actual_production_clips.csv", actual_production_rows, fieldnames=list(actual_production_rows[0].keys()))
    write_csv(tables_dir / "LISTENING_AUDIT_INDEX.csv", listening_index_rows, fieldnames=list(listening_index_rows[0].keys()))
    write_csv(tables_dir / "LISTENING_AUDIT_DECODE_KEY.csv", listening_decode_rows, fieldnames=list(listening_decode_rows[0].keys()))

    provenance = _write_provenance(
        output_root=output_root,
        eval_run=eval_run,
        normalized_speaker_dir=normalized_speaker_dir,
        speechcraft_config=speechcraft_config,
        runtime_versions=runtime_versions,
        status_json=status_json,
        benchmark_config=config,
    )
    _snapshot_code(output_root=output_root)
    _write_reports(
        output_root=output_root,
        scorecard_rows=scorecard_rows,
        packing_rows=packing_rows,
        compute_rows=compute_rows,
        baseline_eval_run=eval_run,
        provenance=provenance,
    )
    _write_test_results(output_root)
    review_zip = _zip_review_bundle(output_root)
    write_json(metrics_dir / "review_bundle.json", {"zip_path": str(review_zip)})
    return output_root


class _EdgeVadDetector(VadLocalMinimaDetector):
    name = "vad_local_minima_with_edges"
    include_edges = True


def _allowed_regions(
    *,
    buffer: dict[str, Any],
    words: list[dict[str, Any]],
    left_guard_sec: float,
    right_guard_sec: float,
    min_region_sec: float,
    include_edges: bool,
    gap_only: bool,
) -> list[tuple[float, float, bool]]:
    regions: list[tuple[float, float, bool]] = []
    trusted_start = float(buffer["trusted_start_sec"])
    trusted_end = float(buffer["trusted_end_sec"])
    if include_edges and words:
        left_end = float(words[0]["source_start_sec"]) - left_guard_sec
        if left_end - trusted_start >= min_region_sec:
            regions.append((trusted_start, left_end, True))
    if words:
        for left_word, right_word in zip(words, words[1:]):
            start = float(left_word["source_end_sec"]) + left_guard_sec
            end = float(right_word["source_start_sec"]) - right_guard_sec
            if end - start >= min_region_sec:
                regions.append((start, end, False))
    if include_edges and words:
        right_start = float(words[-1]["source_end_sec"]) + right_guard_sec
        if trusted_end - right_start >= min_region_sec:
            regions.append((right_start, trusted_end, True))
    if gap_only:
        return regions
    return regions


def _candidate_score(
    *,
    speech_prob: float,
    rms_dbfs: float,
    voicing_score: float,
    use_vad: bool,
    use_rms: bool,
    use_voicing: bool,
) -> float:
    score = 0.0
    if use_vad:
        score += (1.0 - speech_prob)
    if use_rms:
        score += max(0.0, min(1.0, (-rms_dbfs) / 100.0))
    if use_voicing:
        score += (1.0 - voicing_score)
    return score


def _percentile_value(values: list[float], percentile: float) -> float:
    if not values:
        raise ValueError("cannot compute percentile of an empty list")
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    rank = (len(ordered) - 1) * (percentile / 100.0)
    low = math.floor(rank)
    high = math.ceil(rank)
    if low == high:
        return ordered[int(rank)]
    return ordered[low] + (ordered[high] - ordered[low]) * (rank - low)


def _legacy_rms_threshold(frames: list[dict[str, Any]], config: BenchmarkConfig) -> float:
    return min(float(row["rms_dbfs"]) for row in frames) + float(config.legacy_rms_min_margin_db)


def _percentile_rms_threshold(frames: list[dict[str, Any]], config: BenchmarkConfig) -> float:
    values = [float(row["rms_dbfs"]) for row in frames]
    return _percentile_value(values, float(config.percentile_rms_percentile)) + float(config.percentile_rms_margin_db)


def _local_prominence_frames(
    frames: list[dict[str, Any]],
    config: BenchmarkConfig,
    *,
    require_vad: bool,
) -> list[dict[str, Any]]:
    context_frames = max(1, int(config.local_prominence_context_frames))
    selected: list[dict[str, Any]] = []
    for index, row in enumerate(frames):
        if require_vad and float(row["speech_prob"]) >= float(config.vad_threshold):
            continue
        left = max(0, index - context_frames)
        right = min(len(frames), index + context_frames + 1)
        neighborhood = frames[left:right]
        baseline = _percentile_value([float(item["rms_dbfs"]) for item in neighborhood], 60.0)
        rms_dbfs = float(row["rms_dbfs"])
        prominence = baseline - rms_dbfs
        if (
            rms_dbfs <= float(config.local_prominence_absolute_ceiling_dbfs)
            and prominence >= float(config.local_prominence_min_prominence_db)
        ):
            enriched = dict(row)
            enriched["local_rms_baseline_dbfs"] = round(baseline, 6)
            enriched["local_rms_prominence_db"] = round(prominence, 6)
            selected.append(enriched)
    return selected


def _detector_trace_row(
    *,
    detector_name: str,
    recording_id: str,
    buffer_id: str,
    reason: str,
    count: int,
) -> dict[str, Any]:
    return {
        "detector_name": detector_name,
        "recording_id": recording_id,
        "buffer_id": buffer_id,
        "reason": reason,
        "count": count,
    }


def _append_detector_trace_rows(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    existing: list[dict[str, Any]] = []
    if path.exists():
        existing = _read_csv(path)
    existing.extend(rows)
    write_csv(path, existing, fieldnames=["detector_name", "recording_id", "buffer_id", "reason", "count"])


def _append_acoustic_buffer_diagnostics(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    existing: list[dict[str, Any]] = []
    if path.exists():
        existing = _read_csv(path)
    existing.extend(rows)
    write_csv(path, existing, fieldnames=list(existing[0].keys()))


def _acoustic_buffer_diagnostic_row(
    *,
    detector_name: str,
    recording_id: str,
    buffer_id: str,
    trusted_duration_sec: float,
    region_frames: list[dict[str, Any]],
    accepted_cutpoint_count: int,
    trace: Counter[str],
    config: BenchmarkConfig,
    use_vad: bool,
    use_rms: bool,
    rms_mode: str,
) -> dict[str, Any]:
    rms_values = [float(row["rms_dbfs"]) for row in region_frames]
    vad_frames = [row for row in region_frames if float(row["speech_prob"]) < float(config.vad_threshold)]
    if rms_values:
        legacy_threshold = _legacy_rms_threshold(region_frames, config)
        percentile_threshold = _percentile_rms_threshold(region_frames, config)
        rms_threshold = percentile_threshold if rms_mode == "percentile" else legacy_threshold
    else:
        legacy_threshold = percentile_threshold = rms_threshold = None
    rms_frames = [] if rms_threshold is None else [row for row in region_frames if float(row["rms_dbfs"]) <= float(rms_threshold)]
    intersection_frames = [] if rms_threshold is None else [
        row
        for row in region_frames
        if float(row["speech_prob"]) < float(config.vad_threshold)
        and float(row["rms_dbfs"]) <= float(rms_threshold)
    ]
    return {
        "detector_name": detector_name,
        "recording_id": recording_id,
        "buffer_id": buffer_id,
        "trusted_duration_sec": round(trusted_duration_sec, 6),
        "frame_count": len(region_frames),
        "rms_min_dbfs": None if not rms_values else round(min(rms_values), 6),
        "rms_p01_dbfs": None if not rms_values else round(_percentile_value(rms_values, 1.0), 6),
        "rms_p05_dbfs": None if not rms_values else round(_percentile_value(rms_values, 5.0), 6),
        "rms_p10_dbfs": None if not rms_values else round(_percentile_value(rms_values, 10.0), 6),
        "rms_median_dbfs": None if not rms_values else round(statistics.median(rms_values), 6),
        "rms_p90_dbfs": None if not rms_values else round(_percentile_value(rms_values, 90.0), 6),
        "legacy_rms_threshold_dbfs": None if legacy_threshold is None else round(legacy_threshold, 6),
        "percentile_rms_threshold_dbfs": None if percentile_threshold is None else round(percentile_threshold, 6),
        "computed_rms_threshold_dbfs": None if rms_threshold is None else round(rms_threshold, 6),
        "frames_below_vad_threshold": len(vad_frames),
        "frames_below_rms_threshold": len(rms_frames),
        "frames_satisfying_both": len(intersection_frames),
        "longest_vad_only_run_ms": round(_longest_frame_run_ms(vad_frames), 6),
        "longest_rms_only_run_ms": round(_longest_frame_run_ms(rms_frames), 6),
        "longest_intersection_run_ms": round(_longest_frame_run_ms(intersection_frames), 6),
        "accepted_cutpoint_count": accepted_cutpoint_count,
        "uses_vad": use_vad,
        "uses_rms": use_rms,
        "rms_mode": rms_mode,
        "rejection_reason_counts_json": json.dumps(dict(sorted(trace.items())), sort_keys=True),
    }


def _longest_frame_run_ms(frames: list[dict[str, Any]]) -> float:
    if not frames:
        return 0.0
    runs = merge_intervals(
        [(float(row["window_start_sec"]), float(row["window_end_sec"])) for row in frames],
        epsilon_sec=0.0,
    )
    return max((end - start) * 1000.0 for start, end in runs) if runs else 0.0


def _acoustic_compute_metric(
    *,
    detector: AcousticDetector,
    context: DetectorContext,
    candidate_generation_sec: float,
    packing_sec: float,
    dependencies: tuple[str, ...],
    notes: str,
) -> ComputeMetric:
    profile = context.profiler.get(detector.name, {})
    cold_total = sum(
        value
        for key, value in profile.items()
        if key.startswith("cold_") and isinstance(value, (int, float))
    )
    warm_total = sum(
        value
        for key, value in profile.items()
        if key.startswith("warm_") and isinstance(value, (int, float))
    )
    wall = cold_total if cold_total > 0 else candidate_generation_sec
    return ComputeMetric(
        detector_name=detector.name,
        wall_clock_sec=round(wall, 6),
        cpu_time_sec=round(candidate_generation_sec, 6),
        gpu_time_sec=None,
        peak_rss_mb=None,
        peak_gpu_memory_mb=None,
        real_time_factor=_safe_divide(wall, _total_source_duration(context.sources)),
        model_init_time_sec=profile.get("cold_vad_model_load_sec"),
        per_hour_audio_cost_sec=_safe_divide(3600.0 * wall, _total_source_duration(context.sources)),
        external_model_dependencies=dependencies,
        notes=((notes + "; ") if notes else "") + "Peak RSS unavailable for fair per-detector comparison in shared-process mode.",
        cold_audio_decode_sec=profile.get("cold_audio_decode_sec"),
        cold_rms_extraction_sec=profile.get("cold_rms_extraction_sec"),
        cold_vad_model_load_sec=profile.get("cold_vad_model_load_sec"),
        cold_vad_inference_sec=profile.get("cold_vad_inference_sec"),
        cold_voicing_extraction_sec=profile.get("cold_voicing_extraction_sec"),
        cold_candidate_generation_sec=round(candidate_generation_sec, 6),
        cold_packing_sec=packing_sec,
        warm_audio_decode_sec=profile.get("warm_audio_decode_sec"),
        warm_rms_extraction_sec=profile.get("warm_rms_extraction_sec"),
        warm_vad_model_load_sec=profile.get("warm_vad_model_load_sec"),
        warm_vad_inference_sec=profile.get("warm_vad_inference_sec"),
        warm_voicing_extraction_sec=profile.get("warm_voicing_extraction_sec"),
        warm_candidate_generation_sec=round(candidate_generation_sec, 6),
        warm_packing_sec=packing_sec,
    )


def _dedupe_cutpoints(cuts: list[Cutpoint]) -> list[Cutpoint]:
    grouped: dict[tuple[str, int], list[Cutpoint]] = defaultdict(list)
    for cut in cuts:
        key = (cut.recording_id, int(round(cut.time_sec * 1000.0)))
        grouped[key].append(cut)
    deduped: list[Cutpoint] = []
    for _, rows in grouped.items():
        best = max(
            rows,
            key=lambda cut: (
                cut.score,
                -len(cut.buffer_id),
                cut.buffer_id,
                cut.cutpoint_id,
            ),
        )
        scores = [float(row.score) for row in rows]
        metadata = dict(best.metadata)
        metadata.update(
            {
                "dedupe_representative_cutpoint_id": best.cutpoint_id,
                "contributing_buffer_ids": sorted({row.buffer_id for row in rows}),
                "contributing_cutpoint_ids": sorted(row.cutpoint_id for row in rows),
                "support_count": len(rows),
                "score_max": round(max(scores), 6),
                "score_mean": round(statistics.fmean(scores), 6),
                "score_min": round(min(scores), 6),
            }
        )
        deduped.append(replace(best, metadata=metadata))
    return sorted(deduped, key=lambda row: (row.recording_id, row.time_sec, row.cutpoint_id))


def _actual_production_clip_rows(
    *,
    candidate_review_manifest: list[dict[str, Any]],
    sources: dict[str, SourceInfo],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for row in candidate_review_manifest:
        source = sources.get(str(row.get("source_audio_id")))
        if source is None:
            raise ValueError(f"production clip references unknown source_audio_id: {row.get('source_audio_id')}")
        sample_rate = float(row.get("sample_rate") or source.sample_rate)
        start_sec = float(row["source_start_sample"]) / sample_rate
        end_sec = float(row["source_end_sample"]) / sample_rate
        rows.append(
            {
                "baseline_name": "actual_production_emitted_clip",
                "clip_id": row["id"],
                "source_id": source.source_audio_id,
                "recording_id": source.recording_id,
                "buffer_id": row.get("buffer_id", ""),
                "start_sec": round(start_sec, 6),
                "end_sec": round(end_sec, 6),
                "duration_sec": round(end_sec - start_sec, 6),
                "start_cutpoint_ref": row.get("start_cutpoint_ref", ""),
                "end_cutpoint_ref": row.get("end_cutpoint_ref", ""),
                "status": row.get("status", ""),
                "needs_review": row.get("needs_review", ""),
                "audio_path": row.get("audio_path", ""),
            }
        )
    return sorted(rows, key=lambda item: (item["recording_id"], item["start_sec"], item["clip_id"]))


def _clip_weight(*, duration_sec: float, target_clip_sec: float) -> float:
    return duration_sec - (abs(duration_sec - target_clip_sec) * 0.5)


def _candidate_clip_weight(
    *,
    duration_sec: float,
    constraints: PackingConstraints,
) -> float:
    if constraints.preferred_min_sec <= duration_sec <= constraints.preferred_max_sec:
        return 10.0 - ((constraints.target_clip_sec - duration_sec) * 1.5)
    if duration_sec > constraints.preferred_max_sec:
        return 6.5 - max(0.0, duration_sec - 9.0)
    return duration_sec / max(constraints.min_clip_sec, EPSILON_SEC)


def _eligible_regions_by_recording(
    *,
    buffer_ids: set[str],
    buffer_by_id: dict[str, dict[str, Any]],
    sources: dict[str, SourceInfo],
) -> dict[str, tuple[tuple[float, float], ...]]:
    intervals_by_recording: dict[str, list[tuple[float, float]]] = defaultdict(list)
    for buffer_id in buffer_ids:
        buffer = buffer_by_id[buffer_id]
        source = sources[str(buffer["source_audio_id"])]
        intervals_by_recording[source.recording_id].append(
            (float(buffer["trusted_start_sec"]), float(buffer["trusted_end_sec"]))
        )
    return {
        recording_id: tuple(merge_intervals(intervals))
        for recording_id, intervals in intervals_by_recording.items()
    }


def _eligible_region_for_span(
    *,
    recording_id: str,
    start_sec: float,
    end_sec: float,
    constraints: PackingConstraints,
) -> tuple[float, float] | None:
    if recording_id not in constraints.eligible_regions_by_recording:
        raise ValueError(f"missing eligible regions for recording {recording_id}")
    regions = constraints.eligible_regions_by_recording[recording_id]
    if not regions:
        raise ValueError(f"empty eligible regions for recording {recording_id}")
    for region_start, region_end in regions:
        if start_sec >= region_start - EPSILON_SEC and end_sec <= region_end + EPSILON_SEC:
            return region_start, region_end
    return None


def _group_candidate_clips_by_recording(
    candidates: list[CandidateClip],
) -> dict[str, list[CandidateClip]]:
    grouped: dict[str, list[CandidateClip]] = defaultdict(list)
    for candidate in candidates:
        grouped[candidate.recording_id].append(candidate)
    return grouped


def _generate_legal_candidate_clips(
    *,
    cutpoints: list[Cutpoint],
    constraints: PackingConstraints,
) -> tuple[list[CandidateClip], int]:
    by_recording: dict[str, list[Cutpoint]] = defaultdict(list)
    for cut in cutpoints:
        by_recording[cut.recording_id].append(cut)
    candidates: list[CandidateClip] = []
    for _, rows in sorted(by_recording.items()):
        ordered = sorted(rows, key=lambda row: (row.time_sec, row.cutpoint_id))
        times = [row.time_sec for row in ordered]
        for start_index, start in enumerate(ordered[:-1]):
            min_end_index = bisect_left(times, start.time_sec + constraints.min_clip_sec, lo=start_index + 1)
            max_end_index = bisect_right(times, start.time_sec + constraints.max_clip_sec, lo=min_end_index)
            for end_index in range(min_end_index, max_end_index):
                end = ordered[end_index]
                duration = end.time_sec - start.time_sec
                eligible_region = _eligible_region_for_span(
                    recording_id=start.recording_id,
                    start_sec=start.time_sec,
                    end_sec=end.time_sec,
                    constraints=constraints,
                )
                if eligible_region is None:
                    continue
                candidates.append(
                    CandidateClip(
                        detector_name=start.detector_name,
                        source_id=start.source_id,
                        recording_id=start.recording_id,
                        buffer_id=f"{start.buffer_id}|{end.buffer_id}",
                        candidate_id=f"{start.detector_name}:{start.recording_id}:{start.cutpoint_id}:{end.cutpoint_id}",
                        start_sec=round(start.time_sec, 6),
                        end_sec=round(end.time_sec, 6),
                        duration_sec=round(duration, 6),
                        start_cutpoint_id=start.cutpoint_id,
                        end_cutpoint_id=end.cutpoint_id,
                        weight=round(_candidate_clip_weight(duration_sec=duration, constraints=constraints), 6),
                    )
                )
    deduped = _dedupe_candidate_clips(candidates)
    return deduped, len(candidates) - len(deduped)


def _dedupe_candidate_clips(candidates: list[CandidateClip]) -> list[CandidateClip]:
    by_key: dict[tuple[str, int, int], CandidateClip] = {}
    for candidate in candidates:
        key = (
            candidate.recording_id,
            int(round(candidate.start_sec * 1000.0)),
            int(round(candidate.end_sec * 1000.0)),
        )
        existing = by_key.get(key)
        if existing is None:
            by_key[key] = candidate
            continue
        if (
            candidate.weight > existing.weight + 1e-12
            or (
                abs(candidate.weight - existing.weight) <= 1e-12
                and (
                    candidate.buffer_id,
                    candidate.start_cutpoint_id,
                    candidate.end_cutpoint_id,
                    candidate.candidate_id,
                )
                < (
                    existing.buffer_id,
                    existing.start_cutpoint_id,
                    existing.end_cutpoint_id,
                    existing.candidate_id,
                )
            )
        ):
            by_key[key] = candidate
    return sorted(
        by_key.values(),
        key=lambda row: (row.recording_id, row.start_sec, row.end_sec, row.buffer_id, row.candidate_id),
    )


def _clips_from_candidates(candidates: list[CandidateClip], *, packer_name: str) -> list[Clip]:
    clips: list[Clip] = []
    for clip_index, candidate in enumerate(candidates):
        clips.append(
            Clip(
                detector_name=candidate.detector_name,
                packer_name=packer_name,
                source_id=candidate.source_id,
                recording_id=candidate.recording_id,
                buffer_id=candidate.buffer_id,
                clip_id=f"{candidate.detector_name}-{packer_name}-clip-{clip_index:06d}",
                start_sec=candidate.start_sec,
                end_sec=candidate.end_sec,
                duration_sec=candidate.duration_sec,
                start_cutpoint_id=candidate.start_cutpoint_id,
                end_cutpoint_id=candidate.end_cutpoint_id,
                selected_weight=candidate.weight,
                selected_boundary_count=2,
            )
        )
    return clips


def _weighted_interval_schedule_general(
    candidates: list[dict[str, Any]],
    *,
    max_overlap_sec: float,
) -> list[dict[str, Any]]:
    ordered = sorted(candidates, key=lambda row: (float(row["end_sec"]), float(row["start_sec"])))
    if not ordered:
        return []
    ends = [float(row["end_sec"]) for row in ordered]
    prev_compatible: list[int] = []
    for row in ordered:
        compatible_index = -1
        for index in range(len(ordered) - 1, -1, -1):
            if float(ordered[index]["end_sec"]) <= float(row["start_sec"]) + max_overlap_sec + EPSILON_SEC:
                compatible_index = index
                break
        prev_compatible.append(compatible_index)
    best = [0.0] * (len(ordered) + 1)
    for i, row in enumerate(ordered, start=1):
        include = float(row["weight"]) + best[prev_compatible[i - 1] + 1]
        exclude = best[i - 1]
        best[i] = max(include, exclude)
    selected: list[dict[str, Any]] = []
    i = len(ordered)
    while i > 0:
        row = ordered[i - 1]
        include = float(row["weight"]) + best[prev_compatible[i - 1] + 1]
        if include >= best[i - 1] - 1e-12:
            selected.append(row)
            i = prev_compatible[i - 1] + 1
        else:
            i -= 1
    selected.reverse()
    _assert_schedule(selected, max_overlap_sec=max_overlap_sec)
    return selected


def _weighted_interval_schedule_candidate_clips(
    candidates: list[CandidateClip],
    *,
    max_overlap_sec: float,
) -> list[CandidateClip]:
    selected = _weighted_interval_schedule_general(
        [
            {
                "candidate": candidate,
                "start_sec": candidate.start_sec,
                "end_sec": candidate.end_sec,
                "weight": candidate.weight,
            }
            for candidate in candidates
        ],
        max_overlap_sec=max_overlap_sec,
    )
    return [row["candidate"] for row in selected]


def _assert_candidate_schedule(candidates: list[CandidateClip], *, max_overlap_sec: float) -> None:
    by_recording: dict[str, list[CandidateClip]] = defaultdict(list)
    for candidate in candidates:
        by_recording[candidate.recording_id].append(candidate)
    for rows in by_recording.values():
        ordered = sorted(rows, key=lambda row: (row.start_sec, row.end_sec, row.candidate_id))
        for left, right in zip(ordered, ordered[1:]):
            overlap = overlap_duration(left.start_sec, left.end_sec, right.start_sec, right.end_sec)
            if overlap > max_overlap_sec + EPSILON_SEC:
                raise ValueError("selected candidate clips overlap within a recording")


def _weighted_interval_schedule_from_cutpoints(
    ordered: list[Cutpoint],
    *,
    constraints: PackingConstraints,
) -> list[tuple[Cutpoint, Cutpoint, float]]:
    if not ordered:
        return []
    if constraints.allow_overlap and constraints.max_overlap_sec > 0.0:
        candidates: list[dict[str, Any]] = []
        for start_index, start in enumerate(ordered[:-1]):
            for end in ordered[start_index + 1 :]:
                duration = end.time_sec - start.time_sec
                if duration < constraints.min_clip_sec:
                    continue
                if duration > constraints.max_clip_sec:
                    break
                candidates.append(
                    {
                        "start_cutpoint": start,
                        "end_cutpoint": end,
                        "start_sec": start.time_sec,
                        "end_sec": end.time_sec,
                        "weight": _clip_weight(duration_sec=duration, target_clip_sec=constraints.target_clip_sec),
                    }
                )
        selected = _weighted_interval_schedule_general(candidates, max_overlap_sec=constraints.max_overlap_sec)
        return [
            (row["start_cutpoint"], row["end_cutpoint"], float(row["weight"]))
            for row in selected
        ]
    times = [cut.time_sec for cut in ordered]
    n = len(ordered)
    dp = [0.0] * (n + 1)
    choice: list[tuple[int, int] | None] = [None] * (n + 1)
    for end_index in range(1, n):
        best_value = dp[end_index]
        best_choice: tuple[int, int] | None = None
        end_cut = ordered[end_index]
        min_start_index = bisect_left(times, end_cut.time_sec - constraints.max_clip_sec, 0, end_index)
        max_start_index = bisect_right(times, end_cut.time_sec - constraints.min_clip_sec, min_start_index, end_index) - 1
        if min_start_index <= max_start_index:
            for start_index in range(min_start_index, max_start_index + 1):
                start_cut = ordered[start_index]
                duration = end_cut.time_sec - start_cut.time_sec
                value = dp[start_index + 1] + _clip_weight(duration_sec=duration, target_clip_sec=constraints.target_clip_sec)
                if value > best_value + 1e-12:
                    best_value = value
                    best_choice = (start_index, end_index)
        dp[end_index + 1] = best_value
        choice[end_index + 1] = best_choice
    selected_pairs: list[tuple[Cutpoint, Cutpoint, float]] = []
    index = n
    while index > 0:
        pair = choice[index]
        if pair is None:
            index -= 1
            continue
        start_index, end_index = pair
        if dp[index] <= dp[index - 1] + 1e-12:
            index -= 1
            continue
        start_cut = ordered[start_index]
        end_cut = ordered[end_index]
        duration = end_cut.time_sec - start_cut.time_sec
        selected_pairs.append((start_cut, end_cut, _clip_weight(duration_sec=duration, target_clip_sec=constraints.target_clip_sec)))
        index = start_index + 1
    selected_pairs.reverse()
    _assert_schedule(
        [
            {"start_sec": start.time_sec, "end_sec": end.time_sec}
            for start, end, _ in selected_pairs
        ],
        max_overlap_sec=0.0,
    )
    return selected_pairs


def _assert_schedule(rows: list[dict[str, Any]], *, max_overlap_sec: float) -> None:
    for left, right in zip(rows, rows[1:]):
        overlap = overlap_duration(
            float(left["start_sec"]),
            float(left["end_sec"]),
            float(right["start_sec"]),
            float(right["end_sec"]),
        )
        if overlap > max_overlap_sec + EPSILON_SEC:
            raise ValueError("selected clips exceed configured overlap")


def _compute_coverage_metrics(
    *,
    detector_name: str,
    packer_name: str,
    clips: list[Clip],
    lexical_words_by_recording: dict[str, list[dict[str, Any]]],
    speech_phones_by_recording: dict[str, list[dict[str, Any]]],
    sources: dict[str, SourceInfo],
) -> list[dict[str, Any]]:
    clip_intervals_by_recording = _clip_intervals_by_recording(clips)
    source_duration = _total_source_duration(sources)
    clip_union = sum(_interval_union_duration(intervals) for intervals in clip_intervals_by_recording.values())
    emitted_sum = sum(clip.duration_sec for clip in clips)
    word_reference = {
        rid: [(float(row["start_sec"]), float(row["end_sec"])) for row in rows]
        for rid, rows in lexical_words_by_recording.items()
    }
    phone_reference = {
        rid: [(float(row["start_sec"]), float(row["end_sec"])) for row in rows]
        for rid, rows in speech_phones_by_recording.items()
    }
    word_unique, word_repeated = _reference_coverage_stats(word_reference, clip_intervals_by_recording)
    phone_unique, phone_repeated = _reference_coverage_stats(phone_reference, clip_intervals_by_recording)
    total_words = sum(end - start for intervals in word_reference.values() for start, end in merge_intervals(intervals))
    total_phones = sum(end - start for intervals in phone_reference.values() for start, end in merge_intervals(intervals))
    return [
        {
            "detector_name": detector_name,
            "packer_name": packer_name,
            "raw_timeline_union_coverage": round(_safe_divide(clip_union, source_duration), 6),
            "emitted_duration_ratio": round(_safe_divide(emitted_sum, source_duration), 6),
            "reference_lexical_word_coverage": round(_safe_divide(word_unique, total_words), 6),
            "reference_speech_phone_coverage": round(_safe_divide(phone_unique, total_phones), 6),
            "total_source_duration_sec": round(source_duration, 6),
            "total_reference_lexical_word_sec": round(total_words, 6),
            "total_reference_speech_phone_sec": round(total_phones, 6),
            "unique_reference_lexical_word_speech_sec": round(word_unique, 6),
            "repeated_reference_lexical_word_speech_sec": round(word_repeated, 6),
            "unique_reference_speech_phone_sec": round(phone_unique, 6),
            "repeated_reference_speech_phone_sec": round(phone_repeated, 6),
            "clip_union_duration_sec": round(clip_union, 6),
            "clip_emitted_sum_sec": round(emitted_sum, 6),
        }
    ]


def _clip_shape_metrics(
    *,
    detector_name: str,
    packer_name: str,
    clips: list[Clip],
    config: BenchmarkConfig,
) -> dict[str, Any]:
    durations = sorted(clip.duration_sec for clip in clips)
    histogram = Counter(_duration_bucket(value) for value in durations)
    preferred_count = sum(config.preferred_min_sec <= value <= config.preferred_max_sec for value in durations)
    return {
        "detector_name": detector_name,
        "packer_name": packer_name,
        "clip_count": len(clips),
        "preferred_clip_count": preferred_count,
        "total_emitted_duration_sec": round(sum(durations), 6),
        "median_duration_sec": _stat_or_none(durations, statistics.median),
        "mean_duration_sec": _stat_or_none(durations, statistics.fmean),
        "p10_duration_sec": _percentile(durations, 10),
        "p25_duration_sec": _percentile(durations, 25),
        "p75_duration_sec": _percentile(durations, 75),
        "p90_duration_sec": _percentile(durations, 90),
        "minimum_duration_sec": None if not durations else durations[0],
        "maximum_duration_sec": None if not durations else durations[-1],
        "pct_inside_preferred_range": round(
            _safe_divide(preferred_count, len(durations)),
            6,
        ),
        "pct_below_3_sec": round(_safe_divide(sum(value < config.min_clip_sec for value in durations), len(durations)), 6),
        "pct_above_15_sec": round(_safe_divide(sum(value > config.max_clip_sec for value in durations), len(durations)), 6),
        "duration_histogram_json": json.dumps(dict(sorted(histogram.items()))),
    }


def _duplication_metrics(*, detector_name: str, packer_name: str, clips: list[Clip]) -> dict[str, Any]:
    intervals_by_recording = _clip_intervals_by_recording(clips)
    union_duration = sum(_interval_union_duration(intervals) for intervals in intervals_by_recording.values())
    total_duration = sum(clip.duration_sec for clip in clips)
    pair_count = 0
    gt80 = gt90 = gt95 = 0
    shifted_pairs = 0
    for recording_id in sorted(intervals_by_recording):
        recording_clips = [clip for clip in clips if clip.recording_id == recording_id]
        for index, left in enumerate(recording_clips):
            for right in recording_clips[index + 1 :]:
                pair_count += 1
                overlap = overlap_duration(left.start_sec, left.end_sec, right.start_sec, right.end_sec)
                if overlap <= EPSILON_SEC:
                    continue
                ratio = overlap / min(left.duration_sec, right.duration_sec)
                if ratio >= 0.8:
                    gt80 += 1
                if ratio >= 0.9:
                    gt90 += 1
                if ratio >= 0.95:
                    gt95 += 1
                if abs(left.start_sec - right.start_sec) <= 0.1 or abs(left.end_sec - right.end_sec) <= 0.1:
                    shifted_pairs += 1
    return {
        "detector_name": detector_name,
        "packer_name": packer_name,
        "union_duration_sec": round(union_duration, 6),
        "emitted_duration_sum_sec": round(total_duration, 6),
        "duplication_ratio": round(_safe_divide(total_duration, union_duration), 6),
        "pair_count": pair_count,
        "pair_overlap_gt_80_count": gt80,
        "pair_overlap_gt_80_rate": round(_safe_divide(gt80, pair_count), 6),
        "pair_overlap_gt_90_count": gt90,
        "pair_overlap_gt_90_rate": round(_safe_divide(gt90, pair_count), 6),
        "pair_overlap_gt_95_count": gt95,
        "pair_overlap_gt_95_rate": round(_safe_divide(gt95, pair_count), 6),
        "small_boundary_shift_pair_count": shifted_pairs,
    }


def _boundary_safety_rows(
    *,
    detector_name: str,
    packer_name: str,
    cutpoints: list[Cutpoint],
    clips: list[Clip],
    lexical_words_by_recording: dict[str, list[dict[str, Any]]],
    speech_phones_by_recording: dict[str, list[dict[str, Any]]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    selected_cut_ids = {clip.start_cutpoint_id for clip in clips} | {clip.end_cutpoint_id for clip in clips}
    cut_by_id = {cut.cutpoint_id: cut for cut in cutpoints}
    boundary_rows: list[dict[str, Any]] = []
    severity_rows: list[dict[str, Any]] = []
    stages: list[tuple[str, list[tuple[str, str, float, str, Cutpoint | None]]]] = [
        (
            "proposed_cutpoints",
            [("proposed", cut.cutpoint_id, cut.time_sec, cut.recording_id, cut) for cut in cutpoints],
        ),
        (
            "selected_cutpoints",
            [("selected", cut_id, cut_by_id[cut_id].time_sec, cut_by_id[cut_id].recording_id, cut_by_id[cut_id]) for cut_id in sorted(selected_cut_ids) if cut_id in cut_by_id],
        ),
        (
            "final_emitted_boundaries",
            [
                ("clip_start", clip.start_cutpoint_id, clip.start_sec, clip.recording_id, cut_by_id.get(clip.start_cutpoint_id))
                for clip in clips
            ]
            + [
                ("clip_end", clip.end_cutpoint_id, clip.end_sec, clip.recording_id, cut_by_id.get(clip.end_cutpoint_id))
                for clip in clips
            ],
        ),
    ]
    for stage, items in stages:
        stats_rows: list[dict[str, Any]] = []
        for boundary_side, boundary_id, time_sec, recording_id, cut in items:
            lexical_words = lexical_words_by_recording.get(recording_id, [])
            speech_phones = speech_phones_by_recording.get(recording_id, [])
            word = _find_strict_interval(lexical_words, time_sec)
            phone = _find_strict_interval(speech_phones, time_sec)
            prev_phone = _last_interval_before(speech_phones, time_sec)
            next_phone = _first_interval_after(speech_phones, time_sec)
            prev_word = _last_interval_before(lexical_words, time_sec)
            next_word = _first_interval_after(lexical_words, time_sec)
            _, _, nearest_phone_ms = _phone_clearances_ms(
                time_sec,
                overlapping_phone=phone,
                prev_phone=prev_phone,
                next_phone=next_phone,
            )
            word_depth = _depth_inside_interval(word, time_sec)
            phone_depth = _depth_inside_interval(phone, time_sec)
            before_word_sec = 0.0 if word is None else time_sec - float(word["start_sec"])
            after_word_sec = 0.0 if word is None else float(word["end_sec"]) - time_sec
            word_duration_sec = 0.0 if word is None else float(word["end_sec"]) - float(word["start_sec"])
            if boundary_side == "clip_start":
                discarded_fraction = _safe_divide(before_word_sec, word_duration_sec)
                preserved_fraction = _safe_divide(after_word_sec, word_duration_sec)
            elif boundary_side == "clip_end":
                discarded_fraction = _safe_divide(after_word_sec, word_duration_sec)
                preserved_fraction = _safe_divide(before_word_sec, word_duration_sec)
            else:
                discarded_fraction = None
                preserved_fraction = None
            stats_rows.append(
                {
                    "detector_name": detector_name,
                    "packer_name": packer_name,
                    "stage": stage,
                    "boundary_side": boundary_side,
                    "boundary_id": boundary_id,
                    "recording_id": recording_id,
                    "buffer_id": "" if cut is None else cut.buffer_id,
                    "time_sec": round(time_sec, 6),
                    "inside_reference_word": word is not None,
                    "inside_reference_phone": phone is not None,
                    "containing_word": "" if word is None else word["normalized_label"],
                    "containing_phone": "" if phone is None else phone["normalized_label"],
                    "nearest_word_edge_distance_sec": _nearest_edge_distance(word, time_sec),
                    "nearest_phone_edge_distance_sec": None if nearest_phone_ms is None or math.isinf(nearest_phone_ms) else round(nearest_phone_ms / 1000.0, 6),
                    "depth_inside_word_sec": word_depth,
                    "depth_inside_phone_sec": phone_depth,
                    "amount_of_word_before_cut_sec": round(before_word_sec, 6),
                    "amount_of_word_after_cut_sec": round(after_word_sec, 6),
                    "discarded_word_fraction": discarded_fraction,
                    "preserved_word_fraction": preserved_fraction,
                    "guard_10ms_violation": bool(phone is not None) or (nearest_phone_ms is not None and nearest_phone_ms < 10.0),
                    "guard_20ms_violation": bool(phone is not None) or (nearest_phone_ms is not None and nearest_phone_ms < 20.0),
                    "guard_50ms_violation": bool(phone is not None) or (nearest_phone_ms is not None and nearest_phone_ms < 50.0),
                    "guard_100ms_violation": bool(phone is not None) or (nearest_phone_ms is not None and nearest_phone_ms < 100.0),
                }
            )
        boundary_rows.extend(stats_rows)
        for side in sorted({row["boundary_side"] for row in stats_rows} | {"all"}):
            scope = stats_rows if side == "all" else [row for row in stats_rows if row["boundary_side"] == side]
            depths_word = [float(row["depth_inside_word_sec"]) for row in scope if row["depth_inside_word_sec"] is not None]
            depths_phone = [float(row["depth_inside_phone_sec"]) for row in scope if row["depth_inside_phone_sec"] is not None]
            severity_rows.append(
                {
                    "detector_name": detector_name,
                    "packer_name": packer_name,
                    "stage": stage,
                    "boundary_side": side,
                    "boundary_count": len(scope),
                    "inside_word_count": sum(bool(row["inside_reference_word"]) for row in scope),
                    "inside_phone_count": sum(bool(row["inside_reference_phone"]) for row in scope),
                    "guard_10ms_violation_count": sum(bool(row["guard_10ms_violation"]) for row in scope),
                    "guard_20ms_violation_count": sum(bool(row["guard_20ms_violation"]) for row in scope),
                    "guard_50ms_violation_count": sum(bool(row["guard_50ms_violation"]) for row in scope),
                    "guard_100ms_violation_count": sum(bool(row["guard_100ms_violation"]) for row in scope),
                    "inside_word_rate": round(_safe_divide(sum(bool(row["inside_reference_word"]) for row in scope), len(scope)), 6),
                    "inside_phone_rate": round(_safe_divide(sum(bool(row["inside_reference_phone"]) for row in scope), len(scope)), 6),
                    "median_word_leak_depth_sec": _stat_or_none(depths_word, statistics.median),
                    "p90_word_leak_depth_sec": _percentile(depths_word, 90),
                    "p95_word_leak_depth_sec": _percentile(depths_word, 95),
                    "maximum_word_leak_depth_sec": None if not depths_word else max(depths_word),
                    "median_phone_leak_depth_sec": _stat_or_none(depths_phone, statistics.median),
                    "p90_phone_leak_depth_sec": _percentile(depths_phone, 90),
                    "p95_phone_leak_depth_sec": _percentile(depths_phone, 95),
                    "maximum_phone_leak_depth_sec": None if not depths_phone else max(depths_phone),
                    "count_word_depth_gt_10ms": sum(depth > 0.01 for depth in depths_word),
                    "count_word_depth_gt_20ms": sum(depth > 0.02 for depth in depths_word),
                    "count_word_depth_gt_50ms": sum(depth > 0.05 for depth in depths_word),
                    "count_word_depth_gt_100ms": sum(depth > 0.1 for depth in depths_word),
                    "count_phone_depth_gt_10ms": sum(depth > 0.01 for depth in depths_phone),
                    "count_phone_depth_gt_20ms": sum(depth > 0.02 for depth in depths_phone),
                    "count_phone_depth_gt_50ms": sum(depth > 0.05 for depth in depths_phone),
                    "count_phone_depth_gt_100ms": sum(depth > 0.1 for depth in depths_phone),
                }
            )
    return boundary_rows, severity_rows


def _safe_region_recall_rows(
    *,
    detector_name: str,
    cutpoints: list[Cutpoint],
    corrected_safe_regions: list[dict[str, Any]],
    operational_buffers: set[str],
    buffer_by_id: dict[str, dict[str, Any]],
    sources: dict[str, SourceInfo],
    min_region_ms_values: tuple[int, ...],
) -> list[dict[str, Any]]:
    points_by_recording: dict[str, list[float]] = defaultdict(list)
    operational_ranges_by_recording: dict[str, list[tuple[float, float]]] = defaultdict(list)
    for cut in cutpoints:
        points_by_recording[cut.recording_id].append(cut.time_sec)
    for buffer_id in operational_buffers:
        buffer = buffer_by_id[buffer_id]
        source = sources[str(buffer["source_audio_id"])]
        operational_ranges_by_recording[source.recording_id].append(
            (float(buffer["trusted_start_sec"]), float(buffer["trusted_end_sec"]))
        )
    rows: list[dict[str, Any]] = []
    for policy in ("strict", "moderate"):
        policy_field = f"{policy}_eligible"
        for min_region_ms in min_region_ms_values:
            eligible = [
                row
                for row in corrected_safe_regions
                if _as_bool(row[policy_field]) and float(row["duration_ms"]) >= float(min_region_ms)
            ]
            detected = [
                row
                for row in eligible
                if any(float(row["start_sec"]) < point < float(row["end_sec"]) for point in points_by_recording.get(str(row["recording_id"]), []))
            ]
            eligible_operational = [
                row
                for row in eligible
                if any(
                    overlap_duration(start, end, float(row["start_sec"]), float(row["end_sec"])) > EPSILON_SEC
                    for start, end in operational_ranges_by_recording.get(str(row["recording_id"]), [])
                )
            ]
            detected_operational = [
                row
                for row in eligible_operational
                if any(float(row["start_sec"]) < point < float(row["end_sec"]) for point in points_by_recording.get(str(row["recording_id"]), []))
            ]
            rows.append(
                {
                    "detector_name": detector_name,
                    "policy": policy,
                    "min_region_ms": min_region_ms,
                    "eligible_safe_region_count": len(eligible),
                    "detected_safe_region_count": len(detected),
                    "safe_region_recall_all": round(_safe_divide(len(detected), len(eligible)), 6),
                    "eligible_operational_safe_region_count": len(eligible_operational),
                    "detected_operational_safe_region_count": len(detected_operational),
                    "safe_region_recall_operational": round(_safe_divide(len(detected_operational), len(eligible_operational)), 6),
                    "missed_safe_region_count_all": len(eligible) - len(detected),
                    "missed_safe_region_count_operational": len(eligible_operational) - len(detected_operational),
                }
            )
    return rows


def _packing_summary_row(
    *,
    detector_name: str,
    packer_name: str,
    cuts: list[Cutpoint],
    clips: list[Clip],
    coverage_rows: list[dict[str, Any]],
    shape_row: dict[str, Any],
    duplication_row: dict[str, Any],
    boundary_rows: list[dict[str, Any]],
    pack_elapsed_sec: float,
    candidate_clip_count: int,
    candidate_clips_deduplicated_count: int,
) -> dict[str, Any]:
    coverage = coverage_rows[0]
    final_boundaries = [row for row in boundary_rows if row["stage"] == "final_emitted_boundaries"]
    return {
        "detector_name": detector_name,
        "packer_name": packer_name,
        "candidate_count": len(cuts),
        "candidate_clip_count": candidate_clip_count,
        "candidate_clips_deduplicated_count": candidate_clips_deduplicated_count,
        "selected_cutpoint_count": len({clip.start_cutpoint_id for clip in clips} | {clip.end_cutpoint_id for clip in clips}),
        "clip_count": len(clips),
        "unique_reference_speech_phone_sec": coverage["unique_reference_speech_phone_sec"],
        "raw_timeline_union_coverage": coverage["raw_timeline_union_coverage"],
        "preferred_duration_rate": shape_row["pct_inside_preferred_range"],
        "duplication_ratio": duplication_row["duplication_ratio"],
        "selected_boundary_inside_word_rate": round(_safe_divide(sum(bool(row["inside_reference_word"]) for row in final_boundaries), len(final_boundaries)), 6),
        "selected_boundary_inside_phone_rate": round(_safe_divide(sum(bool(row["inside_reference_phone"]) for row in final_boundaries), len(final_boundaries)), 6),
        "selected_boundary_median_phone_leak_depth_sec": _stat_or_none(
            [float(row["depth_inside_phone_sec"]) for row in final_boundaries if row["depth_inside_phone_sec"] is not None],
            statistics.median,
        ),
        "packing_wall_clock_sec": round(pack_elapsed_sec, 6),
    }


def _build_detector_scorecard(
    *,
    coverage_rows: list[dict[str, Any]],
    shape_rows: list[dict[str, Any]],
    duplication_rows: list[dict[str, Any]],
    safe_region_rows: list[dict[str, Any]],
    boundary_rows: list[dict[str, Any]],
    severity_rows: list[dict[str, Any]],
    compute_rows: list[dict[str, Any]],
    detector_results: dict[str, DetectorRunResult],
    config: BenchmarkConfig,
) -> list[dict[str, Any]]:
    coverage_map = {(row["detector_name"], row["packer_name"]): row for row in coverage_rows}
    shape_map = {(row["detector_name"], row["packer_name"]): row for row in shape_rows}
    duplication_map = {(row["detector_name"], row["packer_name"]): row for row in duplication_rows}
    compute_map = {row["detector_name"]: row for row in compute_rows}
    safe_region_map = {
        (row["detector_name"], row["policy"], row["min_region_ms"]): row
        for row in safe_region_rows
    }
    severity_map = {
        (row["detector_name"], row["packer_name"], row["stage"], row["boundary_side"]): row
        for row in severity_rows
    }
    keys = sorted(coverage_map)
    rows: list[dict[str, Any]] = []
    for detector_name, packer_name in keys:
        coverage = coverage_map[(detector_name, packer_name)]
        shape = shape_map[(detector_name, packer_name)]
        duplication = duplication_map[(detector_name, packer_name)]
        safe_region = safe_region_map[(detector_name, "strict", 40)]
        severity = severity_map[(detector_name, packer_name, "final_emitted_boundaries", "all")]
        compute = compute_map[detector_name]
        detector_run = detector_results[detector_name]
        invalid_reasons: list[str] = []
        if float(shape["clip_count"]) < config.minimum_clips_for_pareto:
            invalid_reasons.append("zero_clips")
        if float(coverage["reference_speech_phone_coverage"]) <= 0.0:
            invalid_reasons.append("zero_coverage")
        if float(severity["boundary_count"]) < config.minimum_boundaries_for_pareto:
            invalid_reasons.append("too_few_boundaries")
        rows.append(
            {
                "detector_name": detector_name,
                "packer_name": packer_name,
                "total_source_duration_sec": coverage.get("total_source_duration_sec"),
                "total_reference_lexical_word_sec": coverage.get("total_reference_lexical_word_sec"),
                "total_reference_speech_phone_sec": coverage.get("total_reference_speech_phone_sec"),
                "clip_union_duration_sec": coverage.get("clip_union_duration_sec"),
                "clip_emitted_sum_sec": coverage.get("clip_emitted_sum_sec"),
                "unique_reference_speech_phone_sec": coverage["unique_reference_speech_phone_sec"],
                "unique_reference_lexical_word_speech_sec": coverage.get("unique_reference_lexical_word_speech_sec"),
                "reference_speech_phone_coverage": coverage["reference_speech_phone_coverage"],
                "reference_lexical_word_coverage": coverage.get("reference_lexical_word_coverage"),
                "raw_timeline_union_coverage": coverage["raw_timeline_union_coverage"],
                "emitted_duration_ratio": coverage["emitted_duration_ratio"],
                "clip_count": shape["clip_count"],
                "preferred_clip_count": shape.get("preferred_clip_count"),
                "preferred_duration_rate": shape["pct_inside_preferred_range"],
                "boundary_count": severity["boundary_count"],
                "inside_word_count": severity.get("inside_word_count"),
                "inside_phone_count": severity.get("inside_phone_count"),
                "duplication_ratio": duplication["duplication_ratio"],
                "eligible_safe_region_count": safe_region.get("eligible_safe_region_count"),
                "detected_safe_region_count": safe_region.get("detected_safe_region_count"),
                "safe_region_recall_strict_40ms": safe_region["safe_region_recall_all"],
                "selected_boundary_inside_word_rate": severity["inside_word_rate"],
                "selected_boundary_inside_phone_rate": severity["inside_phone_rate"],
                "median_phone_leak_depth_sec": severity["median_phone_leak_depth_sec"],
                "p95_phone_leak_depth_sec": severity["p95_phone_leak_depth_sec"],
                "audible_clipping_rate": None,
                "real_time_factor": compute["real_time_factor"],
                "peak_rss_mb": compute["peak_rss_mb"],
                "uses_asr": detector_run.uses_asr,
                "uses_mfa": detector_run.uses_mfa,
                "uses_aligned_words": detector_run.uses_aligned_words,
                "uses_alignment_qc": detector_run.uses_alignment_qc,
                "searched_buffer_count": detector_run.searched_interval_count,
                "searched_duration_sec": detector_run.searched_duration_sec,
                "searched_duration_ratio": round(_safe_divide(detector_run.searched_duration_sec, compute["total_pre_asr_buffer_duration_sec"]), 6),
                "validity_notes": detector_run.validity_notes,
                "valid_for_pareto": len(invalid_reasons) == 0,
                "invalid_reason_codes": json.dumps(invalid_reasons),
            }
        )
    return rows


def _build_pareto_frontier(scorecard_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for row in scorecard_rows:
        if not _as_bool(row["valid_for_pareto"]):
            rows.append(
                {
                    **row,
                    "pareto_optimal_pre_perceptual": False,
                    "pareto_basis": "excluded_invalid_configuration",
                }
            )
            continue
        dominated = False
        for other in scorecard_rows:
            if other is row:
                continue
            if not _as_bool(other["valid_for_pareto"]):
                continue
            if (
                float(other["reference_speech_phone_coverage"]) >= float(row["reference_speech_phone_coverage"])
                and float(other["selected_boundary_inside_phone_rate"]) <= float(row["selected_boundary_inside_phone_rate"])
                and float(other["real_time_factor"]) <= float(row["real_time_factor"])
                and (
                    float(other["reference_speech_phone_coverage"]) > float(row["reference_speech_phone_coverage"])
                    or float(other["selected_boundary_inside_phone_rate"]) < float(row["selected_boundary_inside_phone_rate"])
                    or float(other["real_time_factor"]) < float(row["real_time_factor"])
                )
            ):
                dominated = True
                break
        rows.append(
            {
                **row,
                "pareto_optimal_pre_perceptual": not dominated,
                "pareto_basis": "maximize_coverage_minimize_inside_phone_rate_minimize_rtf",
            }
        )
    return rows


def _build_audio_feature_cache(
    *,
    sources: dict[str, SourceInfo],
    frame_index_by_recording: dict[str, dict[str, Any]],
    cache_dir: Path,
) -> dict[str, dict[str, Any]]:
    import numpy as np
    import soundfile as sf

    cache_dir.mkdir(parents=True, exist_ok=True)
    results: dict[str, dict[str, Any]] = {}
    for source in sources.values():
        cache_path = cache_dir / f"{source.recording_id}.json"
        samples, sample_rate = sf.read(str(source.path), dtype="float32", always_2d=False)
        audio = np.asarray(samples, dtype=np.float32)
        frames = []
        for row in frame_index_by_recording[source.recording_id]["frames"]:
            start = max(0, int(round(float(row["window_start_sec"]) * sample_rate)))
            end = min(len(audio), int(round(float(row["window_end_sec"]) * sample_rate)))
            chunk = audio[start:end]
            if len(chunk) == 0:
                rms = 0.0
                zcr = 0.0
            else:
                rms = float(np.sqrt(np.mean(np.square(chunk), dtype=np.float64)))
                signs = np.signbit(chunk)
                zcr = float(np.mean(signs[1:] != signs[:-1])) if len(chunk) > 1 else 0.0
            rms_dbfs = -120.0 if rms <= 1e-8 else float(20.0 * np.log10(rms))
            voicing_score = max(0.0, min(1.0, 1.0 - min(zcr / 0.5, 1.0)))
            frames.append(
                {
                    "window_start_sec": row["window_start_sec"],
                    "window_end_sec": row["window_end_sec"],
                    "center_sec": row["center_sec"],
                    "speech_prob": row["speech_prob"],
                    "rms_dbfs": round(rms_dbfs, 6),
                    "voicing_score": round(voicing_score, 6),
                    "offset_samples": row["offset_samples"],
                }
            )
        payload = {"frames": frames, "centers": [float(row["center_sec"]) for row in frames]}
        write_json(cache_path, payload)
        results[source.recording_id] = payload
    return results


def _profile_detector_pipelines(
    *,
    sources: dict[str, SourceInfo],
    audio_feature_cache: dict[str, dict[str, Any]],
    output_root: Path,
) -> dict[str, Any]:
    import numpy as np
    import soundfile as sf
    import torch
    from silero_vad import load_silero_vad

    decoded_audio: dict[str, tuple[Any, int]] = {}

    def decode_audio() -> float:
        started = time.perf_counter()
        decoded_audio.clear()
        for source in sources.values():
            decoded_audio[source.recording_id] = sf.read(str(source.path), dtype="float32", always_2d=False)
        return time.perf_counter() - started

    def rms_and_voicing_from_decoded() -> tuple[float, float]:
        started_rms = time.perf_counter()
        rms_sum = 0.0
        for source in sources.values():
            audio, sample_rate = decoded_audio[source.recording_id]
            audio = np.asarray(audio, dtype=np.float32)
            for row in audio_feature_cache[source.recording_id]["frames"]:
                start = max(0, int(round(float(row["window_start_sec"]) * sample_rate)))
                end = min(len(audio), int(round(float(row["window_end_sec"]) * sample_rate)))
                chunk = audio[start:end]
                if len(chunk):
                    rms_sum += float(np.sqrt(np.mean(np.square(chunk), dtype=np.float64)))
        rms_time = time.perf_counter() - started_rms
        started_voicing = time.perf_counter()
        voicing_sum = 0.0
        for source in sources.values():
            audio, sample_rate = decoded_audio[source.recording_id]
            audio = np.asarray(audio, dtype=np.float32)
            for row in audio_feature_cache[source.recording_id]["frames"]:
                start = max(0, int(round(float(row["window_start_sec"]) * sample_rate)))
                end = min(len(audio), int(round(float(row["window_end_sec"]) * sample_rate)))
                chunk = audio[start:end]
                if len(chunk) > 1:
                    signs = np.signbit(chunk)
                    voicing_sum += float(np.mean(signs[1:] != signs[:-1]))
        voicing_time = time.perf_counter() - started_voicing
        _ = rms_sum + voicing_sum
        return rms_time, voicing_time

    def vad_infer(model: Any) -> float:
        started = time.perf_counter()
        for source in sources.values():
            audio, sample_rate = decoded_audio[source.recording_id]
            audio = np.asarray(audio, dtype=np.float32)
            for offset in (0, 128):
                model.reset_states()
                for start in range(offset, len(audio), 256):
                    chunk = audio[start : start + 512]
                    if len(chunk) < 512:
                        chunk = np.pad(chunk, (0, 512 - len(chunk)))
                    _ = float(model(torch.from_numpy(chunk), sample_rate).item())
        return time.perf_counter() - started

    cold_decode = decode_audio()
    cold_rms, cold_voicing = rms_and_voicing_from_decoded()
    load_started = time.perf_counter()
    vad_model = load_silero_vad()
    cold_vad_load = time.perf_counter() - load_started
    cold_vad_infer = vad_infer(vad_model)
    warm_decode = decode_audio()
    warm_rms, warm_voicing = rms_and_voicing_from_decoded()
    warm_vad_infer = vad_infer(vad_model)
    del vad_model
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    profiler = {
        "vad_local_minima": {
            "cold_audio_decode_sec": round(cold_decode, 6),
            "cold_vad_model_load_sec": round(cold_vad_load, 6),
            "cold_vad_inference_sec": round(cold_vad_infer, 6),
            "warm_audio_decode_sec": round(warm_decode, 6),
            "warm_vad_model_load_sec": 0.0,
            "warm_vad_inference_sec": round(warm_vad_infer, 6),
        },
        "legacy_rms_minima": {
            "cold_audio_decode_sec": round(cold_decode, 6),
            "cold_rms_extraction_sec": round(cold_rms, 6),
            "warm_audio_decode_sec": round(warm_decode, 6),
            "warm_rms_extraction_sec": round(warm_rms, 6),
        },
        "legacy_vad_rms": {
            "cold_audio_decode_sec": round(cold_decode, 6),
            "cold_rms_extraction_sec": round(cold_rms, 6),
            "cold_vad_model_load_sec": round(cold_vad_load, 6),
            "cold_vad_inference_sec": round(cold_vad_infer, 6),
            "warm_audio_decode_sec": round(warm_decode, 6),
            "warm_rms_extraction_sec": round(warm_rms, 6),
            "warm_vad_model_load_sec": 0.0,
            "warm_vad_inference_sec": round(warm_vad_infer, 6),
        },
        "percentile_rms": {
            "cold_audio_decode_sec": round(cold_decode, 6),
            "cold_rms_extraction_sec": round(cold_rms, 6),
            "warm_audio_decode_sec": round(warm_decode, 6),
            "warm_rms_extraction_sec": round(warm_rms, 6),
        },
        "vad_percentile_rms": {
            "cold_audio_decode_sec": round(cold_decode, 6),
            "cold_rms_extraction_sec": round(cold_rms, 6),
            "cold_vad_model_load_sec": round(cold_vad_load, 6),
            "cold_vad_inference_sec": round(cold_vad_infer, 6),
            "warm_audio_decode_sec": round(warm_decode, 6),
            "warm_rms_extraction_sec": round(warm_rms, 6),
            "warm_vad_model_load_sec": 0.0,
            "warm_vad_inference_sec": round(warm_vad_infer, 6),
        },
        "local_prominence_rms": {
            "cold_audio_decode_sec": round(cold_decode, 6),
            "cold_rms_extraction_sec": round(cold_rms, 6),
            "warm_audio_decode_sec": round(warm_decode, 6),
            "warm_rms_extraction_sec": round(warm_rms, 6),
        },
        "vad_local_prominence_rms": {
            "cold_audio_decode_sec": round(cold_decode, 6),
            "cold_rms_extraction_sec": round(cold_rms, 6),
            "cold_vad_model_load_sec": round(cold_vad_load, 6),
            "cold_vad_inference_sec": round(cold_vad_infer, 6),
            "warm_audio_decode_sec": round(warm_decode, 6),
            "warm_rms_extraction_sec": round(warm_rms, 6),
            "warm_vad_model_load_sec": 0.0,
            "warm_vad_inference_sec": round(warm_vad_infer, 6),
        },
        "vad_rms_voicing": {
            "cold_audio_decode_sec": round(cold_decode, 6),
            "cold_rms_extraction_sec": round(cold_rms, 6),
            "cold_vad_model_load_sec": round(cold_vad_load, 6),
            "cold_vad_inference_sec": round(cold_vad_infer, 6),
            "cold_voicing_extraction_sec": round(cold_voicing, 6),
            "warm_audio_decode_sec": round(warm_decode, 6),
            "warm_rms_extraction_sec": round(warm_rms, 6),
            "warm_vad_model_load_sec": 0.0,
            "warm_vad_inference_sec": round(warm_vad_infer, 6),
            "warm_voicing_extraction_sec": round(warm_voicing, 6),
        },
        "adaptive_local_rms_valleys": {
            "cold_audio_decode_sec": round(cold_decode, 6),
            "cold_rms_extraction_sec": round(cold_rms, 6),
            "warm_audio_decode_sec": round(warm_decode, 6),
            "warm_rms_extraction_sec": round(warm_rms, 6),
        },
        "rms_vad_veto": {
            "cold_audio_decode_sec": round(cold_decode, 6),
            "cold_rms_extraction_sec": round(cold_rms, 6),
            "cold_vad_model_load_sec": round(cold_vad_load, 6),
            "cold_vad_inference_sec": round(cold_vad_infer, 6),
            "warm_audio_decode_sec": round(warm_decode, 6),
            "warm_rms_extraction_sec": round(warm_rms, 6),
            "warm_vad_model_load_sec": 0.0,
            "warm_vad_inference_sec": round(warm_vad_infer, 6),
        },
        "word_gap_acoustic_hybrid": {
            "cold_audio_decode_sec": round(cold_decode, 6),
            "cold_vad_model_load_sec": round(cold_vad_load, 6),
            "cold_vad_inference_sec": round(cold_vad_infer, 6),
            "warm_audio_decode_sec": round(warm_decode, 6),
            "warm_vad_model_load_sec": 0.0,
            "warm_vad_inference_sec": round(warm_vad_infer, 6),
        },
    }
    profiler["current_plus_vad_union"] = dict(profiler["vad_local_minima"])
    profiler["current_plus_vad_plus_buffer_edge"] = dict(profiler["vad_local_minima"])
    write_json(output_root / "metrics" / "detector_profiler_raw.json", profiler)
    return profiler


def _window_feature_stats(feature_index: dict[str, Any], start_sec: float, end_sec: float) -> dict[str, Any]:
    frames = _slice_feature_frames(feature_index, start_sec, end_sec)
    return _stats_from_frames(frames)


def _slice_feature_frames(feature_index: dict[str, Any], start_sec: float, end_sec: float) -> list[dict[str, Any]]:
    return [
        row
        for row in _slice_indexed_frames(feature_index, start_sec, end_sec)
        if start_sec + EPSILON_SEC < float(row["center_sec"]) < end_sec - EPSILON_SEC
    ]


def _stats_from_frames(frames: list[dict[str, Any]]) -> dict[str, Any]:
    if not frames:
        return {
            "vad_min": None,
            "vad_mean": None,
            "vad_longest_below_0_1_ms": None,
            "vad_longest_below_0_2_ms": None,
            "rms_min_dbfs": None,
            "rms_mean_dbfs": None,
            "voicing_min": None,
            "voicing_mean": None,
        }
    vad_probs = [float(row["speech_prob"]) for row in frames]
    rms_values = [float(row["rms_dbfs"]) for row in frames]
    voicing_values = [float(row["voicing_score"]) for row in frames]
    below_01 = merge_intervals(
        [(float(row["window_start_sec"]), float(row["window_end_sec"])) for row in frames if float(row["speech_prob"]) < 0.1],
        epsilon_sec=0.0,
    )
    below_02 = merge_intervals(
        [(float(row["window_start_sec"]), float(row["window_end_sec"])) for row in frames if float(row["speech_prob"]) < 0.2],
        epsilon_sec=0.0,
    )
    return {
        "vad_min": min(vad_probs),
        "vad_mean": statistics.fmean(vad_probs),
        "vad_longest_below_0_1_ms": 0.0 if not below_01 else max((end - start) * 1000.0 for start, end in below_01),
        "vad_longest_below_0_2_ms": 0.0 if not below_02 else max((end - start) * 1000.0 for start, end in below_02),
        "rms_min_dbfs": min(rms_values),
        "rms_mean_dbfs": statistics.fmean(rms_values),
        "voicing_min": min(voicing_values),
        "voicing_mean": statistics.fmean(voicing_values),
    }


def _find_strict_interval(rows: list[dict[str, Any]], time_sec: float) -> dict[str, Any] | None:
    for row in rows:
        if float(row["start_sec"]) < time_sec < float(row["end_sec"]):
            return row
    return None


def _last_interval_before(rows: list[dict[str, Any]], time_sec: float) -> dict[str, Any] | None:
    candidate = None
    for row in rows:
        if float(row["end_sec"]) <= time_sec + EPSILON_SEC:
            candidate = row
        else:
            break
    return candidate


def _first_interval_after(rows: list[dict[str, Any]], time_sec: float) -> dict[str, Any] | None:
    for row in rows:
        if float(row["start_sec"]) >= time_sec - EPSILON_SEC:
            return row
    return None


def _depth_inside_interval(row: dict[str, Any] | None, time_sec: float) -> float | None:
    if row is None:
        return None
    start = float(row["start_sec"])
    end = float(row["end_sec"])
    if not (start < time_sec < end):
        return None
    return round(min(time_sec - start, end - time_sec), 6)


def _nearest_edge_distance(row: dict[str, Any] | None, time_sec: float) -> float | None:
    if row is None:
        return None
    start = float(row["start_sec"])
    end = float(row["end_sec"])
    if start <= time_sec <= end:
        return round(min(time_sec - start, end - time_sec), 6)
    return round(min(abs(time_sec - start), abs(time_sec - end)), 6)


def _clip_intervals_by_recording(clips: list[Clip]) -> dict[str, list[tuple[float, float]]]:
    rows: dict[str, list[tuple[float, float]]] = defaultdict(list)
    for clip in clips:
        rows[clip.recording_id].append((clip.start_sec, clip.end_sec))
    return rows


def _buffer_union_duration(
    *,
    buffer_ids: set[str],
    buffer_by_id: dict[str, dict[str, Any]],
    sources: dict[str, SourceInfo],
) -> float:
    intervals_by_recording: dict[str, list[tuple[float, float]]] = defaultdict(list)
    for buffer_id in buffer_ids:
        buffer = buffer_by_id[buffer_id]
        source = sources[str(buffer["source_audio_id"])]
        intervals_by_recording[source.recording_id].append(
            (float(buffer["trusted_start_sec"]), float(buffer["trusted_end_sec"]))
        )
    return sum(_interval_union_duration(intervals) for intervals in intervals_by_recording.values())


def _interval_union_duration(intervals: list[tuple[float, float]]) -> float:
    return sum(end - start for start, end in merge_intervals(intervals))


def _reference_coverage_stats(
    reference_by_recording: dict[str, list[tuple[float, float]]],
    clip_intervals_by_recording: dict[str, list[tuple[float, float]]],
) -> tuple[float, float]:
    unique = 0.0
    repeated = 0.0
    for recording_id, reference_intervals in reference_by_recording.items():
        clip_intervals = clip_intervals_by_recording.get(recording_id, [])
        boundaries = sorted(
            {
                boundary
                for start, end in reference_intervals + clip_intervals
                for boundary in (start, end)
            }
        )
        for left, right in zip(boundaries, boundaries[1:]):
            if right - left <= EPSILON_SEC:
                continue
            mid = (left + right) / 2.0
            if not any(start < mid < end for start, end in reference_intervals):
                continue
            cover_count = sum(start < mid < end for start, end in clip_intervals)
            if cover_count >= 1:
                unique += right - left
            if cover_count >= 2:
                repeated += right - left
    return unique, repeated


def _duration_bucket(duration_sec: float) -> str:
    if duration_sec < 3.0:
        return "<3"
    if duration_sec < 6.0:
        return "3-6"
    if duration_sec <= 8.0:
        return "6-8"
    if duration_sec <= 15.0:
        return "8-15"
    return ">15"


def _compute_metric_row(
    result: DetectorRunResult,
    total_audio_sec: float,
    total_buffer_count: int,
    total_pre_asr_buffer_duration_sec: float,
) -> dict[str, Any]:
    metric = result.compute_metric
    row = asdict(metric)
    row["external_model_dependencies"] = json.dumps(list(metric.external_model_dependencies))
    row["per_hour_audio_cost_sec"] = metric.per_hour_audio_cost_sec
    row["real_time_factor"] = metric.real_time_factor
    row["total_audio_sec"] = round(total_audio_sec, 6)
    row["uses_asr"] = result.uses_asr
    row["uses_mfa"] = result.uses_mfa
    row["uses_aligned_words"] = result.uses_aligned_words
    row["uses_alignment_qc"] = result.uses_alignment_qc
    row["searched_buffer_count"] = result.searched_interval_count
    row["total_buffer_count"] = total_buffer_count
    row["searched_duration_sec"] = result.searched_duration_sec
    row["total_pre_asr_buffer_duration_sec"] = round(total_pre_asr_buffer_duration_sec, 6)
    row["validity_notes"] = result.validity_notes
    return row


def _cutpoint_row(cut: Cutpoint) -> dict[str, Any]:
    row = asdict(cut)
    row["metadata_json"] = json.dumps(cut.metadata, sort_keys=True)
    del row["metadata"]
    return row


def _clip_rows_from_clips(clips: list[Clip]) -> list[dict[str, Any]]:
    return [asdict(clip) for clip in clips]


def _rows_to_clips(rows: list[dict[str, Any]]) -> list[Clip]:
    return [Clip(**row) for row in rows]


def _validate_current_baseline(
    *,
    benchmark_root: Path,
    eval_run: Path,
    cutpoints: list[Cutpoint],
    corrected_safe_regions: list[dict[str, Any]],
    buffer_by_id: dict[str, dict[str, Any]],
    sources: dict[str, SourceInfo],
    lexical_words_by_recording: dict[str, list[dict[str, Any]]],
    speech_phones_by_recording: dict[str, list[dict[str, Any]]],
) -> None:
    old_path = eval_run / "tables" / "detector_comparison_corrected.csv"
    if not old_path.exists():
        return
    rows = _read_csv(old_path)
    old_row = next(
        row
        for row in rows
        if row["scope_type"] == "aggregate"
        and row["scope_id"] == "all"
        and row["detector"] == "current"
        and row["policy"] == "strict"
        and int(row["min_region_ms"]) == 40
        and int(row["phone_guard_ms"]) == 50
    )
    proposed_boundary_rows, _ = _boundary_safety_rows(
        detector_name="current_production",
        packer_name="baseline",
        cutpoints=cutpoints,
        clips=[],
        lexical_words_by_recording=lexical_words_by_recording,
        speech_phones_by_recording=speech_phones_by_recording,
    )
    proposed = [row for row in proposed_boundary_rows if row["stage"] == "proposed_cutpoints"]
    safe_region_rows = _safe_region_recall_rows(
        detector_name="current_production",
        cutpoints=cutpoints,
        corrected_safe_regions=corrected_safe_regions,
        operational_buffers={cut.buffer_id for cut in cutpoints},
        buffer_by_id=buffer_by_id,
        sources=sources,
        min_region_ms_values=(40,),
    )
    recall = safe_region_rows[0]["safe_region_recall_all"]
    precision = round(
        _safe_divide(
            sum(not row["guard_50ms_violation"] and not row["inside_reference_phone"] for row in proposed),
            len(proposed),
        ),
        6,
    )
    if abs(float(old_row["safe_cut_precision_phone_guard"]) - float(precision)) > 1e-6:
        raise ValueError(
            f"baseline precision mismatch: old={old_row['safe_cut_precision_phone_guard']} new={precision}"
        )
    if abs(float(old_row["eligible_safe_region_recall_all_buffers"]) - float(recall)) > 1e-6:
        raise ValueError(
            f"baseline recall mismatch: old={old_row['eligible_safe_region_recall_all_buffers']} new={recall}"
        )
    write_json(
        benchmark_root / "metrics" / "baseline_match.json",
        {
            "current_precision_strict_40ms_guard50": precision,
            "current_recall_strict_40ms_guard50": recall,
            "matched_old_corrected_output": True,
        },
    )


def _build_listening_audit(
    *,
    output_root: Path,
    clips_all: list[Clip],
    boundary_rows: list[dict[str, Any]],
    reference_words_by_recording: dict[str, list[dict[str, Any]]],
    reference_phones_by_recording: dict[str, list[dict[str, Any]]],
    sources: dict[str, SourceInfo],
    sample_per_bucket: int,
    seed: int,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    rng = random.Random(seed)
    snippets_dir = output_root / "audit_audio" / "listening_bundle"
    snippets_dir.mkdir(parents=True, exist_ok=True)
    candidate_rows = [
        row
        for row in boundary_rows
        if row["stage"] == "final_emitted_boundaries"
        and row["detector_name"] in {
            "current_production",
            "legacy_rms_minima",
            "legacy_vad_rms",
            "percentile_rms",
            "vad_percentile_rms",
            "local_prominence_rms",
            "vad_local_prominence_rms",
        }
    ]
    by_bucket: dict[tuple[str, str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in candidate_rows:
        bucket = _listening_bucket(row)
        by_bucket[(row["detector_name"], row["boundary_side"], bucket)].append(row)
    chosen: list[dict[str, Any]] = []
    base_quota = 8
    target_total = 198
    ordered_strata = sorted(by_bucket)
    leftovers: list[dict[str, Any]] = []
    for key in ordered_strata:
        rows = by_bucket[key]
        take = min(len(rows), base_quota)
        sampled = rows if len(rows) <= take else rng.sample(rows, take)
        chosen.extend(sampled)
        selected_ids = {id(row) for row in sampled}
        leftovers.extend([row for row in rows if id(row) not in selected_ids])
    if len(chosen) < target_total and leftovers:
        extras = min(target_total - len(chosen), len(leftovers))
        chosen.extend(rng.sample(leftovers, extras))
    if len(chosen) > target_total:
        chosen = rng.sample(chosen, target_total)
    index_rows: list[dict[str, Any]] = []
    decode_rows: list[dict[str, Any]] = []
    clip_by_boundary: dict[tuple[str, str, str, float], Clip] = {}
    for clip in clips_all:
        clip_by_boundary[(clip.detector_name, "clip_start", clip.recording_id, clip.start_sec)] = clip
        clip_by_boundary[(clip.detector_name, "clip_end", clip.recording_id, clip.end_sec)] = clip
    for index, row in enumerate(chosen):
        anonymous_id = f"audit_{index:05d}"
        clip = clip_by_boundary.get((row["detector_name"], row["boundary_side"], row["recording_id"], float(row["time_sec"])))
        source = next(src for src in sources.values() if src.recording_id == row["recording_id"])
        boundary_path = snippets_dir / f"{anonymous_id}_boundary.wav"
        clip_path = snippets_dir / f"{anonymous_id}_clip.wav"
        context_path = snippets_dir / f"{anonymous_id}_context.wav"
        _export_audio_window(boundary_path, source=source, start_sec=float(row["time_sec"]) - 0.5, end_sec=float(row["time_sec"]) + 0.5)
        if clip is not None:
            _export_audio_window(clip_path, source=source, start_sec=clip.start_sec, end_sec=clip.end_sec)
            _export_audio_window(context_path, source=source, start_sec=max(0.0, clip.start_sec - 0.5), end_sec=min(source.duration_sec, clip.end_sec + 0.5))
        else:
            _export_audio_window(clip_path, source=source, start_sec=max(0.0, float(row["time_sec"]) - 1.0), end_sec=min(source.duration_sec, float(row["time_sec"]) + 1.0))
            _export_audio_window(context_path, source=source, start_sec=max(0.0, float(row["time_sec"]) - 1.0), end_sec=min(source.duration_sec, float(row["time_sec"]) + 1.0))
        index_rows.append(
            {
                "anonymous_item_id": anonymous_id,
                "reviewer_label": "",
                "reviewer_notes": "",
            }
        )
        decode_rows.append(
            {
                "anonymous_item_id": anonymous_id,
                "detector_name": row["detector_name"],
                "packer_name": row["packer_name"],
                "recording_id": row["recording_id"],
                "boundary_side": row["boundary_side"],
                "boundary_time_sec": row["time_sec"],
                "inside_phone": row["inside_reference_phone"],
                "inside_word": row["inside_reference_word"],
                "phone_label": row["containing_phone"],
                "word_label": row["containing_word"],
                "leak_bucket": _listening_bucket(row),
                "boundary_snippet_path": str(boundary_path),
                "emitted_clip_path": str(clip_path),
                "source_context_path": str(context_path),
            }
        )
    return index_rows, decode_rows


def _listening_bucket(row: dict[str, Any]) -> str:
    depth = row["depth_inside_phone_sec"]
    if depth in (None, ""):
        return "outside_all_phones"
    depth_ms = float(depth) * 1000.0
    if depth_ms <= 10.0:
        return "inside_phone_0_10ms"
    if depth_ms <= 20.0:
        return "inside_phone_10_20ms"
    if depth_ms <= 50.0:
        return "inside_phone_20_50ms"
    if depth_ms <= 100.0:
        return "inside_phone_50_100ms"
    return "inside_phone_gt_100ms"


def _export_audio_window(snippet_path: Path, *, source: SourceInfo, start_sec: float, end_sec: float) -> None:
    start_sec = max(0.0, start_sec)
    end_sec = min(source.duration_sec, end_sec)
    start_frame = int(start_sec * source.sample_rate)
    end_frame = int(end_sec * source.sample_rate)
    with wave.open(str(source.path), "rb") as in_handle:
        in_handle.setpos(start_frame)
        frames = in_handle.readframes(max(0, end_frame - start_frame))
        params = in_handle.getparams()
    snippet_path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(snippet_path), "wb") as out_handle:
        out_handle.setparams(params)
        out_handle.writeframes(frames)


def _write_provenance(
    *,
    output_root: Path,
    eval_run: Path,
    normalized_speaker_dir: Path,
    speechcraft_config: dict[str, Any],
    runtime_versions: dict[str, Any],
    status_json: dict[str, Any],
    benchmark_config: BenchmarkConfig,
) -> dict[str, Any]:
    speechcraft_root = Path("/home/aaravthegreat/Projects/speechcraft")
    git_head = _run_git(speechcraft_root, ["rev-parse", "HEAD"])
    git_status = _run_git(speechcraft_root, ["status", "--short"])
    payload = {
        "speechcraft_commit": git_head.strip(),
        "speechcraft_status": git_status.splitlines(),
        "speaker_ts_eval_git_available": False,
        "input_eval_run": str(eval_run),
        "normalized_speaker_dir": str(normalized_speaker_dir),
        "speechcraft_config": speechcraft_config,
        "runtime_versions": runtime_versions,
        "speechcraft_status_json": status_json,
        "benchmark_config": asdict(benchmark_config),
        "benchmark_config_hash": _json_hash(asdict(benchmark_config)),
        "source_manifest_hash": _file_sha256(eval_run / "speechcraft_run" / "artifacts" / "source_audio_manifest.json"),
        "processing_buffers_hash": _file_sha256(eval_run / "speechcraft_run" / "artifacts" / "processing_buffers.json"),
        "reference_words_hash": _file_sha256(normalized_speaker_dir / "reference_words.csv"),
        "reference_phones_hash": _file_sha256(normalized_speaker_dir / "reference_phones.csv"),
        "benchmark_code_hash": _files_sha256(
            [
                Path("/home/aaravthegreat/Projects/speaker_ts_eval/src/speaker_ts_eval/slicer_daddy_test.py"),
                Path("/home/aaravthegreat/Projects/speaker_ts_eval/src/speaker_ts_eval/multispeaker_slicer_daddy_test.py"),
                Path("/home/aaravthegreat/Projects/speaker_ts_eval/src/speaker_ts_eval/buckeye_safecut_benchmark.py"),
            ]
        ),
    }
    write_json(output_root / "metrics" / "provenance.json", payload)
    return payload


def _snapshot_code(*, output_root: Path) -> None:
    code_dir = output_root / "code_snapshot"
    files = [
        Path("/home/aaravthegreat/Projects/speaker_ts_eval/src/speaker_ts_eval/slicer_daddy_test.py"),
        Path("/home/aaravthegreat/Projects/speaker_ts_eval/src/speaker_ts_eval/multispeaker_slicer_daddy_test.py"),
        Path("/home/aaravthegreat/Projects/speaker_ts_eval/src/speaker_ts_eval/buckeye_safecut_benchmark.py"),
        Path("/home/aaravthegreat/Projects/speaker_ts_eval/src/speaker_ts_eval/cli.py"),
        Path("/home/aaravthegreat/Projects/speaker_ts_eval/tests/test_slicer_daddy_test.py"),
        Path("/home/aaravthegreat/Projects/speaker_ts_eval/tests/test_multispeaker_slicer_daddy_test.py"),
    ]
    for path in files:
        target = code_dir / path.name
        target.write_text(path.read_text())


def _read_stage_durations_from_log(log_path: Path) -> dict[str, float]:
    durations: dict[str, float] = {}
    if not log_path.exists():
        return durations
    previous_stage = "started"
    previous_time: datetime | None = None
    for line in log_path.read_text(errors="replace").splitlines():
        if " completed summary=" not in line:
            continue
        timestamp_text, remainder = line.split(" ", 1)
        stage = remainder.split(" completed summary=", 1)[0].strip()
        current_time = datetime.fromisoformat(timestamp_text)
        if previous_time is not None:
            durations[stage] = round((current_time - previous_time).total_seconds(), 6)
        previous_stage = stage
        previous_time = current_time
    return durations


def _write_reports(
    *,
    output_root: Path,
    scorecard_rows: list[dict[str, Any]],
    packing_rows: list[dict[str, Any]],
    compute_rows: list[dict[str, Any]],
    baseline_eval_run: Path,
    provenance: dict[str, Any],
) -> None:
    best_coverage = max(scorecard_rows, key=lambda row: float(row["reference_speech_phone_coverage"]))
    best_shape = max(scorecard_rows, key=lambda row: float(row["preferred_duration_rate"]))
    safest_word = min(scorecard_rows, key=lambda row: float(row["selected_boundary_inside_word_rate"]))
    safest_phone = min(scorecard_rows, key=lambda row: float(row["selected_boundary_inside_phone_rate"]))
    shallowest = min(scorecard_rows, key=lambda row: float("inf") if row["p95_phone_leak_depth_sec"] is None else float(row["p95_phone_leak_depth_sec"]))
    best_safe_region = max(scorecard_rows, key=lambda row: float(row["safe_region_recall_strict_40ms"]))
    cheapest = min(scorecard_rows, key=lambda row: float("inf") if row["real_time_factor"] is None else float(row["real_time_factor"]))
    constrained_rows = [
        row
        for row in scorecard_rows
        if float(row["selected_boundary_inside_phone_rate"]) <= float(next(item for item in scorecard_rows if item["detector_name"] == "current_production" and item["packer_name"] == row["packer_name"])["selected_boundary_inside_phone_rate"])
    ]
    constrained_best = None if not constrained_rows else max(constrained_rows, key=lambda row: float(row["reference_speech_phone_coverage"]))
    frontier = [row for row in _build_pareto_frontier(scorecard_rows) if row["pareto_optimal_pre_perceptual"]]
    validity_rows = [
        row for row in sorted(scorecard_rows, key=lambda row: (row["detector_name"], row["packer_name"]))
        if row["packer_name"] == "optimal_weighted_interval"
    ]
    review_lines = [
        "Validity",
        "| detector | uses_asr | uses_mfa | uses_aligned_words | uses_alignment_qc | searched_buffers | searched_duration_ratio |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for row in validity_rows:
        review_lines.append(
            f"| {row['detector_name']} | {str(row['uses_asr']).lower()} | {str(row['uses_mfa']).lower()} | {str(row['uses_aligned_words']).lower()} | {str(row['uses_alignment_qc']).lower()} | {row['searched_buffer_count']} | {row['searched_duration_ratio']} |"
        )
    review_lines.extend(
        [
            "",
        f"1. Highest unique reference-speech coverage: `{best_coverage['detector_name']}` / `{best_coverage['packer_name']}` at `{best_coverage['reference_speech_phone_coverage']}`.",
        f"2. Best 6–8 second clip distribution: `{best_shape['detector_name']}` / `{best_shape['packer_name']}` at `{best_shape['preferred_duration_rate']}`.",
        f"3. Lowest selected-boundary inside-word rate: `{safest_word['detector_name']}` / `{safest_word['packer_name']}` at `{safest_word['selected_boundary_inside_word_rate']}`.",
        f"4. Lowest selected-boundary inside-phone rate: `{safest_phone['detector_name']}` / `{safest_phone['packer_name']}` at `{safest_phone['selected_boundary_inside_phone_rate']}`.",
        f"5. Shallowest boundary leaks by p95 phone depth: `{shallowest['detector_name']}` / `{shallowest['packer_name']}` at `{shallowest['p95_phone_leak_depth_sec']}` sec.",
        f"6. Most corrected human-safe regions found: `{best_safe_region['detector_name']}` / `{best_safe_region['packer_name']}` at `{best_safe_region['safe_region_recall_strict_40ms']}`.",
        "7. Overlap and duplicate material by detector are in `duplication_metrics.csv` and summarized in `detector_scorecard.csv`.",
        "8. Greedy-versus-optimal gains are in `packing_comparison.csv`.",
        f"9. Cheapest detector by real-time factor: `{cheapest['detector_name']}` at `{cheapest['real_time_factor']}`.",
        "10. Pareto-optimal detector/packer combinations are listed in `pareto_frontier.csv`.",
        f"13. Constrained coverage winner at or below current inside-phone rate: `{constrained_best['detector_name']}` / `{constrained_best['packer_name']}`." if constrained_best is not None else "13. No detector met the constrained winner rule.",
        "11. Whether any acoustic-only detector beats current ASR+MFA is answered in `detector_scorecard.csv`; compare the legacy RMS baselines, percentile RMS baselines, and local-prominence RMS baselines against `current_production`.",
        "12. Perceptual annotations are still required; `LISTENING_AUDIT_INDEX.csv` is blank by design and `LISTENING_AUDIT_DECODE_KEY.csv` is for post-review decoding.",
        "14. `current_production` means production SafeCutPoints with benchmark packers. Actual Speechcraft-emitted clips are exported separately in `actual_production_clips.csv`.",
        ]
    )
    (output_root / "REVIEW_ME_FIRST.md").write_text("\n".join(review_lines) + "\n")
    report_lines = [
        "# Slicer Daddy Test",
        "",
        f"- Input Speechcraft run: `{baseline_eval_run}`",
        f"- Speechcraft commit: `{provenance['speechcraft_commit']}`",
        f"- Benchmark detectors: current_production, vad_local_minima, legacy_rms_minima, legacy_vad_rms, percentile_rms, vad_percentile_rms, local_prominence_rms, vad_local_prominence_rms, vad_rms_voicing, word_gap_acoustic_hybrid, current_plus_vad_union, current_plus_vad_plus_buffer_edge",
        f"- Packers: greedy, optimal_weighted_interval",
        "- `current_production` is production SafeCutPoints repacked by benchmark packers; actual Speechcraft-emitted clips are in `actual_production_clips.csv`.",
        "",
        "## Validity",
        "",
        "| detector | uses_asr | uses_mfa | uses_aligned_words | uses_alignment_qc | searched_buffers | searched_duration_ratio |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for row in sorted(scorecard_rows, key=lambda row: (row["detector_name"], row["packer_name"])):
        if row["packer_name"] != "optimal_weighted_interval":
            continue
        report_lines.append(
            f"| {row['detector_name']} | {str(row['uses_asr']).lower()} | {str(row['uses_mfa']).lower()} | {str(row['uses_aligned_words']).lower()} | {str(row['uses_alignment_qc']).lower()} | {row['searched_buffer_count']} | {row['searched_duration_ratio']} |"
        )
    report_lines.extend(
        [
            "",
        "## Pareto Frontier",
        ]
    )
    for row in frontier:
        report_lines.append(
            f"- `{row['detector_name']}` / `{row['packer_name']}`: coverage `{row['reference_speech_phone_coverage']}`, inside-phone `{row['selected_boundary_inside_phone_rate']}`, RTF `{row['real_time_factor']}`"
        )
    report_lines.extend(
        [
            "",
            "## Baseline",
            "- The benchmark validates current_production strict-policy 40ms/50ms metrics against the existing corrected Buckeye evaluator before comparing new detectors.",
            "- See `metrics/baseline_match.json`.",
            "",
            "## Outputs",
            "- detector_scorecard.csv",
            "- cutpoints_all_detectors.csv",
            "- clips_all_detectors.csv",
            "- coverage_metrics.csv",
            "- clip_shape_metrics.csv",
            "- duplication_metrics.csv",
            "- boundary_safety_all_stages.csv",
            "- boundary_severity.csv",
            "- safe_region_recall.csv",
            "- packing_comparison.csv",
            "- compute_metrics.csv",
            "- pareto_frontier.csv",
            "- LISTENING_AUDIT_INDEX.csv",
            "- LISTENING_AUDIT_DECODE_KEY.csv",
        ]
    )
    (output_root / "SLICER_DADDY_TEST_REPORT.md").write_text("\n".join(report_lines) + "\n")


def _write_test_results(output_root: Path) -> None:
    import subprocess

    cmd = [
        "/home/aaravthegreat/Projects/speechcraft/workers/dataset/.venv/bin/python",
        "-m",
        "unittest",
        "discover",
        "-s",
        "tests",
        "-q",
    ]
    proc = subprocess.run(
        cmd,
        cwd="/home/aaravthegreat/Projects/speaker_ts_eval",
        env={**os.environ, "PYTHONPATH": "src"},
        capture_output=True,
        text=True,
    )
    payload = {
        "command": "PYTHONPATH=src /home/aaravthegreat/Projects/speechcraft/workers/dataset/.venv/bin/python -m unittest discover -s tests -q",
        "returncode": proc.returncode,
        "stdout": proc.stdout,
        "stderr": proc.stderr,
    }
    write_json(output_root / "metrics" / "test_results.json", payload)
    if proc.returncode != 0:
        raise RuntimeError(f"test suite failed: {proc.stdout}\n{proc.stderr}")


def _zip_review_bundle(output_root: Path) -> Path:
    zip_path = output_root.with_name(output_root.name + "_review.zip")
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(output_root.rglob("*")):
            if path.is_file():
                zf.write(path, arcname=str(path.relative_to(output_root.parent)))
    return zip_path


def _run_git(root: Path, args: list[str]) -> str:
    import subprocess

    proc = subprocess.run(["git", *args], cwd=root, capture_output=True, text=True, check=True)
    return proc.stdout


def _file_sha256(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def _files_sha256(paths: list[Path]) -> str:
    hasher = hashlib.sha256()
    for path in sorted(paths):
        hasher.update(str(path).encode("utf-8"))
        hasher.update(_file_sha256(path).encode("utf-8"))
    return hasher.hexdigest()


def _json_hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def _timestamp_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d_%H%M%S")


def _total_source_duration(sources: dict[str, SourceInfo]) -> float:
    return round(sum(source.duration_sec for source in sources.values()), 6)


def _safe_divide(numerator: float, denominator: float) -> float:
    if denominator == 0:
        return 0.0
    return numerator / denominator


def _percentile(values: list[float], q: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    rank = (len(ordered) - 1) * (q / 100.0)
    lo = math.floor(rank)
    hi = math.ceil(rank)
    if lo == hi:
        return ordered[lo]
    return ordered[lo] + (ordered[hi] - ordered[lo]) * (rank - lo)


def _stat_or_none(values: list[float], fn: Any) -> float | None:
    if not values:
        return None
    return round(float(fn(values)), 6)


def _ru_maxrss_to_mb(value: int) -> float | None:
    if not value:
        return None
    return round(float(value) / 1024.0, 3)
