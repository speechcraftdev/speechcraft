from __future__ import annotations

import csv
import json
import random
import shutil
import sys
import time
import wave
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from .buckeye_safecut_benchmark import SourceInfo, _as_bool, _load_sources, _vad_frame_geometry_from_env
from .intervals import merge_intervals, overlap_duration
from .io_utils import read_json, read_jsonl, write_csv, write_json
from .slicer_daddy_test import (
    AdaptiveLocalRmsDetector,
    AcousticDetectorContext,
    BenchmarkConfig,
    BenchmarkContexts,
    CandidateClip,
    Clip,
    ComputeMetric,
    Cutpoint,
    DetectorContext,
    DetectorRunResult,
    LocalProminenceRmsDetector,
    PercentileRmsDetector,
    PackingConstraints,
    RmsMinimaDetector,
    RmsVadVetoDetector,
    UnionDetector,
    VadLocalMinimaDetector,
    VadLocalProminenceRmsDetector,
    VadPercentileRmsDetector,
    VadRmsDetector,
    EPSILON_SEC,
    _build_audio_feature_cache,
    _buffer_union_duration,
    _candidate_clip_weight,
    _clips_from_candidates,
    _compute_recording_vad_frames,
    _dedupe_cutpoints,
    _safe_divide,
    _total_source_duration,
    _window_feature_stats,
    _weighted_interval_schedule_candidate_clips,
)


BOUNDARY_EPSILON_SEC = 0.001
NEMO_WALL_EPSILON_SEC = 0.000001
DEFAULT_SCOPE_MIN_CLIP_SEC = 3.0


@dataclass(frozen=True)
class NemoScopeBuffer:
    speaker_id: str
    recording_id: str
    source_audio_id: str
    wav_path: str
    buffer_id: str
    buffer_start_sec: float
    buffer_end_sec: float
    duration_sec: float
    source_cluster_ids: tuple[str, ...]
    mapping_confidence: float


@dataclass(frozen=True)
class RepairedMatrixFixture:
    speaker_id: str
    eval_run: Path
    normalized_speaker_dir: Path


def schedule_candidates_by_buffer(
    candidates: list[CandidateClip],
    *,
    max_overlap_sec: float = 0.0,
) -> list[CandidateClip]:
    candidates_by_buffer: dict[tuple[str, str], list[CandidateClip]] = defaultdict(list)
    for candidate in candidates:
        candidates_by_buffer[(candidate.recording_id, candidate.buffer_id)].append(candidate)
    selected: list[CandidateClip] = []
    for key in sorted(candidates_by_buffer):
        selected.extend(
            _weighted_interval_schedule_candidate_clips(
                candidates_by_buffer[key],
                max_overlap_sec=max_overlap_sec,
            )
        )
    return selected


def build_interviewer_mask(
    *,
    reference_words: list[dict[str, Any]],
    reference_phones: list[dict[str, Any]],
) -> dict[str, list[tuple[float, float]]]:
    by_recording: dict[str, list[tuple[float, float]]] = defaultdict(list)
    for row in reference_words:
        event_type = str(row.get("event_type") or "")
        raw_label = str(row.get("raw_label") or "")
        if event_type == "interviewer" or raw_label.strip().upper().startswith("<IVER"):
            by_recording[str(row["recording_id"])].append((float(row["start_sec"]), float(row["end_sec"])))
    for row in reference_phones:
        if str(row.get("phone_class") or "") == "interviewer" or str(row.get("raw_label") or "").strip().upper() == "IVER":
            by_recording[str(row["recording_id"])].append((float(row["start_sec"]), float(row["end_sec"])))
    return {recording_id: merge_intervals(intervals) for recording_id, intervals in by_recording.items()}


def subtract_intervals(
    intervals: list[tuple[float, float]],
    mask: list[tuple[float, float]],
) -> list[tuple[float, float]]:
    pieces = merge_intervals(intervals)
    for mask_start, mask_end in merge_intervals(mask):
        next_pieces: list[tuple[float, float]] = []
        for start_sec, end_sec in pieces:
            overlap_start = max(start_sec, mask_start)
            overlap_end = min(end_sec, mask_end)
            if overlap_end <= overlap_start:
                next_pieces.append((start_sec, end_sec))
                continue
            if start_sec < overlap_start:
                next_pieces.append((start_sec, overlap_start))
            if overlap_end < end_sec:
                next_pieces.append((overlap_end, end_sec))
        pieces = next_pieces
    return merge_intervals(pieces)


def build_target_speech_reference(
    *,
    reference_phones: list[dict[str, Any]],
    interviewer_mask_by_recording: dict[str, list[tuple[float, float]]],
    uncertainty_mask_by_recording: dict[str, list[tuple[float, float]]] | None = None,
) -> dict[str, list[tuple[float, float]]]:
    speech_by_recording: dict[str, list[tuple[float, float]]] = defaultdict(list)
    for row in reference_phones:
        if not _as_bool(row.get("is_speech_phone")):
            continue
        speech_by_recording[str(row["recording_id"])].append((float(row["start_sec"]), float(row["end_sec"])))
    result: dict[str, list[tuple[float, float]]] = {}
    for recording_id, intervals in speech_by_recording.items():
        result_intervals = subtract_intervals(intervals, interviewer_mask_by_recording.get(recording_id, []))
        result_intervals = subtract_intervals(result_intervals, (uncertainty_mask_by_recording or {}).get(recording_id, []))
        result[recording_id] = result_intervals
    return result


def build_phone_annotations(
    reference_phones: list[dict[str, Any]],
    *,
    interviewer_mask_by_recording: dict[str, list[tuple[float, float]]],
    uncertainty_mask_by_recording: dict[str, list[tuple[float, float]]] | None = None,
) -> dict[str, list[dict[str, Any]]]:
    by_recording: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in reference_phones:
        recording_id = str(row["recording_id"])
        start_sec = float(row["start_sec"])
        end_sec = float(row["end_sec"])
        if _as_bool(row.get("is_speech_phone")):
            target_pieces = subtract_intervals([(start_sec, end_sec)], interviewer_mask_by_recording.get(recording_id, []))
            target_pieces = subtract_intervals(target_pieces, (uncertainty_mask_by_recording or {}).get(recording_id, []))
            for piece_start, piece_end in target_pieces:
                by_recording[recording_id].append(
                    {
                        "recording_id": recording_id,
                        "start_sec": piece_start,
                        "end_sec": piece_end,
                        "label": str(row["normalized_label"]),
                        "annotation_class": "speech",
                    }
                )
            continue
        by_recording[recording_id].append(
            {
                "recording_id": recording_id,
                "start_sec": start_sec,
                "end_sec": end_sec,
                "label": str(row.get("normalized_label") or row.get("raw_label") or ""),
                "annotation_class": str(row.get("phone_class") or "unknown"),
            }
        )
    return {
        recording_id: sorted(rows, key=lambda row: (float(row["start_sec"]), float(row["end_sec"]), str(row["label"])))
        for recording_id, rows in by_recording.items()
    }


def load_nemo_cluster_mapping(mapping_csv: Path, *, speaker_id: str) -> dict[tuple[str, str], dict[str, Any]]:
    rows = _read_csv(mapping_csv)
    return {
        (str(row["recording_id"]), str(row["nemo_cluster"])): row
        for row in rows
        if str(row["dataset_id"]) == speaker_id
    }


def build_raw_nemo_target_buffers(
    *,
    speaker_id: str,
    eval_run: Path,
    cluster_mapping: dict[tuple[str, str], dict[str, Any]],
    included_recording_ids: set[str] | None = None,
    excluded_recording_ids: set[str] | None = None,
) -> list[NemoScopeBuffer]:
    artifacts_root = _resolve_artifacts_root(eval_run)
    source_manifest = read_json(artifacts_root / "source_audio_manifest.json")
    sources = {str(row["source_audio_id"]): row for row in source_manifest["sources"]}
    source_to_recording = {str(row["source_audio_id"]): str(row["source_recording_id"]) for row in source_manifest["sources"]}
    raw_regions = read_jsonl(artifacts_root / "speaker_regions.jsonl")
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in raw_regions:
        source_audio_id = str(row["source_audio_id"])
        recording_id = source_to_recording[source_audio_id]
        if included_recording_ids is not None and recording_id not in included_recording_ids:
            continue
        if excluded_recording_ids is not None and recording_id in excluded_recording_ids:
            continue
        cluster_id = str(row["speaker_id"])
        mapping_row = cluster_mapping.get((recording_id, cluster_id))
        if mapping_row is None or str(mapping_row["assigned_role"]) != "target":
            continue
        grouped[(recording_id, source_audio_id)].append(
            {
                "recording_id": recording_id,
                "source_audio_id": source_audio_id,
                "wav_path": str(sources[source_audio_id]["path"]),
                "start_sec": float(row["start_sec"]),
                "end_sec": float(row["end_sec"]),
                "cluster_id": cluster_id,
                "mapping_confidence": float(mapping_row["mapping_confidence"]),
            }
        )
    buffers: list[NemoScopeBuffer] = []
    for (recording_id, source_audio_id), rows in sorted(grouped.items()):
        ordered = sorted(rows, key=lambda row: (row["start_sec"], row["end_sec"], row["cluster_id"]))
        merged: list[dict[str, Any]] = []
        for row in ordered:
            if not merged:
                merged.append(
                    {
                        "start_sec": row["start_sec"],
                        "end_sec": row["end_sec"],
                        "cluster_ids": {row["cluster_id"]},
                        "mapping_confidence": row["mapping_confidence"],
                        "wav_path": row["wav_path"],
                    }
                )
                continue
            current = merged[-1]
            if row["start_sec"] <= current["end_sec"] + BOUNDARY_EPSILON_SEC:
                current["end_sec"] = max(current["end_sec"], row["end_sec"])
                current["cluster_ids"].add(row["cluster_id"])
                current["mapping_confidence"] = min(current["mapping_confidence"], row["mapping_confidence"])
            else:
                merged.append(
                    {
                        "start_sec": row["start_sec"],
                        "end_sec": row["end_sec"],
                        "cluster_ids": {row["cluster_id"]},
                        "mapping_confidence": row["mapping_confidence"],
                        "wav_path": row["wav_path"],
                    }
                )
        for index, row in enumerate(merged):
            duration_sec = float(row["end_sec"]) - float(row["start_sec"])
            buffers.append(
                NemoScopeBuffer(
                    speaker_id=speaker_id,
                    recording_id=recording_id,
                    source_audio_id=source_audio_id,
                    wav_path=str(row["wav_path"]),
                    buffer_id=f"{speaker_id}_{recording_id}_raw_nemo_buffer_{index:06d}",
                    buffer_start_sec=round(float(row["start_sec"]), 6),
                    buffer_end_sec=round(float(row["end_sec"]), 6),
                    duration_sec=round(duration_sec, 6),
                    source_cluster_ids=tuple(sorted(row["cluster_ids"])),
                    mapping_confidence=round(float(row["mapping_confidence"]), 6),
                )
                )
    return buffers


def build_nemo_scope_rows(
    *,
    buffers: list[NemoScopeBuffer],
    target_reference_by_recording: dict[str, list[tuple[float, float]]],
    interviewer_mask_by_recording: dict[str, list[tuple[float, float]]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    by_recording: dict[str, list[NemoScopeBuffer]] = defaultdict(list)
    for buffer in buffers:
        by_recording[buffer.recording_id].append(buffer)
    recording_rows: list[dict[str, Any]] = []
    speaker_totals: dict[str, float] = defaultdict(float)
    speaker_target_inside: dict[str, float] = defaultdict(float)
    speaker_target_ref: dict[str, float] = defaultdict(float)
    speaker_iver_inside: dict[str, float] = defaultdict(float)
    for recording_id, rows in sorted(by_recording.items()):
        intervals = [(row.buffer_start_sec, row.buffer_end_sec) for row in rows]
        union_duration = _interval_union_duration(intervals)
        target_inside = _overlap_intervals(intervals, target_reference_by_recording.get(recording_id, []))
        interviewer_inside = _overlap_intervals(intervals, interviewer_mask_by_recording.get(recording_id, []))
        target_ref = _interval_union_duration(target_reference_by_recording.get(recording_id, []))
        speaker_id = rows[0].speaker_id
        speaker_totals[speaker_id] += union_duration
        speaker_target_inside[speaker_id] += target_inside
        speaker_target_ref[speaker_id] += target_ref
        speaker_iver_inside[speaker_id] += interviewer_inside
        recording_rows.append(
            {
                "speaker_id": speaker_id,
                "recording_id": recording_id,
                "raw_nemo_buffer_count": len(rows),
                "median_buffer_duration_sec": _median([row.duration_sec for row in rows]),
                "total_buffer_duration_sec": round(union_duration, 6),
                "target_phone_recall": round(_safe_divide(target_inside, target_ref), 6),
                "target_phone_density": round(_safe_divide(target_inside, union_duration), 6),
                "interviewer_mask_overlap_rate": round(_safe_divide(interviewer_inside, union_duration), 6),
                "too_short_for_legal_clip_count": sum(row.duration_sec < DEFAULT_SCOPE_MIN_CLIP_SEC for row in rows),
            }
        )
    speaker_rows = [
        {
            "speaker_id": speaker_id,
            "recording_count": sum(1 for row in recording_rows if row["speaker_id"] == speaker_id),
            "raw_nemo_buffer_count": sum(int(row["raw_nemo_buffer_count"]) for row in recording_rows if row["speaker_id"] == speaker_id),
            "total_buffer_duration_sec": round(speaker_totals[speaker_id], 6),
            "target_phone_recall": round(_safe_divide(speaker_target_inside[speaker_id], speaker_target_ref[speaker_id]), 6),
            "target_phone_density": round(_safe_divide(speaker_target_inside[speaker_id], speaker_totals[speaker_id]), 6),
            "interviewer_mask_overlap_rate": round(_safe_divide(speaker_iver_inside[speaker_id], speaker_totals[speaker_id]), 6),
        }
        for speaker_id in sorted(speaker_totals)
    ]
    return recording_rows, speaker_rows


def cutpoints_strictly_inside_buffers(
    cutpoints: list[Cutpoint],
    buffers: list[NemoScopeBuffer],
) -> list[Cutpoint]:
    by_recording: dict[str, list[NemoScopeBuffer]] = defaultdict(list)
    for buffer in buffers:
        by_recording[buffer.recording_id].append(buffer)
    filtered: list[Cutpoint] = []
    for cut in cutpoints:
        containing = [
            buffer
            for buffer in by_recording.get(cut.recording_id, [])
            if buffer.buffer_start_sec + NEMO_WALL_EPSILON_SEC < cut.time_sec < buffer.buffer_end_sec - NEMO_WALL_EPSILON_SEC
        ]
        if len(containing) > 1:
            raise ValueError(f"cutpoint {cut.cutpoint_id} falls inside multiple NeMo buffers")
        if not containing:
            raise ValueError(f"cutpoint {cut.cutpoint_id} lies on or outside every NeMo buffer wall")
        filtered.append(
            Cutpoint(
                detector_name=cut.detector_name,
                source_id=cut.source_id,
                recording_id=cut.recording_id,
                buffer_id=containing[0].buffer_id,
                cutpoint_id=cut.cutpoint_id,
                time_sec=cut.time_sec,
                interval_start_sec=cut.interval_start_sec,
                interval_end_sec=cut.interval_end_sec,
                score=cut.score,
                vad_min=cut.vad_min,
                vad_mean=cut.vad_mean,
                vad_longest_below_0_1_ms=cut.vad_longest_below_0_1_ms,
                vad_longest_below_0_2_ms=cut.vad_longest_below_0_2_ms,
                rms_min_dbfs=cut.rms_min_dbfs,
                rms_mean_dbfs=cut.rms_mean_dbfs,
                voicing_min=cut.voicing_min,
                voicing_mean=cut.voicing_mean,
                compute_time_sec=cut.compute_time_sec,
                is_buffer_edge_candidate=cut.is_buffer_edge_candidate,
                metadata={**cut.metadata, "nemo_buffer_id": containing[0].buffer_id},
            )
        )
    return filtered


def build_buffer_lookup(buffers: list[NemoScopeBuffer]) -> dict[str, NemoScopeBuffer]:
    return {buffer.buffer_id: buffer for buffer in buffers}


def generate_legal_candidate_clips_in_buffers(
    *,
    cutpoints: list[Cutpoint],
    constraints: PackingConstraints,
) -> list[CandidateClip]:
    by_buffer: dict[tuple[str, str], list[Cutpoint]] = defaultdict(list)
    for cut in cutpoints:
        by_buffer[(cut.recording_id, cut.buffer_id)].append(cut)
    candidates: list[CandidateClip] = []
    for (recording_id, buffer_id), rows in sorted(by_buffer.items()):
        ordered = sorted(rows, key=lambda row: (row.time_sec, row.cutpoint_id))
        for start_index, start in enumerate(ordered[:-1]):
            for end in ordered[start_index + 1 :]:
                duration_sec = end.time_sec - start.time_sec
                if duration_sec < constraints.min_clip_sec - BOUNDARY_EPSILON_SEC:
                    continue
                if duration_sec > constraints.max_clip_sec + BOUNDARY_EPSILON_SEC:
                    break
                candidates.append(
                    CandidateClip(
                        detector_name=start.detector_name,
                        source_id=start.source_id,
                        recording_id=recording_id,
                        buffer_id=buffer_id,
                        candidate_id=f"{start.detector_name}:{recording_id}:{buffer_id}:{start.cutpoint_id}:{end.cutpoint_id}",
                        start_sec=round(start.time_sec, 6),
                        end_sec=round(end.time_sec, 6),
                        duration_sec=round(duration_sec, 6),
                        start_cutpoint_id=start.cutpoint_id,
                        end_cutpoint_id=end.cutpoint_id,
                        weight=round(_candidate_clip_weight(duration_sec=duration_sec, constraints=constraints), 6),
                    )
                )
    return candidates


def assert_clips_within_single_buffer(
    clips: list[Clip],
    buffers: list[NemoScopeBuffer],
) -> None:
    by_id = {buffer.buffer_id: buffer for buffer in buffers}
    for clip in clips:
        if "|" in clip.buffer_id:
            raise ValueError(f"clip {clip.clip_id} spans multiple buffers: {clip.buffer_id}")
        buffer = by_id.get(clip.buffer_id)
        if buffer is None:
            raise ValueError(f"clip {clip.clip_id} references unknown buffer {clip.buffer_id}")
        if not (buffer.buffer_start_sec + NEMO_WALL_EPSILON_SEC < clip.start_sec < buffer.buffer_end_sec - NEMO_WALL_EPSILON_SEC):
            raise ValueError(f"clip {clip.clip_id} start lies on or outside NeMo buffer wall")
        if not (buffer.buffer_start_sec + NEMO_WALL_EPSILON_SEC < clip.end_sec < buffer.buffer_end_sec - NEMO_WALL_EPSILON_SEC):
            raise ValueError(f"clip {clip.clip_id} end lies on or outside NeMo buffer wall")


def _assert_selected_candidates_single_group(
    selected_candidates: list[CandidateClip],
) -> None:
    for candidate in selected_candidates:
        if not candidate.recording_id:
            raise ValueError(f"selected candidate {candidate.candidate_id} is missing recording_id")
        if not candidate.buffer_id:
            raise ValueError(f"selected candidate {candidate.candidate_id} is missing buffer_id")


def build_boundary_classification_rows(
    *,
    detector_name: str,
    boundary_source: str,
    selected_cutpoints: list[Cutpoint],
    buffers: list[NemoScopeBuffer],
    annotation_rows_by_recording: dict[str, list[dict[str, Any]]],
    interviewer_mask_by_recording: dict[str, list[tuple[float, float]]],
    uncertainty_mask_by_recording: dict[str, list[tuple[float, float]]] | None = None,
) -> list[dict[str, Any]]:
    buffer_by_id = build_buffer_lookup(buffers)
    rows: list[dict[str, Any]] = []
    for cut in selected_cutpoints:
        buffer = buffer_by_id.get(cut.buffer_id)
        if buffer is None:
            raise ValueError(f"selected cutpoint {cut.cutpoint_id} references unknown buffer {cut.buffer_id}")
        classification = classify_boundary(
            speaker_id=buffer.speaker_id,
            recording_id=cut.recording_id,
            buffer=buffer,
            timestamp_sec=cut.time_sec,
            annotation_rows_by_recording=annotation_rows_by_recording,
            interviewer_mask_by_recording=interviewer_mask_by_recording,
            uncertainty_mask_by_recording=uncertainty_mask_by_recording,
        )
        rows.append(
            {
                "detector_name": detector_name,
                "boundary_source": boundary_source,
                "cutpoint_id": cut.cutpoint_id,
                "clip_id": "",
                **classification,
            }
        )
    return rows


def summarize_boundary_severity_by_speaker(
    rows: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[(str(row["speaker_id"]), str(row["detector_name"]))].append(row)
    summary_rows: list[dict[str, Any]] = []
    for (speaker_id, detector_name), items in sorted(grouped.items()):
        target_scope = [row for row in items if not _as_bool(row["inside_interviewer"])]
        target_scope = [row for row in target_scope if not _as_bool(row.get("inside_uncertainty"))]
        speech_failures = [row for row in target_scope if _as_bool(row["inside_target_speech_phone"])]
        leak_depths = [float(row["speech_phone_leak_depth_sec"]) for row in speech_failures if row["speech_phone_leak_depth_sec"] != ""]
        relative_depths = [float(row.get("relative_leak_depth") or 0.0) for row in speech_failures if row.get("relative_leak_depth", "") != ""]
        gt_20 = sum(_as_bool(row["gt_20ms"]) for row in speech_failures)
        gt_50 = sum(_as_bool(row["gt_50ms"]) for row in speech_failures)
        gt_100 = sum(_as_bool(row["gt_100ms"]) for row in speech_failures)
        summary_rows.append(
            {
                "speaker_id": speaker_id,
                "detector_name": detector_name,
                "selected_boundary_count": len(target_scope),
                "inside_target_speech_phone_count": len(speech_failures),
                "inside_target_speech_phone_rate": round(_safe_divide(len(speech_failures), len(target_scope)), 6),
                "inside_annotated_silence_count": sum(_as_bool(row["inside_annotated_silence"]) for row in target_scope),
                "inside_laughter_count": sum(_as_bool(row["inside_laughter"]) for row in target_scope),
                "inside_vocnoise_count": sum(_as_bool(row["inside_vocnoise"]) for row in target_scope),
                "inside_noise_count": sum(_as_bool(row["inside_noise"]) for row in target_scope),
                "inside_boundary_marker_count": sum(_as_bool(row["inside_boundary_marker"]) for row in target_scope),
                "inside_other_annotation_count": sum(_as_bool(row["inside_other_annotation"]) for row in target_scope),
                "outside_all_annotations_count": sum(_as_bool(row["outside_all_annotations"]) for row in target_scope),
                "inside_interviewer_count_excluded_from_denominator": sum(_as_bool(row["inside_interviewer"]) for row in items),
                "inside_uncertainty_count_excluded_from_denominator": sum(_as_bool(row.get("inside_uncertainty")) for row in items),
                "median_speech_phone_leak_depth_sec": _median(leak_depths),
                "p90_speech_phone_leak_depth_sec": _quantile(leak_depths, 0.90),
                "p95_speech_phone_leak_depth_sec": _quantile(leak_depths, 0.95),
                "max_speech_phone_leak_depth_sec": round(max(leak_depths), 6) if leak_depths else None,
                "median_relative_leak_depth": _median(relative_depths),
                "p90_relative_leak_depth": _quantile(relative_depths, 0.90),
                "p95_relative_leak_depth": _quantile(relative_depths, 0.95),
                "speech_phone_failures_gt_20ms": gt_20,
                "speech_phone_failures_gt_50ms": gt_50,
                "speech_phone_failures_gt_100ms": gt_100,
                "speech_phone_failures_gt_25pct_phone": sum(_as_bool(row["gt_25pct_phone"]) for row in speech_failures),
                "speech_phone_failures_gt_50pct_phone": sum(_as_bool(row["gt_50pct_phone"]) for row in speech_failures),
                "speech_phone_failures_gt_20ms_rate": round(_safe_divide(gt_20, len(target_scope)), 6),
                "speech_phone_failures_gt_50ms_rate": round(_safe_divide(gt_50, len(target_scope)), 6),
                "speech_phone_failures_gt_100ms_rate": round(_safe_divide(gt_100, len(target_scope)), 6),
                "speech_phone_failures_gt_50ms_among_errors_rate": round(_safe_divide(gt_50, len(speech_failures)), 6),
            }
        )
    return summary_rows


def summarize_boundary_severity_by_speaker_and_source(
    rows: list[dict[str, Any]],
) -> dict[str, list[dict[str, Any]]]:
    by_source: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_source[str(row["boundary_source"])].append(row)
    unique_rows = by_source.get("detector_selected_cutpoint", [])
    final_rows = [
        row
        for source in ("final_clip_start", "final_clip_end")
        for row in by_source.get(source, [])
    ]
    return {
        "unique_selected_cutpoints": summarize_boundary_severity_by_speaker(unique_rows),
        "final_edge_occurrences": summarize_boundary_severity_by_speaker(final_rows),
    }


def build_in_phone_error_details(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    details: list[dict[str, Any]] = []
    for row in rows:
        if _as_bool(row.get("inside_interviewer")) or _as_bool(row.get("inside_uncertainty")) or not _as_bool(row.get("inside_target_speech_phone")):
            continue
        details.append(
            {
                "speaker_id": str(row["speaker_id"]),
                "recording_id": str(row["recording_id"]),
                "buffer_id": str(row["buffer_id"]),
                "detector_name": str(row["detector_name"]),
                "boundary_source": str(row["boundary_source"]),
                "cutpoint_id": str(row["cutpoint_id"]),
                "clip_id": str(row.get("clip_id") or ""),
                "timestamp_sec": row["timestamp_sec"],
                "phone_label": str(row.get("speech_phone_label") or ""),
                "phone_start_sec": row["phone_start_sec"],
                "phone_end_sec": row["phone_end_sec"],
                "phone_duration_ms": round(float(row["speech_phone_duration_sec"]) * 1000.0, 3),
                "leak_depth_ms": round(float(row["speech_phone_leak_depth_sec"]) * 1000.0, 3),
                "relative_leak_depth": row["relative_leak_depth"],
                "gt_20ms": row["gt_20ms"],
                "gt_50ms": row["gt_50ms"],
                "gt_100ms": row["gt_100ms"],
                "gt_25pct_phone": row["gt_25pct_phone"],
                "gt_50pct_phone": row["gt_50pct_phone"],
            }
        )
    return details


def build_deep_error_review_manifest(
    rows: list[dict[str, Any]],
    *,
    window_sec: float = 0.35,
) -> list[dict[str, Any]]:
    rng = random.Random(0)
    selected: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str]] = set()
    error_rows = build_in_phone_error_details(rows)

    def add_rows(candidates: list[dict[str, Any]], label: str, limit: int) -> None:
        count = 0
        for row in candidates:
            key = (str(row["boundary_source"]), str(row["cutpoint_id"]), str(row["clip_id"]))
            if key in seen:
                continue
            seen.add(key)
            selected.append(
                {
                    **row,
                    "review_bucket": label,
                    "suggested_window_start_sec": round(max(0.0, float(row["timestamp_sec"]) - window_sec), 6),
                    "suggested_window_end_sec": round(float(row["timestamp_sec"]) + window_sec, 6),
                }
            )
            count += 1
            if count >= limit:
                break

    add_rows(sorted(error_rows, key=lambda row: (-float(row["leak_depth_ms"]), row["cutpoint_id"])), "deepest_absolute", 20)
    add_rows(sorted(error_rows, key=lambda row: (-float(row["relative_leak_depth"]), row["cutpoint_id"])), "deepest_relative", 20)
    shallow = [row for row in error_rows if 0.0 <= float(row["leak_depth_ms"]) <= 20.0]
    rng.shuffle(shallow)
    add_rows(shallow, "shallow_random", 20)

    clean_rows = [row for row in rows if not _as_bool(row.get("inside_interviewer")) and not _as_bool(row.get("inside_uncertainty")) and not _as_bool(row.get("inside_target_speech_phone"))]
    rng.shuffle(clean_rows)
    for row in clean_rows[:20]:
        selected.append(
            {
                "speaker_id": str(row["speaker_id"]),
                "recording_id": str(row["recording_id"]),
                "buffer_id": str(row["buffer_id"]),
                "detector_name": str(row["detector_name"]),
                "boundary_source": str(row["boundary_source"]),
                "cutpoint_id": str(row["cutpoint_id"]),
                "clip_id": str(row.get("clip_id") or ""),
                "timestamp_sec": row["timestamp_sec"],
                "phone_label": "",
                "phone_start_sec": "",
                "phone_end_sec": "",
                "phone_duration_ms": "",
                "leak_depth_ms": "",
                "relative_leak_depth": "",
                "gt_20ms": False,
                "gt_50ms": False,
                "gt_100ms": False,
                "gt_25pct_phone": False,
                "gt_50pct_phone": False,
                "review_bucket": "clean_random",
                "suggested_window_start_sec": round(max(0.0, float(row["timestamp_sec"]) - window_sec), 6),
                "suggested_window_end_sec": round(float(row["timestamp_sec"]) + window_sec, 6),
            }
        )
    return selected


def _read_csv_from_in_phone_details_and_sources(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    converted: list[dict[str, Any]] = []
    for row in rows:
        converted.append(
            {
                "speaker_id": row["speaker_id"],
                "detector_name": row["detector_name"],
                "boundary_source": row["boundary_source"],
                "speech_phone_leak_depth_sec": round(_safe_divide(float(row.get("leak_depth_ms") or 0.0), 1000.0), 6),
                "relative_leak_depth": float(row.get("relative_leak_depth") or 0.0),
            }
        )
    return converted


def _plot_boundary_error_figures(
    *,
    rows: list[dict[str, Any]],
    figures_dir: Path,
) -> None:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt  # noqa: F401
    except ModuleNotFoundError:
        return

    figures_dir.mkdir(parents=True, exist_ok=True)
    unique_rows = [
        row for row in rows
        if str(row.get("boundary_source")) == "detector_selected_cutpoint"
        and _as_bool(row.get("inside_target_speech_phone"))
        and not _as_bool(row.get("inside_interviewer"))
    ]
    final_rows = [
        row for row in rows
        if str(row.get("boundary_source")) in {"final_clip_start", "final_clip_end"}
        and _as_bool(row.get("inside_target_speech_phone"))
        and not _as_bool(row.get("inside_interviewer"))
    ]
    _plot_leak_depth_ecdf_by_speaker(unique_rows, figures_dir / "leak_depth_ecdf_unique_cutpoints_by_speaker.png")
    _plot_leak_depth_ecdf_pooled(unique_rows, figures_dir / "leak_depth_ecdf_unique_cutpoints_pooled.png")
    _plot_relative_leak_depth_ecdf_pooled(unique_rows, figures_dir / "relative_leak_depth_ecdf_pooled.png")
    _plot_leak_depth_histogram_by_speaker(unique_rows, figures_dir / "leak_depth_histogram_unique_cutpoints_by_speaker.png")
    _plot_leak_depth_ecdf_pooled(final_rows, figures_dir / "leak_depth_ecdf_final_edges_pooled.png")


def _plot_leak_depth_ecdf_by_speaker(rows: list[dict[str, Any]], path: Path) -> None:
    if not rows:
        return
    import matplotlib.pyplot as plt

    by_speaker: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_speaker[str(row["speaker_id"])].append(row)
    fig, axes = plt.subplots(len(by_speaker), 1, figsize=(9, max(4, 3 * len(by_speaker))), squeeze=False)
    for ax, speaker_id in zip(axes.flatten(), sorted(by_speaker)):
        speaker_rows = by_speaker[speaker_id]
        for detector_name in sorted({str(row["detector_name"]) for row in speaker_rows}):
            depths = sorted(
                float(row["speech_phone_leak_depth_sec"]) * 1000.0
                for row in speaker_rows
                if str(row["detector_name"]) == detector_name
            )
            if not depths:
                continue
            ys = [(index + 1) / len(depths) for index in range(len(depths))]
            ax.step(depths, ys, where="post", label=detector_name)
        for ref_ms in (20.0, 50.0, 100.0):
            ax.axvline(ref_ms, linestyle="--", color="grey", linewidth=0.8)
        ax.set_title(f"{speaker_id} unique selected cutpoints")
        ax.set_xlabel("Leak depth (ms)")
        ax.set_ylabel("ECDF")
        ax.set_xlim(left=0.0)
        ax.set_ylim(0.0, 1.0)
        ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def _plot_leak_depth_ecdf_pooled(rows: list[dict[str, Any]], path: Path) -> None:
    if not rows:
        return
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(9, 5))
    for detector_name in sorted({str(row["detector_name"]) for row in rows}):
        depths = sorted(
            float(row["speech_phone_leak_depth_sec"]) * 1000.0
            for row in rows
            if str(row["detector_name"]) == detector_name
        )
        if not depths:
            continue
        ys = [(index + 1) / len(depths) for index in range(len(depths))]
        ax.step(depths, ys, where="post", label=detector_name)
    for ref_ms in (20.0, 50.0, 100.0):
        ax.axvline(ref_ms, linestyle="--", color="grey", linewidth=0.8)
    ax.set_xlabel("Leak depth (ms)")
    ax.set_ylabel("ECDF")
    ax.set_xlim(left=0.0)
    ax.set_ylim(0.0, 1.0)
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def _plot_leak_depth_histogram_pooled(rows: list[dict[str, Any]], path: Path, *, title: str) -> None:
    if not rows:
        return
    import matplotlib.pyplot as plt

    bins = [(0.0, 10.0), (10.0, 20.0), (20.0, 50.0), (50.0, 100.0), (100.0, 200.0), (200.0, float("inf"))]
    labels = ["0-10", "10-20", "20-50", "50-100", "100-200", ">200"]
    detector_names = sorted({str(row["detector_name"]) for row in rows})
    fig, ax = plt.subplots(figsize=(10, 5))
    x = list(range(len(labels)))
    width = 0.8 / max(1, len(detector_names))
    for det_index, detector_name in enumerate(detector_names):
        counts = []
        det_rows = [row for row in rows if str(row["detector_name"]) == detector_name]
        for start, end in bins:
            counts.append(sum(start <= float(row["speech_phone_leak_depth_sec"]) * 1000.0 < end for row in det_rows))
        offsets = [value + ((det_index - (len(detector_names) - 1) / 2.0) * width) for value in x]
        ax.bar(offsets, counts, width=width, label=detector_name)
    ax.set_title(title)
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.set_xlabel("Leak depth bin (ms)")
    ax.set_ylabel("Count")
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def _plot_relative_leak_depth_ecdf_pooled(rows: list[dict[str, Any]], path: Path) -> None:
    if not rows:
        return
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(9, 5))
    for detector_name in sorted({str(row["detector_name"]) for row in rows}):
        values = sorted(
            float(row["relative_leak_depth"])
            for row in rows
            if str(row["detector_name"]) == detector_name
        )
        if not values:
            continue
        ys = [(index + 1) / len(values) for index in range(len(values))]
        ax.step(values, ys, where="post", label=detector_name)
    for ref in (0.25, 0.50):
        ax.axvline(ref, linestyle="--", color="grey", linewidth=0.8)
    ax.set_xlabel("Relative leak depth")
    ax.set_ylabel("ECDF")
    ax.set_xlim(left=0.0, right=1.0)
    ax.set_ylim(0.0, 1.0)
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def _plot_leak_depth_histogram_by_speaker(rows: list[dict[str, Any]], path: Path) -> None:
    if not rows:
        return
    import matplotlib.pyplot as plt

    bins = [(0.0, 10.0), (10.0, 20.0), (20.0, 50.0), (50.0, 100.0), (100.0, 200.0), (200.0, float("inf"))]
    labels = ["0-10", "10-20", "20-50", "50-100", "100-200", ">200"]
    by_speaker: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_speaker[str(row["speaker_id"])].append(row)
    fig, axes = plt.subplots(len(by_speaker), 1, figsize=(10, max(4, 3 * len(by_speaker))), squeeze=False)
    for ax, speaker_id in zip(axes.flatten(), sorted(by_speaker)):
        speaker_rows = by_speaker[speaker_id]
        detector_names = sorted({str(row["detector_name"]) for row in speaker_rows})
        x = list(range(len(labels)))
        width = 0.8 / max(1, len(detector_names))
        for det_index, detector_name in enumerate(detector_names):
            counts = []
            det_rows = [row for row in speaker_rows if str(row["detector_name"]) == detector_name]
            for start, end in bins:
                counts.append(sum(start <= float(row["speech_phone_leak_depth_sec"]) * 1000.0 < end for row in det_rows))
            offsets = [value + ((det_index - (len(detector_names) - 1) / 2.0) * width) for value in x]
            ax.bar(offsets, counts, width=width, label=detector_name)
        ax.set_title(f"{speaker_id} unique selected cutpoints")
        ax.set_xticks(x)
        ax.set_xticklabels(labels)
        ax.set_xlabel("Leak depth bin (ms)")
        ax.set_ylabel("Count")
        ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def _plot_safety_coverage_scatter(
    rows: list[dict[str, Any]],
    *,
    x_key: str,
    y_key: str,
    path: Path,
    y_label: str,
) -> None:
    if not rows:
        return
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ModuleNotFoundError:
        return
    by_detector: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_detector[str(row["detector_name"])].append(row)
    fig, ax = plt.subplots(figsize=(9, 6))
    for detector_name in sorted(by_detector):
        detector_rows = by_detector[detector_name]
        x = sum(float(row.get(x_key, 0.0) or 0.0) for row in detector_rows) / len(detector_rows)
        y = sum(float(row.get(y_key, 0.0) or 0.0) for row in detector_rows) / len(detector_rows)
        ax.scatter([x], [y], label=detector_name)
        ax.annotate(detector_name, (x, y), fontsize=8, xytext=(4, 4), textcoords="offset points")
    ax.set_xlabel("Conditional target-phone coverage")
    ax.set_ylabel(y_label)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def classify_boundary(
    *,
    speaker_id: str,
    recording_id: str,
    buffer: NemoScopeBuffer,
    timestamp_sec: float,
    annotation_rows_by_recording: dict[str, list[dict[str, Any]]],
    interviewer_mask_by_recording: dict[str, list[tuple[float, float]]],
    uncertainty_mask_by_recording: dict[str, list[tuple[float, float]]] | None = None,
) -> dict[str, Any]:
    annotations = annotation_rows_by_recording.get(recording_id, [])
    containing = [row for row in annotations if float(row["start_sec"]) <= timestamp_sec < float(row["end_sec"])]
    by_class = {str(row["annotation_class"]): row for row in containing}
    speech_row = by_class.get("speech")
    silence_row = by_class.get("silence")
    laughter_row = by_class.get("laughter")
    vocnoise_row = by_class.get("vocnoise")
    noise_row = by_class.get("noise")
    interviewer_inside = any(start <= timestamp_sec < end for start, end in interviewer_mask_by_recording.get(recording_id, []))
    uncertainty_inside = any(start <= timestamp_sec < end for start, end in (uncertainty_mask_by_recording or {}).get(recording_id, []))
    distance_to_start = max(0.0, timestamp_sec - buffer.buffer_start_sec)
    distance_to_end = max(0.0, buffer.buffer_end_sec - timestamp_sec)
    row: dict[str, Any] = {
        "speaker_id": speaker_id,
        "recording_id": recording_id,
        "buffer_id": buffer.buffer_id,
        "timestamp_sec": round(timestamp_sec, 6),
        "inside_target_speech_phone": speech_row is not None,
        "speech_phone_label": "" if speech_row is None else speech_row["label"],
        "inside_annotated_silence": silence_row is not None,
        "inside_laughter": laughter_row is not None,
        "inside_vocnoise": vocnoise_row is not None,
        "inside_noise": noise_row is not None,
        "inside_interviewer": interviewer_inside,
        "inside_uncertainty": uncertainty_inside,
        "inside_boundary_marker": "boundary_marker" in by_class,
        "inside_other_annotation": "other_annotation" in by_class,
        "outside_all_annotations": not containing,
        "distance_to_nemo_start": round(distance_to_start, 6),
        "distance_to_nemo_end": round(distance_to_end, 6),
        "phone_start_sec": "",
        "phone_end_sec": "",
    }
    if speech_row is None:
        row.update(
            {
                "speech_phone_duration_sec": "",
                "speech_phone_leak_depth_sec": "",
                "distance_from_phone_start_sec": "",
                "distance_from_phone_end_sec": "",
                "relative_leak_depth": "",
                "gt_20ms": False,
                "gt_50ms": False,
                "gt_100ms": False,
                "gt_25pct_phone": False,
                "gt_50pct_phone": False,
            }
        )
        return row
    phone_start = float(speech_row["start_sec"])
    phone_end = float(speech_row["end_sec"])
    phone_duration = phone_end - phone_start
    depth = min(timestamp_sec - phone_start, phone_end - timestamp_sec)
    relative = depth / phone_duration if phone_duration > 0 else 0.0
    row.update(
        {
            "phone_start_sec": round(phone_start, 6),
            "phone_end_sec": round(phone_end, 6),
            "speech_phone_duration_sec": round(phone_duration, 6),
            "speech_phone_leak_depth_sec": round(depth, 6),
            "distance_from_phone_start_sec": round(timestamp_sec - phone_start, 6),
            "distance_from_phone_end_sec": round(phone_end - timestamp_sec, 6),
            "relative_leak_depth": round(relative, 6),
            "gt_20ms": depth > 0.020,
            "gt_50ms": depth > 0.050,
            "gt_100ms": depth > 0.100,
            "gt_25pct_phone": relative > 0.25,
            "gt_50pct_phone": relative > 0.50,
        }
    )
    return row


def compute_clip_coverage_metrics(
    *,
    clips: list[Clip],
    buffers: list[NemoScopeBuffer],
    target_reference_by_recording: dict[str, list[tuple[float, float]]],
    all_target_reference_by_recording: dict[str, list[tuple[float, float]]] | None = None,
) -> dict[str, Any]:
    clip_intervals_by_recording: dict[str, list[tuple[float, float]]] = defaultdict(list)
    buffer_intervals_by_recording: dict[str, list[tuple[float, float]]] = defaultdict(list)
    for clip in clips:
        clip_intervals_by_recording[clip.recording_id].append((clip.start_sec, clip.end_sec))
    for buffer in buffers:
        buffer_intervals_by_recording[buffer.recording_id].append((buffer.buffer_start_sec, buffer.buffer_end_sec))
    clip_union = sum(_interval_union_duration(rows) for rows in clip_intervals_by_recording.values())
    emitted_sum = sum(clip.duration_sec for clip in clips)
    conditional_total = sum(_interval_union_duration(rows) for rows in target_reference_by_recording.values())
    conditional_covered = sum(
        _overlap_intervals(clip_intervals_by_recording.get(recording_id, []), rows)
        for recording_id, rows in target_reference_by_recording.items()
    )
    all_reference = target_reference_by_recording if all_target_reference_by_recording is None else all_target_reference_by_recording
    end_to_end_total = sum(_interval_union_duration(rows) for rows in all_reference.values())
    end_to_end_covered = sum(
        _overlap_intervals(clip_intervals_by_recording.get(recording_id, []), rows)
        for recording_id, rows in all_reference.items()
    )
    target_density_by_clip = []
    zero_target = 0
    below_10pct = 0
    for clip in clips:
        covered = _overlap_intervals([(clip.start_sec, clip.end_sec)], target_reference_by_recording.get(clip.recording_id, []))
        density = _safe_divide(covered, clip.duration_sec)
        target_density_by_clip.append(density)
        if covered <= BOUNDARY_EPSILON_SEC:
            zero_target += 1
        if density < 0.10:
            below_10pct += 1
    buffer_target_total = sum(
        _overlap_intervals(buffer_intervals_by_recording.get(recording_id, []), rows)
        for recording_id, rows in target_reference_by_recording.items()
    )
    return {
        "conditional_target_phone_coverage": round(_safe_divide(conditional_covered, conditional_total), 6),
        "end_to_end_target_phone_coverage": round(_safe_divide(end_to_end_covered, end_to_end_total), 6),
        "pooled_target_speech_density": round(_safe_divide(conditional_covered, emitted_sum), 6),
        "median_clip_target_speech_density": _median(target_density_by_clip),
        "zero_target_speech_clip_rate": round(_safe_divide(zero_target, len(clips)), 6),
        "clips_below_10pct_target_speech_rate": round(_safe_divide(below_10pct, len(clips)), 6),
        "target_speech_stranded_in_unusable_nemo_buffers_sec": round(max(0.0, buffer_target_total - conditional_covered), 6),
        "clip_union_duration_sec": round(clip_union, 6),
        "clip_emitted_sum_sec": round(emitted_sum, 6),
    }


def write_parser_artifact_manifest(
    *,
    normalized_speaker_dir: Path,
    out_dir: Path,
) -> None:
    artifact_names = (
        "reference_words.csv",
        "reference_phones.csv",
        "phone_label_inventory.csv",
        "word_annotation_inventory.csv",
        "unknown_labels.csv",
        "malformed_rows.csv",
        "annotation_coverage_by_recording.csv",
        "uncertainty_masks.csv",
        "correction_manifest.csv",
        "excluded_recordings.csv",
        "reference_reconciliation.csv",
        "BUCKEYE_INGEST_VALIDATION.md",
    )
    rows: list[dict[str, Any]] = []
    for name in artifact_names:
        path = normalized_speaker_dir / name
        rows.append(
            {
                "artifact_name": name,
                "path": str(path),
                "exists": path.exists(),
            }
        )
    write_csv(
        out_dir / "parser_artifact_manifest.csv",
        rows,
        fieldnames=["artifact_name", "path", "exists"],
    )


def require_parser_artifacts(normalized_speaker_dir: Path) -> dict[str, Path]:
    required = {
        "reference_words": normalized_speaker_dir / "reference_words.csv",
        "reference_phones": normalized_speaker_dir / "reference_phones.csv",
        "phone_label_inventory": normalized_speaker_dir / "phone_label_inventory.csv",
        "word_annotation_inventory": normalized_speaker_dir / "word_annotation_inventory.csv",
        "unknown_labels": normalized_speaker_dir / "unknown_labels.csv",
        "malformed_rows": normalized_speaker_dir / "malformed_rows.csv",
        "annotation_coverage": normalized_speaker_dir / "annotation_coverage_by_recording.csv",
        "uncertainty_masks": normalized_speaker_dir / "uncertainty_masks.csv",
        "correction_manifest": normalized_speaker_dir / "correction_manifest.csv",
        "excluded_recordings": normalized_speaker_dir / "excluded_recordings.csv",
        "reference_reconciliation": normalized_speaker_dir / "reference_reconciliation.csv",
        "ingest_validation": normalized_speaker_dir / "BUCKEYE_INGEST_VALIDATION.md",
    }
    missing = [name for name, path in required.items() if not path.exists()]
    if missing:
        raise ValueError(
            f"normalized Buckeye artifacts are missing under {normalized_speaker_dir}: {missing}. "
            "Regenerate ingest with the repaired parser before running the repaired benchmark."
        )
    unknown_rows = _read_csv(required["unknown_labels"])
    if unknown_rows:
        raise ValueError(
            f"unknown_labels.csv for {normalized_speaker_dir.name} is not empty; repaired benchmark refuses to run"
        )
    return required


def load_uncertainty_masks_by_recording(uncertainty_masks_csv: Path) -> dict[str, list[tuple[float, float]]]:
    rows = _read_csv(uncertainty_masks_csv)
    by_recording: dict[str, list[tuple[float, float]]] = defaultdict(list)
    for row in rows:
        by_recording[str(row["recording_id"])].append((float(row["start_sec"]), float(row["end_sec"])))
    return {recording_id: merge_intervals(intervals) for recording_id, intervals in by_recording.items()}


def load_recording_eligibility(
    *,
    reference_reconciliation_csv: Path,
    excluded_recordings_csv: Path,
) -> tuple[set[str], set[str]]:
    included_recording_ids = {
        str(row["recording_id"])
        for row in _read_csv(reference_reconciliation_csv)
    }
    excluded_recording_ids = {
        str(row["recording_id"])
        for row in _read_csv(excluded_recordings_csv)
    }
    return included_recording_ids, excluded_recording_ids


def _filter_sources_to_included_recordings(
    sources: dict[str, SourceInfo],
    included_recording_ids: set[str],
) -> dict[str, SourceInfo]:
    return {
        source_id: source
        for source_id, source in sources.items()
        if source.recording_id in included_recording_ids
    }


def _assert_rows_in_included_recordings(
    *,
    rows: list[Any],
    included_recording_ids: set[str],
    row_label: str,
) -> None:
    def _recording_id(row: Any) -> str:
        if isinstance(row, dict):
            return str(row.get("recording_id"))
        return str(getattr(row, "recording_id"))

    outside = sorted({_recording_id(row) for row in rows if _recording_id(row) not in included_recording_ids})
    if outside:
        raise ValueError(f"{row_label} include out-of-scope recordings: {outside}")


def _assert_boundary_rows_in_included_recordings(
    rows: list[dict[str, Any]],
    included_recording_ids: set[str],
) -> None:
    outside = sorted({str(row["recording_id"]) for row in rows if str(row["recording_id"]) not in included_recording_ids})
    if outside:
        raise ValueError(f"boundary rows include out-of-scope recordings: {outside}")


def build_annotation_rows(
    *,
    reference_words: list[dict[str, Any]],
    reference_phones: list[dict[str, Any]],
    interviewer_mask_by_recording: dict[str, list[tuple[float, float]]],
    uncertainty_mask_by_recording: dict[str, list[tuple[float, float]]] | None = None,
) -> dict[str, list[dict[str, Any]]]:
    by_recording = build_phone_annotations(
        reference_phones,
        interviewer_mask_by_recording=interviewer_mask_by_recording,
        uncertainty_mask_by_recording=uncertainty_mask_by_recording,
    )
    for row in reference_words:
        if _as_bool(row.get("is_lexical_word")):
            continue
        event_type = str(row.get("event_type") or "")
        if event_type in {"", "interviewer", "unknown"}:
            continue
        annotation_class = event_type if event_type in {
            "silence",
            "laughter",
            "vocnoise",
            "noise",
            "boundary_marker",
            "other_annotation",
        } else "other_annotation"
        by_recording[str(row["recording_id"])].append(
            {
                "recording_id": str(row["recording_id"]),
                "start_sec": float(row["start_sec"]),
                "end_sec": float(row["end_sec"]),
                "label": str(row.get("normalized_label") or row.get("raw_label") or ""),
                "annotation_class": annotation_class,
            }
        )
    return {
        recording_id: sorted(rows, key=lambda row: (float(row["start_sec"]), float(row["end_sec"]), str(row["label"])))
        for recording_id, rows in by_recording.items()
    }


def build_buffer_rows_from_nemo_buffers(
    buffers: list[NemoScopeBuffer],
) -> dict[str, dict[str, Any]]:
    return {
        buffer.buffer_id: {
            "buffer_id": buffer.buffer_id,
            "source_audio_id": buffer.source_audio_id,
            "recording_id": buffer.recording_id,
            "source_start_sec": buffer.buffer_start_sec,
            "source_end_sec": buffer.buffer_end_sec,
            "trusted_start_sec": buffer.buffer_start_sec,
            "trusted_end_sec": buffer.buffer_end_sec,
        }
        for buffer in buffers
    }


def supported_repaired_detectors() -> dict[str, Any]:
    vad_only = VadLocalMinimaDetector()
    rms_only = RmsMinimaDetector()
    percentile_rms_only = _NamedDetector("percentile_rms_only", PercentileRmsDetector())
    local_prominence_rms_only = _NamedDetector("local_prominence_rms_only", LocalProminenceRmsDetector())
    adaptive_rms_only = _NamedDetector("all_local_rms_minima", AdaptiveLocalRmsDetector())
    return {
        "vad_only": vad_only,
        "rms_only": rms_only,
        "percentile_rms_only": percentile_rms_only,
        "local_prominence_rms_only": local_prominence_rms_only,
        "legacy_vad_rms": VadRmsDetector(),
        "vad_percentile_rms": VadPercentileRmsDetector(),
        "vad_local_prominence_rms": VadLocalProminenceRmsDetector(),
        "rms_vad_veto": RmsVadVetoDetector(),
        "vad_or_percentile_rms": UnionDetector("vad_or_percentile_rms", (VadLocalMinimaDetector(), PercentileRmsDetector())),
        "vad_or_local_prominence_rms": UnionDetector("vad_or_local_prominence_rms", (VadLocalMinimaDetector(), LocalProminenceRmsDetector())),
        "vad_or_adaptive_rms": UnionDetector("vad_or_adaptive_rms", (VadLocalMinimaDetector(), AdaptiveLocalRmsDetector())),
        "vad_and_percentile_rms": _IntersectionDetector("vad_and_percentile_rms", VadLocalMinimaDetector(), PercentileRmsDetector()),
        "vad_and_local_prominence_rms": _IntersectionDetector("vad_and_local_prominence_rms", VadLocalMinimaDetector(), LocalProminenceRmsDetector()),
        "all_local_rms_minima": adaptive_rms_only,
        "uniform_grid_250ms": _UniformGridDetector("uniform_grid_250ms", spacing_sec=0.25),
        "uniform_grid_500ms": _UniformGridDetector("uniform_grid_500ms", spacing_sec=0.50),
    }


def default_repaired_matrix_detector_names() -> list[str]:
    return [
        "production_safecut_optimal",
        "legacy_vad_rms",
        "vad_only",
        "vad_percentile_rms",
        "vad_local_prominence_rms",
        "rms_vad_veto",
        "rms_only",
        "percentile_rms_only",
        "local_prominence_rms_only",
        "vad_or_percentile_rms",
        "vad_or_local_prominence_rms",
        "vad_or_adaptive_rms",
        "vad_and_percentile_rms",
        "vad_and_local_prominence_rms",
        "all_local_rms_minima",
        "uniform_grid_250ms",
        "uniform_grid_500ms",
    ]


class _NamedDetector:
    def __init__(self, name: str, detector: Any) -> None:
        self.name = name
        self.detector = detector

    def find_cutpoints(self, contexts: BenchmarkContexts) -> DetectorRunResult:
        result = self.detector.find_cutpoints(contexts)
        cuts = [
            Cutpoint(
                detector_name=self.name,
                source_id=cut.source_id,
                recording_id=cut.recording_id,
                buffer_id=cut.buffer_id,
                cutpoint_id=f"{self.name}:{cut.cutpoint_id}",
                time_sec=cut.time_sec,
                interval_start_sec=cut.interval_start_sec,
                interval_end_sec=cut.interval_end_sec,
                score=cut.score,
                vad_min=cut.vad_min,
                vad_mean=cut.vad_mean,
                vad_longest_below_0_1_ms=cut.vad_longest_below_0_1_ms,
                vad_longest_below_0_2_ms=cut.vad_longest_below_0_2_ms,
                rms_min_dbfs=cut.rms_min_dbfs,
                rms_mean_dbfs=cut.rms_mean_dbfs,
                voicing_min=cut.voicing_min,
                voicing_mean=cut.voicing_mean,
                compute_time_sec=cut.compute_time_sec,
                is_buffer_edge_candidate=cut.is_buffer_edge_candidate,
                metadata={**cut.metadata, "component_detector": cut.detector_name},
            )
            for cut in result.cutpoints
        ]
        metric = ComputeMetric(**{**asdict(result.compute_metric), "detector_name": self.name})
        return DetectorRunResult(
            cutpoints=cuts,
            compute_metric=metric,
            searched_buffer_ids=result.searched_buffer_ids,
            searched_duration_sec=result.searched_duration_sec,
            searched_interval_count=result.searched_interval_count,
            uses_asr=result.uses_asr,
            uses_mfa=result.uses_mfa,
            uses_aligned_words=result.uses_aligned_words,
            uses_alignment_qc=result.uses_alignment_qc,
            validity_notes=result.validity_notes,
        )


class _IntersectionDetector:
    def __init__(self, name: str, left: Any, right: Any) -> None:
        self.name = name
        self.left = left
        self.right = right

    def find_cutpoints(self, contexts: BenchmarkContexts) -> DetectorRunResult:
        left_result = self.left.find_cutpoints(contexts)
        right_result = self.right.find_cutpoints(contexts)
        right_index: dict[tuple[str, str, int], Cutpoint] = {
            (cut.recording_id, cut.buffer_id, int(round(cut.time_sec * 1000.0))): cut
            for cut in right_result.cutpoints
        }
        cuts: list[Cutpoint] = []
        for cut in left_result.cutpoints:
            key = (cut.recording_id, cut.buffer_id, int(round(cut.time_sec * 1000.0)))
            partner = right_index.get(key)
            if partner is None:
                continue
            cuts.append(
                Cutpoint(
                    detector_name=self.name,
                    source_id=cut.source_id,
                    recording_id=cut.recording_id,
                    buffer_id=cut.buffer_id,
                    cutpoint_id=f"{self.name}:{cut.cutpoint_id}|{partner.cutpoint_id}",
                    time_sec=cut.time_sec,
                    interval_start_sec=max(cut.interval_start_sec, partner.interval_start_sec),
                    interval_end_sec=min(cut.interval_end_sec, partner.interval_end_sec),
                    score=max(cut.score, partner.score),
                    vad_min=cut.vad_min if cut.vad_min is not None else partner.vad_min,
                    vad_mean=cut.vad_mean if cut.vad_mean is not None else partner.vad_mean,
                    vad_longest_below_0_1_ms=cut.vad_longest_below_0_1_ms if cut.vad_longest_below_0_1_ms is not None else partner.vad_longest_below_0_1_ms,
                    vad_longest_below_0_2_ms=cut.vad_longest_below_0_2_ms if cut.vad_longest_below_0_2_ms is not None else partner.vad_longest_below_0_2_ms,
                    rms_min_dbfs=cut.rms_min_dbfs if cut.rms_min_dbfs is not None else partner.rms_min_dbfs,
                    rms_mean_dbfs=cut.rms_mean_dbfs if cut.rms_mean_dbfs is not None else partner.rms_mean_dbfs,
                    voicing_min=cut.voicing_min if cut.voicing_min is not None else partner.voicing_min,
                    voicing_mean=cut.voicing_mean if cut.voicing_mean is not None else partner.voicing_mean,
                    compute_time_sec=0.0,
                    is_buffer_edge_candidate=cut.is_buffer_edge_candidate or partner.is_buffer_edge_candidate,
                    metadata={
                        "left_component_detector": cut.detector_name,
                        "right_component_detector": partner.detector_name,
                    },
                )
            )
        wall = left_result.compute_metric.wall_clock_sec + right_result.compute_metric.wall_clock_sec
        cpu = left_result.compute_metric.cpu_time_sec + right_result.compute_metric.cpu_time_sec
        metric = ComputeMetric(
            detector_name=self.name,
            wall_clock_sec=round(wall, 6),
            cpu_time_sec=round(cpu, 6),
            gpu_time_sec=None,
            peak_rss_mb=max(left_result.compute_metric.peak_rss_mb or 0.0, right_result.compute_metric.peak_rss_mb or 0.0) or None,
            peak_gpu_memory_mb=None,
            real_time_factor=_safe_divide(wall, _total_source_duration(contexts.shared.sources)),
            model_init_time_sec=0.0,
            per_hour_audio_cost_sec=_safe_divide(3600.0 * wall, _total_source_duration(contexts.shared.sources)),
            external_model_dependencies=tuple(sorted(set(left_result.compute_metric.external_model_dependencies + right_result.compute_metric.external_model_dependencies))),
            notes="Intersection detector keeps only millisecond-matched cutpoints from both component detectors.",
        )
        searched = left_result.searched_buffer_ids | right_result.searched_buffer_ids
        searched_duration_sec = _buffer_union_duration(
            buffer_ids=set(searched),
            buffer_by_id=contexts.shared.buffer_by_id,
            sources=contexts.shared.sources,
        )
        return DetectorRunResult(
            cutpoints=_dedupe_cutpoints(cuts),
            compute_metric=metric,
            searched_buffer_ids=searched,
            searched_duration_sec=round(searched_duration_sec, 6),
            searched_interval_count=len(searched),
            uses_asr=left_result.uses_asr or right_result.uses_asr,
            uses_mfa=left_result.uses_mfa or right_result.uses_mfa,
            uses_aligned_words=left_result.uses_aligned_words or right_result.uses_aligned_words,
            uses_alignment_qc=left_result.uses_alignment_qc or right_result.uses_alignment_qc,
            validity_notes="Intersection detector keeps only source-local millisecond-matched candidates from both components.",
        )


class _UniformGridDetector:
    def __init__(self, name: str, *, spacing_sec: float) -> None:
        self.name = name
        self.spacing_sec = spacing_sec

    def find_cutpoints(self, contexts: BenchmarkContexts) -> DetectorRunResult:
        cuts: list[Cutpoint] = []
        searched_buffer_ids: set[str] = set()
        for buffer_id, buffer in sorted(contexts.shared.buffer_by_id.items()):
            start_sec = float(buffer["trusted_start_sec"])
            end_sec = float(buffer["trusted_end_sec"])
            duration_sec = end_sec - start_sec
            if duration_sec <= self.spacing_sec:
                continue
            searched_buffer_ids.add(buffer_id)
            source = contexts.shared.sources[str(buffer["source_audio_id"])]
            step_index = 1
            while True:
                center = start_sec + (step_index * self.spacing_sec)
                if center >= end_sec - EPSILON_SEC:
                    break
                stats = _window_feature_stats(
                    contexts.acoustic.audio_feature_cache[source.recording_id],
                    center - 0.05,
                    center + 0.05,
                )
                cuts.append(
                    Cutpoint(
                        detector_name=self.name,
                        source_id=source.source_audio_id,
                        recording_id=source.recording_id,
                        buffer_id=buffer_id,
                        cutpoint_id=f"{buffer_id}-{self.name}-{int(round(center * 1000.0))}",
                        time_sec=round(center, 6),
                        interval_start_sec=round(max(start_sec, center - (self.spacing_sec / 2.0)), 6),
                        interval_end_sec=round(min(end_sec, center + (self.spacing_sec / 2.0)), 6),
                        score=0.0,
                        vad_min=stats["vad_min"],
                        vad_mean=stats["vad_mean"],
                        vad_longest_below_0_1_ms=stats["vad_longest_below_0_1_ms"],
                        vad_longest_below_0_2_ms=stats["vad_longest_below_0_2_ms"],
                        rms_min_dbfs=stats["rms_min_dbfs"],
                        rms_mean_dbfs=stats["rms_mean_dbfs"],
                        voicing_min=stats["voicing_min"],
                        voicing_mean=stats["voicing_mean"],
                        compute_time_sec=0.0,
                        is_buffer_edge_candidate=False,
                        metadata={"grid_spacing_sec": self.spacing_sec},
                    )
                )
                step_index += 1
        searched_duration_sec = _buffer_union_duration(
            buffer_ids=searched_buffer_ids,
            buffer_by_id=contexts.shared.buffer_by_id,
            sources=contexts.shared.sources,
        )
        metric = ComputeMetric(
            detector_name=self.name,
            wall_clock_sec=0.0,
            cpu_time_sec=0.0,
            gpu_time_sec=None,
            peak_rss_mb=None,
            peak_gpu_memory_mb=None,
            real_time_factor=0.0,
            model_init_time_sec=0.0,
            per_hour_audio_cost_sec=0.0,
            external_model_dependencies=tuple(),
            notes="Uniform grid control baseline inside raw NeMo buffers.",
        )
        return DetectorRunResult(
            cutpoints=cuts,
            compute_metric=metric,
            searched_buffer_ids=frozenset(searched_buffer_ids),
            searched_duration_sec=round(searched_duration_sec, 6),
            searched_interval_count=len(searched_buffer_ids),
            uses_asr=False,
            uses_mfa=False,
            uses_aligned_words=False,
            uses_alignment_qc=False,
            validity_notes="Uniform grid control baseline.",
        )


def _compute_metric_row(
    *,
    speaker_id: str,
    detector_name: str,
    compute_metric: ComputeMetric,
) -> dict[str, Any]:
    wall_clock_sec = float(getattr(compute_metric, "wall_clock_sec", 0.0) or 0.0)
    cpu_time_sec = float(getattr(compute_metric, "cpu_time_sec", 0.0) or 0.0)
    gpu_time_sec = getattr(compute_metric, "gpu_time_sec", None)
    peak_rss_mb = getattr(compute_metric, "peak_rss_mb", None)
    peak_gpu_memory_mb = getattr(compute_metric, "peak_gpu_memory_mb", None)
    real_time_factor = float(getattr(compute_metric, "real_time_factor", 0.0) or 0.0)
    model_init_time_sec = float(getattr(compute_metric, "model_init_time_sec", 0.0) or 0.0)
    per_hour_audio_cost_sec = float(getattr(compute_metric, "per_hour_audio_cost_sec", 0.0) or 0.0)
    external_model_dependencies = tuple(getattr(compute_metric, "external_model_dependencies", tuple()) or tuple())
    notes = str(getattr(compute_metric, "notes", "") or "")
    return {
        "speaker_id": speaker_id,
        "detector_name": detector_name,
        "wall_clock_sec": round(wall_clock_sec, 6),
        "cpu_time_sec": round(cpu_time_sec, 6),
        "gpu_time_sec": gpu_time_sec,
        "peak_rss_mb": peak_rss_mb,
        "peak_gpu_memory_mb": peak_gpu_memory_mb,
        "real_time_factor": round(real_time_factor, 6),
        "model_init_time_sec": round(model_init_time_sec, 6),
        "per_hour_audio_cost_sec": round(per_hour_audio_cost_sec, 6),
        "external_model_dependencies": "|".join(external_model_dependencies),
        "notes": notes,
    }


def _load_speechcraft_worker_functions() -> dict[str, Any]:
    worker_root = Path("/home/aaravthegreat/Projects/speechcraft/workers/dataset")
    if str(worker_root) not in sys.path:
        sys.path.insert(0, str(worker_root))
    from speechcraft_dataset.alignment_qc import run_alignment_qc
    from speechcraft_dataset.asr import build_asr_queue, run_asr
    from speechcraft_dataset.io import sha256_file as worker_sha256_file
    from speechcraft_dataset.mfa import run_mfa_alignment
    from speechcraft_dataset.normalization import normalize_transcripts
    from speechcraft_dataset.safecut import generate_safe_cutpoint_diagnostics

    return {
        "build_asr_queue": build_asr_queue,
        "run_asr": run_asr,
        "normalize_transcripts": normalize_transcripts,
        "run_mfa_alignment": run_mfa_alignment,
        "run_alignment_qc": run_alignment_qc,
        "generate_safe_cutpoint_diagnostics": generate_safe_cutpoint_diagnostics,
        "worker_sha256_file": worker_sha256_file,
    }


def _write_pcm16_wav_slice(
    *,
    source_wav_path: Path,
    start_sample: int,
    end_sample: int,
    out_path: Path,
) -> None:
    if end_sample <= start_sample:
        raise ValueError(f"invalid buffer slice: {source_wav_path} {start_sample}:{end_sample}")
    with wave.open(str(source_wav_path), "rb") as src:
        sample_rate = int(src.getframerate())
        channels = int(src.getnchannels())
        sample_width = int(src.getsampwidth())
        if channels != 1:
            raise ValueError(f"expected mono source WAV for production dry run: {source_wav_path}")
        if sample_width != 2:
            raise ValueError(f"expected 16-bit PCM source WAV for production dry run: {source_wav_path}")
        src.setpos(start_sample)
        frames = src.readframes(end_sample - start_sample)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(out_path), "wb") as dst:
        dst.setnchannels(1)
        dst.setsampwidth(2)
        dst.setframerate(sample_rate)
        dst.writeframes(frames)


def _build_processing_buffers_for_raw_nemo_scope(
    *,
    run_root: Path,
    buffers: list[NemoScopeBuffer],
    sources: dict[str, SourceInfo],
    worker_sha256_file: Any,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for index, buffer in enumerate(buffers):
        source = sources[buffer.source_audio_id]
        source_start_sample = int(round(buffer.buffer_start_sec * source.sample_rate))
        source_end_sample = int(round(buffer.buffer_end_sec * source.sample_rate))
        duration_samples = source_end_sample - source_start_sample
        if duration_samples <= 0:
            raise ValueError(f"non-positive raw NeMo buffer duration for {buffer.buffer_id}")
        audio_rel_path = f"artifacts/buffers/{buffer.buffer_id}.wav"
        audio_path = run_root / audio_rel_path
        _write_pcm16_wav_slice(
            source_wav_path=Path(source.path),
            start_sample=source_start_sample,
            end_sample=source_end_sample,
            out_path=audio_path,
        )
        content_hash = worker_sha256_file(audio_path)
        duration_sec = duration_samples / source.sample_rate
        rows.append(
            {
                "analysis_audio_path": audio_rel_path,
                "audio_path": audio_rel_path,
                "buffer_id": buffer.buffer_id,
                "content_hash": content_hash,
                "duration_samples": duration_samples,
                "duration_sec": round(duration_sec, 6),
                "left_provisional_boundary": False,
                "reason_codes": [],
                "right_provisional_boundary": False,
                "sample_rate": source.sample_rate,
                "source_audio_id": source.source_audio_id,
                "source_end_sample": source_end_sample,
                "source_end_sec": round(source_end_sample / source.sample_rate, 6),
                "source_start_sample": source_start_sample,
                "source_start_sec": round(source_start_sample / source.sample_rate, 6),
                "split_strategy": "raw_nemo_target_segment",
                "target_speaker_id": "oracle_nemo_target",
                "trusted_end_sample": source_end_sample,
                "trusted_end_sec": round(source_end_sample / source.sample_rate, 6),
                "trusted_local_end_sample": duration_samples,
                "trusted_local_start_sample": 0,
                "trusted_start_sample": source_start_sample,
                "trusted_start_sec": round(source_start_sample / source.sample_rate, 6),
            }
        )
    rows.sort(key=lambda row: (str(row["source_audio_id"]), int(row["source_start_sample"]), str(row["buffer_id"])))
    return rows


def _run_speechcraft_stage(stage_fn: Any, *, run_root: Path, config: dict[str, Any]) -> tuple[dict[str, Any], float]:
    started = time.monotonic()
    result = stage_fn(run_root, config)
    return result, round(time.monotonic() - started, 6)


def _load_production_cutpoints_from_run(
    *,
    run_root: Path,
    detector_name: str,
    sources: dict[str, SourceInfo],
    buffer_by_id: dict[str, dict[str, Any]],
    audio_feature_cache: dict[str, dict[str, Any]],
) -> tuple[list[Cutpoint], dict[str, Any]]:
    queue_rows = json.loads((run_root / "artifacts" / "asr_mfa_queue.json").read_text(encoding="utf-8"))
    qc_rows = json.loads((run_root / "artifacts" / "alignment_qc_by_buffer.json").read_text(encoding="utf-8"))
    cut_rows = read_jsonl(run_root / "artifacts" / "safe_cutpoints.jsonl")
    queue_by_id = {str(row["buffer_id"]): row for row in queue_rows}
    qc_by_id = {str(row["buffer_id"]): row for row in qc_rows}
    cuts: list[Cutpoint] = []
    for row in cut_rows:
        buffer_id = str(row["buffer_id"])
        buffer = buffer_by_id[buffer_id]
        queue_row = queue_by_id.get(buffer_id)
        if queue_row is None:
            continue
        source = sources[str(queue_row["source_audio_id"])]
        cut_time = int(row["source_sample"]) / source.sample_rate
        stats = _window_feature_stats(audio_feature_cache[source.recording_id], cut_time - 0.05, cut_time + 0.05)
        interval_start = float(queue_row["source_start_sec"]) + (int(row["candidate_start_local_sample"]) / source.sample_rate)
        interval_end = float(queue_row["source_start_sec"]) + (int(row["candidate_end_local_sample"]) / source.sample_rate)
        cuts.append(
            Cutpoint(
                detector_name=detector_name,
                source_id=source.source_audio_id,
                recording_id=source.recording_id,
                buffer_id=buffer_id,
                cutpoint_id=str(row["id"]),
                time_sec=round(cut_time, 6),
                interval_start_sec=round(interval_start, 6),
                interval_end_sec=round(interval_end, 6),
                score=-float(row.get("valley_dbfs") or 0.0),
                vad_min=stats["vad_min"],
                vad_mean=stats["vad_mean"],
                vad_longest_below_0_1_ms=stats["vad_longest_below_0_1_ms"],
                vad_longest_below_0_2_ms=stats["vad_longest_below_0_2_ms"],
                rms_min_dbfs=stats["rms_min_dbfs"],
                rms_mean_dbfs=stats["rms_mean_dbfs"],
                voicing_min=stats["voicing_min"],
                voicing_mean=stats["voicing_mean"],
                compute_time_sec=0.0,
                is_buffer_edge_candidate=False,
                metadata={
                    "left_word": row.get("left_word", ""),
                    "right_word": row.get("right_word", ""),
                    "gap_duration_ms": round(float(row.get("gap_duration_sec", 0.0)) * 1000.0, 3),
                    "usable_gap_ms": round(float(row.get("usable_gap_sec", 0.0)) * 1000.0, 3),
                    "valley_dbfs": row.get("valley_dbfs"),
                    "noise_floor_dbfs": row.get("noise_floor_dbfs"),
                    "left_word_id": row.get("left_word_id", ""),
                    "right_word_id": row.get("right_word_id", ""),
                    "buffer_warning_reason_codes": row.get("buffer_warning_reason_codes", []),
                },
            )
        )
    summary = {
        "queue_buffer_count": len(queue_rows),
        "qc_buffer_count": len(qc_rows),
        "accepted_cutpoint_count": len(cut_rows),
        "buffers_with_automatic_cutpoints_disabled": sum(
            bool(row.get("automatic_cutpoints_disabled")) or bool(row.get("fatal_reason_codes"))
            for row in qc_rows
        ),
    }
    return cuts, summary


def write_repaired_scope_validation(
    *,
    speaker_id: str,
    eval_run: Path,
    normalized_speaker_dir: Path,
    cluster_mapping_csv: Path,
    out_dir: Path,
) -> Path:
    artifacts = require_parser_artifacts(normalized_speaker_dir)
    reference_words = _read_csv(normalized_speaker_dir / "reference_words.csv")
    reference_phones = _read_csv(normalized_speaker_dir / "reference_phones.csv")
    included_recording_ids, excluded_recording_ids = load_recording_eligibility(
        reference_reconciliation_csv=artifacts["reference_reconciliation"],
        excluded_recordings_csv=artifacts["excluded_recordings"],
    )
    uncertainty_masks = load_uncertainty_masks_by_recording(artifacts["uncertainty_masks"])
    interviewer_mask = build_interviewer_mask(reference_words=reference_words, reference_phones=reference_phones)
    target_reference = build_target_speech_reference(
        reference_phones=reference_phones,
        interviewer_mask_by_recording=interviewer_mask,
        uncertainty_mask_by_recording=uncertainty_masks,
    )
    cluster_mapping = load_nemo_cluster_mapping(cluster_mapping_csv, speaker_id=speaker_id)
    all_buffers = build_raw_nemo_target_buffers(
        speaker_id=speaker_id,
        eval_run=eval_run,
        cluster_mapping=cluster_mapping,
    )
    buffers = build_raw_nemo_target_buffers(
        speaker_id=speaker_id,
        eval_run=eval_run,
        cluster_mapping=cluster_mapping,
        included_recording_ids=included_recording_ids,
        excluded_recording_ids=excluded_recording_ids,
    )
    if any(buffer.recording_id in excluded_recording_ids for buffer in buffers):
        raise ValueError("excluded recordings survived raw NeMo scope construction")
    if any(buffer.recording_id not in included_recording_ids for buffer in buffers):
        raise ValueError("non-included recordings survived raw NeMo scope construction")
    recording_rows, speaker_rows = build_nemo_scope_rows(
        buffers=buffers,
        target_reference_by_recording=target_reference,
        interviewer_mask_by_recording=interviewer_mask,
    )
    out_dir.mkdir(parents=True, exist_ok=False)
    write_csv(
        out_dir / "nemo_target_buffers.csv",
        [
            {
                "speaker_id": row.speaker_id,
                "recording_id": row.recording_id,
                "source_audio_id": row.source_audio_id,
                "wav_path": row.wav_path,
                "buffer_id": row.buffer_id,
                "buffer_start_sec": row.buffer_start_sec,
                "buffer_end_sec": row.buffer_end_sec,
                "duration_sec": row.duration_sec,
                "source_cluster_ids": "|".join(row.source_cluster_ids),
                "mapping_confidence": row.mapping_confidence,
            }
            for row in buffers
        ],
        fieldnames=[
            "speaker_id", "recording_id", "source_audio_id", "wav_path", "buffer_id",
            "buffer_start_sec", "buffer_end_sec", "duration_sec", "source_cluster_ids", "mapping_confidence",
        ],
    )
    write_csv(out_dir / "nemo_scope_by_recording.csv", recording_rows, fieldnames=list(recording_rows[0].keys()) if recording_rows else ["speaker_id"])
    write_csv(out_dir / "nemo_scope_by_speaker.csv", speaker_rows, fieldnames=list(speaker_rows[0].keys()) if speaker_rows else ["speaker_id"])
    write_parser_artifact_manifest(normalized_speaker_dir=normalized_speaker_dir, out_dir=out_dir)
    write_json(
        out_dir / "provenance.json",
        {
            "speaker_id": speaker_id,
            "eval_run": str(eval_run),
            "normalized_speaker_dir": str(normalized_speaker_dir),
            "cluster_mapping_csv": str(cluster_mapping_csv),
            "included_recording_count": len(included_recording_ids),
            "excluded_recording_count": len(excluded_recording_ids),
            "raw_nemo_recording_count": len({buffer.recording_id for buffer in all_buffers}),
            "eligible_nemo_recording_count": len({buffer.recording_id for buffer in buffers}),
            "dropped_excluded_nemo_buffer_count": len(all_buffers) - len(buffers),
        },
    )
    report_lines = [
        "# Repaired Buckeye / NeMo Scope Validation",
        "",
        f"- speaker: `{speaker_id}`",
        f"- eval run: `{eval_run}`",
        f"- cluster mapping: `{cluster_mapping_csv}`",
        "",
        "## Speaker Summary",
        "",
    ]
    for row in speaker_rows:
        report_lines.append(
            f"- `{row['speaker_id']}`: raw buffers `{row['raw_nemo_buffer_count']}`, "
            f"target recall `{row['target_phone_recall']}`, target density `{row['target_phone_density']}`, "
            f"interviewer overlap `{row['interviewer_mask_overlap_rate']}`"
        )
    report_lines.extend(["", "## Recording Summary", ""])
    for row in recording_rows:
        report_lines.append(
            f"- `{row['recording_id']}`: buffers `{row['raw_nemo_buffer_count']}`, recall `{row['target_phone_recall']}`, "
            f"density `{row['target_phone_density']}`, interviewer overlap `{row['interviewer_mask_overlap_rate']}`, "
            f"too short `{row['too_short_for_legal_clip_count']}`"
        )
    (out_dir / "REPAIRED_SCOPE_VALIDATION.md").write_text("\n".join(report_lines) + "\n", encoding="utf-8")
    return out_dir


def run_repaired_slicer_dry_run(
    *,
    eval_run: Path,
    normalized_speaker_dir: Path,
    cluster_mapping_csv: Path,
    out_root: Path,
    detector_name: str = "legacy_vad_rms",
    shared_cache_root: Path | None = None,
    write_heavy_tables: bool = True,
) -> Path:
    artifacts = require_parser_artifacts(normalized_speaker_dir)
    detectors = supported_repaired_detectors()
    if detector_name not in detectors:
        raise ValueError(f"unsupported repaired detector {detector_name}; choose from {sorted(detectors)}")
    speaker_id = normalized_speaker_dir.name
    timestamp = "2026-07-17_000000"
    output_root = out_root / f"{timestamp}_buckeye_{speaker_id}_repaired_slicer_dry_run_{detector_name}"
    if output_root.exists():
        raise FileExistsError(f"repaired dry-run output already exists: {output_root}")
    output_root.mkdir(parents=True, exist_ok=False)

    reference_words = _read_csv(normalized_speaker_dir / "reference_words.csv")
    reference_phones = _read_csv(normalized_speaker_dir / "reference_phones.csv")
    included_recording_ids, excluded_recording_ids = load_recording_eligibility(
        reference_reconciliation_csv=artifacts["reference_reconciliation"],
        excluded_recordings_csv=artifacts["excluded_recordings"],
    )
    uncertainty_masks = load_uncertainty_masks_by_recording(artifacts["uncertainty_masks"])
    interviewer_mask = build_interviewer_mask(reference_words=reference_words, reference_phones=reference_phones)
    target_reference = build_target_speech_reference(
        reference_phones=reference_phones,
        interviewer_mask_by_recording=interviewer_mask,
        uncertainty_mask_by_recording=uncertainty_masks,
    )
    annotation_rows = build_annotation_rows(
        reference_words=reference_words,
        reference_phones=reference_phones,
        interviewer_mask_by_recording=interviewer_mask,
        uncertainty_mask_by_recording=uncertainty_masks,
    )
    cluster_mapping = load_nemo_cluster_mapping(cluster_mapping_csv, speaker_id=speaker_id)
    all_buffers = build_raw_nemo_target_buffers(
        speaker_id=speaker_id,
        eval_run=eval_run,
        cluster_mapping=cluster_mapping,
    )
    buffers = build_raw_nemo_target_buffers(
        speaker_id=speaker_id,
        eval_run=eval_run,
        cluster_mapping=cluster_mapping,
        included_recording_ids=included_recording_ids,
        excluded_recording_ids=excluded_recording_ids,
    )
    if not buffers:
        raise ValueError(f"no raw NeMo target buffers built for {speaker_id}")
    if any(buffer.recording_id in excluded_recording_ids for buffer in buffers):
        raise ValueError("excluded recordings survived raw NeMo scope construction")
    if any(buffer.recording_id not in included_recording_ids for buffer in buffers):
        raise ValueError("non-included recordings survived raw NeMo scope construction")
    buffer_by_id = build_buffer_rows_from_nemo_buffers(buffers)
    sources = _filter_sources_to_included_recordings(
        _load_sources(_resolve_artifacts_root(eval_run) / "source_audio_manifest.json"),
        included_recording_ids,
    )

    metrics_dir = output_root / "metrics"
    tables_dir = output_root / "tables"
    for path in (metrics_dir, tables_dir):
        path.mkdir(parents=True, exist_ok=True)
    cache_root = (shared_cache_root / speaker_id) if shared_cache_root is not None else metrics_dir
    frame_index_by_recording = _load_or_reuse_vad_frame_indices(
        sources=sources,
        eval_run=eval_run,
        cache_dir=cache_root / "vad_frame_cache",
    )
    vad_backend, vad_window_samples, vad_hop_samples, vad_offsets = _vad_frame_geometry_from_env()
    audio_feature_cache = _build_audio_feature_cache_stdlib(
        sources=sources,
        frame_index_by_recording=frame_index_by_recording,
        cache_dir=cache_root / "audio_feature_cache",
    )
    config = BenchmarkConfig()
    contexts = BenchmarkContexts(
        shared=DetectorContext(
            eval_run=eval_run,
            normalized_speaker_dir=normalized_speaker_dir,
            benchmark_root=output_root,
            config=config,
            sources=sources,
            buffer_by_id=buffer_by_id,
            lexical_words_by_recording={},
            speech_phones_by_recording={},
            corrected_safe_regions=[],
            reference_words=reference_words,
            reference_phones=reference_phones,
        ),
        acoustic=AcousticDetectorContext(
            benchmark_root=output_root,
            config=config,
            sources=sources,
            buffer_by_id=buffer_by_id,
            audio_feature_cache=audio_feature_cache,
            profiler={},
        ),
        linguistic=None,  # type: ignore[arg-type]
    )
    detector = detectors[detector_name]
    result = detector.find_cutpoints(contexts)
    legal_cutpoints = cutpoints_strictly_inside_buffers(result.cutpoints, buffers)
    constraints = PackingConstraints(
        min_clip_sec=config.min_clip_sec,
        preferred_min_sec=config.preferred_min_sec,
        preferred_max_sec=config.preferred_max_sec,
        target_clip_sec=config.target_clip_sec,
        max_clip_sec=config.max_clip_sec,
        allow_overlap=False,
        max_overlap_sec=0.0,
        max_duplication_ratio=1.0,
        eligible_regions_by_recording={recording_id: tuple((buf.buffer_start_sec, buf.buffer_end_sec) for buf in rows)
                                       for recording_id, rows in _group_buffers_by_recording(buffers).items()},
    )
    all_candidates = generate_legal_candidate_clips_in_buffers(
        cutpoints=legal_cutpoints,
        constraints=constraints,
    )
    _assert_rows_in_included_recordings(rows=legal_cutpoints, included_recording_ids=included_recording_ids, row_label="legal cutpoints")
    _assert_rows_in_included_recordings(rows=all_candidates, included_recording_ids=included_recording_ids, row_label="candidate clips")
    selected_candidates = schedule_candidates_by_buffer(all_candidates, max_overlap_sec=0.0)
    _assert_rows_in_included_recordings(rows=selected_candidates, included_recording_ids=included_recording_ids, row_label="selected candidate clips")
    clips = _clips_from_candidates(selected_candidates, packer_name="optimal_weighted_interval")
    _assert_rows_in_included_recordings(rows=clips, included_recording_ids=included_recording_ids, row_label="emitted clips")
    assert_clips_within_single_buffer(clips, buffers)
    _assert_final_clip_boundaries_match_cutpoints(clips=clips, cutpoints=legal_cutpoints)
    selected_cutpoint_ids = {candidate.start_cutpoint_id for candidate in selected_candidates} | {
        candidate.end_cutpoint_id for candidate in selected_candidates
    }
    selected_cutpoints = [
        cut for cut in legal_cutpoints
        if cut.cutpoint_id in selected_cutpoint_ids
    ]
    selected_boundary_rows = build_boundary_classification_rows(
        detector_name=detector_name,
        boundary_source="detector_selected_cutpoint",
        selected_cutpoints=selected_cutpoints,
        buffers=buffers,
        annotation_rows_by_recording=annotation_rows,
        interviewer_mask_by_recording=interviewer_mask,
        uncertainty_mask_by_recording=uncertainty_masks,
    )
    emitted_boundary_rows = _final_boundary_classification_rows(
        detector_name=detector_name,
        clips=clips,
        cutpoints=legal_cutpoints,
        buffers=buffers,
        annotation_rows_by_recording=annotation_rows,
        interviewer_mask_by_recording=interviewer_mask,
        uncertainty_mask_by_recording=uncertainty_masks,
    )
    _assert_boundary_rows_in_included_recordings(selected_boundary_rows, included_recording_ids)
    _assert_boundary_rows_in_included_recordings(emitted_boundary_rows, included_recording_ids)
    _assert_boundary_population_reconciliation(
        selected_cutpoints=selected_cutpoints,
        clips=clips,
        emitted_boundary_rows=emitted_boundary_rows,
    )
    coverage = compute_clip_coverage_metrics(
        clips=clips,
        buffers=buffers,
        target_reference_by_recording={
            rid: _intersect_with_buffer_scope(rows, _group_buffers_by_recording(buffers).get(rid, []))
            for rid, rows in target_reference.items()
        },
        all_target_reference_by_recording=target_reference,
    )
    candidate_support_rows = _candidate_support_by_recording(
        buffers=buffers,
        target_reference_by_recording=target_reference,
        selected_cutpoints=selected_cutpoints,
        all_candidates=all_candidates,
    )
    invariant_rows = _invariant_rows(
        detector_name=detector_name,
        legal_cutpoints=legal_cutpoints,
        all_candidates=all_candidates,
        selected_candidates=selected_candidates,
        buffers=buffers,
        clips=clips,
        reference_phones=reference_phones,
    )
    if write_heavy_tables:
        write_csv(tables_dir / "all_cutpoints.csv", [_cutpoint_csv_row(row) for row in legal_cutpoints], fieldnames=list(_cutpoint_csv_row(legal_cutpoints[0]).keys()) if legal_cutpoints else ["detector_name"])
        write_csv(tables_dir / "all_candidates.csv", [_candidate_csv_row(row) for row in all_candidates], fieldnames=list(_candidate_csv_row(all_candidates[0]).keys()) if all_candidates else ["detector_name"])
        write_csv(tables_dir / "selected_boundaries.csv", [_cutpoint_csv_row(row) for row in selected_cutpoints], fieldnames=list(_cutpoint_csv_row(selected_cutpoints[0]).keys()) if selected_cutpoints else ["detector_name"])
    boundary_rows = selected_boundary_rows + emitted_boundary_rows
    if write_heavy_tables:
        write_csv(tables_dir / "boundary_classification.csv", boundary_rows, fieldnames=list(boundary_rows[0].keys()) if boundary_rows else ["detector_name"])
    error_details = build_in_phone_error_details(boundary_rows)
    write_csv(
        tables_dir / "in_phone_error_details.csv",
        error_details,
        fieldnames=list(error_details[0].keys()) if error_details else ["speaker_id"],
    )
    deep_error_manifest = build_deep_error_review_manifest(boundary_rows)
    write_csv(
        tables_dir / "deep_error_review_manifest.csv",
        deep_error_manifest,
        fieldnames=list(deep_error_manifest[0].keys()) if deep_error_manifest else ["speaker_id"],
    )
    severity_rows = summarize_boundary_severity_by_speaker_and_source(boundary_rows)
    write_csv(
        tables_dir / "boundary_severity_unique_cutpoints.csv",
        severity_rows["unique_selected_cutpoints"],
        fieldnames=list(severity_rows["unique_selected_cutpoints"][0].keys()) if severity_rows["unique_selected_cutpoints"] else ["speaker_id"],
    )
    write_csv(
        tables_dir / "boundary_severity_final_edge_occurrences.csv",
        severity_rows["final_edge_occurrences"],
        fieldnames=list(severity_rows["final_edge_occurrences"][0].keys()) if severity_rows["final_edge_occurrences"] else ["speaker_id"],
    )
    severity_summary_rows = [
        {**row, "population": "unique_selected_cutpoints"}
        for row in severity_rows["unique_selected_cutpoints"]
    ] + [
        {**row, "population": "final_edge_occurrences"}
        for row in severity_rows["final_edge_occurrences"]
    ]
    write_csv(
        tables_dir / "in_phone_error_severity_summary.csv",
        severity_summary_rows,
        fieldnames=list(severity_summary_rows[0].keys()) if severity_summary_rows else ["speaker_id"],
    )
    write_csv(tables_dir / "emitted_clips.csv", [_clip_csv_row(row) for row in clips], fieldnames=list(_clip_csv_row(clips[0]).keys()) if clips else ["detector_name"])
    coverage_by_recording = _coverage_by_recording(clips=clips, target_reference_by_recording=target_reference, buffers=buffers)
    write_csv(tables_dir / "coverage_by_recording.csv", coverage_by_recording, fieldnames=list(coverage_by_recording[0].keys()) if coverage_by_recording else ["speaker_id"])
    write_csv(tables_dir / "candidate_support_by_recording.csv", candidate_support_rows, fieldnames=list(candidate_support_rows[0].keys()) if candidate_support_rows else ["speaker_id"])
    write_csv(tables_dir / "coverage_by_speaker.csv", [dict({"speaker_id": speaker_id, "detector_name": detector_name}, **coverage)], fieldnames=list({"speaker_id": speaker_id, "detector_name": detector_name, **coverage}.keys()))
    write_csv(
        tables_dir / "compute_metrics.csv",
        [_compute_metric_row(speaker_id=speaker_id, detector_name=detector_name, compute_metric=result.compute_metric)],
        fieldnames=list(_compute_metric_row(speaker_id=speaker_id, detector_name=detector_name, compute_metric=result.compute_metric).keys()),
    )
    write_csv(tables_dir / "invariant_report.csv", invariant_rows, fieldnames=list(invariant_rows[0].keys()))
    _plot_boundary_error_figures(rows=boundary_rows, figures_dir=output_root / "figures")
    write_json(
        output_root / "provenance.json",
        {
            "speaker_id": speaker_id,
            "detector_name": detector_name,
            "eval_run": str(eval_run),
            "normalized_speaker_dir": str(normalized_speaker_dir),
            "cluster_mapping_csv": str(cluster_mapping_csv),
            "raw_nemo_buffer_count": len(buffers),
            "included_recording_count": len(included_recording_ids),
            "excluded_recording_count": len(excluded_recording_ids),
            "raw_nemo_recording_count": len({buffer.recording_id for buffer in all_buffers}),
            "eligible_nemo_recording_count": len({buffer.recording_id for buffer in buffers}),
            "dropped_excluded_nemo_buffer_count": len(all_buffers) - len(buffers),
            "vad_backend": vad_backend,
            "vad_window_samples": vad_window_samples,
            "vad_hop_samples": vad_hop_samples,
            "vad_offsets": list(vad_offsets),
            "legal_cutpoint_count": len(legal_cutpoints),
            "selected_cutpoint_count": len(selected_cutpoints),
            "candidate_clip_count": len(all_candidates),
            "selected_clip_count": len(clips),
            "vad_frame_cache_mode": _vad_cache_mode(frame_index_by_recording),
            "compute_metric": _compute_metric_row(
                speaker_id=speaker_id,
                detector_name=detector_name,
                compute_metric=result.compute_metric,
            ),
        },
    )
    return output_root


def run_repaired_production_dry_run(
    *,
    eval_run: Path,
    normalized_speaker_dir: Path,
    cluster_mapping_csv: Path,
    out_root: Path,
    shared_cache_root: Path | None = None,
    write_heavy_tables: bool = True,
) -> Path:
    artifacts = require_parser_artifacts(normalized_speaker_dir)
    speaker_id = normalized_speaker_dir.name
    timestamp = "2026-07-17_000000"
    detector_name = "production_safecut_optimal"
    output_root = out_root / f"{timestamp}_buckeye_{speaker_id}_repaired_slicer_dry_run_{detector_name}"
    production_run_root = output_root / "speechcraft_run"
    reuse_completed_speechcraft_run = (
        output_root.exists()
        and (production_run_root / "artifacts" / "safe_cutpoints.jsonl").exists()
    )
    if output_root.exists() and not reuse_completed_speechcraft_run:
        raise FileExistsError(f"repaired production dry-run output already exists: {output_root}")
    output_root.mkdir(parents=True, exist_ok=True)

    reference_words = _read_csv(normalized_speaker_dir / "reference_words.csv")
    reference_phones = _read_csv(normalized_speaker_dir / "reference_phones.csv")
    included_recording_ids, excluded_recording_ids = load_recording_eligibility(
        reference_reconciliation_csv=artifacts["reference_reconciliation"],
        excluded_recordings_csv=artifacts["excluded_recordings"],
    )
    uncertainty_masks = load_uncertainty_masks_by_recording(artifacts["uncertainty_masks"])
    interviewer_mask = build_interviewer_mask(reference_words=reference_words, reference_phones=reference_phones)
    target_reference = build_target_speech_reference(
        reference_phones=reference_phones,
        interviewer_mask_by_recording=interviewer_mask,
        uncertainty_mask_by_recording=uncertainty_masks,
    )
    annotation_rows = build_annotation_rows(
        reference_words=reference_words,
        reference_phones=reference_phones,
        interviewer_mask_by_recording=interviewer_mask,
        uncertainty_mask_by_recording=uncertainty_masks,
    )
    cluster_mapping = load_nemo_cluster_mapping(cluster_mapping_csv, speaker_id=speaker_id)
    all_buffers = build_raw_nemo_target_buffers(
        speaker_id=speaker_id,
        eval_run=eval_run,
        cluster_mapping=cluster_mapping,
    )
    buffers = build_raw_nemo_target_buffers(
        speaker_id=speaker_id,
        eval_run=eval_run,
        cluster_mapping=cluster_mapping,
        included_recording_ids=included_recording_ids,
        excluded_recording_ids=excluded_recording_ids,
    )
    if not buffers:
        raise ValueError(f"no raw NeMo target buffers built for {speaker_id}")
    if any(buffer.recording_id in excluded_recording_ids for buffer in buffers):
        raise ValueError("excluded recordings survived raw NeMo scope construction")
    if any(buffer.recording_id not in included_recording_ids for buffer in buffers):
        raise ValueError("non-included recordings survived raw NeMo scope construction")
    buffer_by_id = build_buffer_rows_from_nemo_buffers(buffers)
    artifacts_root = _resolve_artifacts_root(eval_run)
    sources = _filter_sources_to_included_recordings(
        _load_sources(artifacts_root / "source_audio_manifest.json"),
        included_recording_ids,
    )

    metrics_dir = output_root / "metrics"
    tables_dir = output_root / "tables"
    for path in (metrics_dir, tables_dir, production_run_root / "artifacts"):
        path.mkdir(parents=True, exist_ok=True)

    cache_root = (shared_cache_root / speaker_id) if shared_cache_root is not None else metrics_dir
    frame_index_by_recording = _load_or_reuse_vad_frame_indices(
        sources=sources,
        eval_run=eval_run,
        cache_dir=cache_root / "vad_frame_cache",
    )
    audio_feature_cache = _build_audio_feature_cache_stdlib(
        sources=sources,
        frame_index_by_recording=frame_index_by_recording,
        cache_dir=cache_root / "audio_feature_cache",
    )
    production_config = json.loads((eval_run / "config.json").read_text(encoding="utf-8"))
    production_config["candidate_min_clip_sec"] = DEFAULT_SCOPE_MIN_CLIP_SEC
    production_config["min_asr_mfa_buffer_sec"] = DEFAULT_SCOPE_MIN_CLIP_SEC
    stage_summaries: dict[str, Any] = {}
    stage_durations_sec: dict[str, float] = {}
    if not reuse_completed_speechcraft_run:
        worker = _load_speechcraft_worker_functions()
        processing_buffers = _build_processing_buffers_for_raw_nemo_scope(
            run_root=production_run_root,
            buffers=buffers,
            sources=sources,
            worker_sha256_file=worker["worker_sha256_file"],
        )
        write_json(production_run_root / "config.json", production_config)
        write_json(production_run_root / "artifacts" / "source_audio_manifest.json", json.loads((artifacts_root / "source_audio_manifest.json").read_text(encoding="utf-8")))
        write_json(production_run_root / "artifacts" / "processing_buffers.json", processing_buffers)

        for stage_name, fn_key in (
            ("asr_queue", "build_asr_queue"),
            ("asr", "run_asr"),
            ("normalization", "normalize_transcripts"),
            ("mfa", "run_mfa_alignment"),
            ("alignment_qc", "run_alignment_qc"),
            ("safe_cutpoints", "generate_safe_cutpoint_diagnostics"),
        ):
            summary, duration_sec = _run_speechcraft_stage(
                worker[fn_key],
                run_root=production_run_root,
                config=production_config,
            )
            stage_summaries[stage_name] = summary
            stage_durations_sec[stage_name] = duration_sec
    else:
        for stage_name, artifact_name in (
            ("asr_queue", "asr_mfa_queue_summary.json"),
            ("asr", "transcripts_summary.json"),
            ("normalization", "normalization_summary.json"),
            ("mfa", "aligned_words_summary.json"),
            ("alignment_qc", "alignment_qc_summary.json"),
            ("safe_cutpoints", "safe_cutpoint_summary.json"),
        ):
            path = production_run_root / "artifacts" / artifact_name
            if path.exists():
                stage_summaries[stage_name] = json.loads(path.read_text(encoding="utf-8"))

    production_cutpoints, production_artifact_summary = _load_production_cutpoints_from_run(
        run_root=production_run_root,
        detector_name=detector_name,
        sources=sources,
        buffer_by_id=buffer_by_id,
        audio_feature_cache=audio_feature_cache,
    )
    legal_cutpoints = cutpoints_strictly_inside_buffers(production_cutpoints, buffers)
    config = BenchmarkConfig()
    constraints = PackingConstraints(
        min_clip_sec=config.min_clip_sec,
        preferred_min_sec=config.preferred_min_sec,
        preferred_max_sec=config.preferred_max_sec,
        target_clip_sec=config.target_clip_sec,
        max_clip_sec=config.max_clip_sec,
        allow_overlap=False,
        max_overlap_sec=0.0,
        max_duplication_ratio=1.0,
        eligible_regions_by_recording={
            recording_id: tuple((buf.buffer_start_sec, buf.buffer_end_sec) for buf in rows)
            for recording_id, rows in _group_buffers_by_recording(buffers).items()
        },
    )
    all_candidates = generate_legal_candidate_clips_in_buffers(
        cutpoints=legal_cutpoints,
        constraints=constraints,
    )
    _assert_rows_in_included_recordings(rows=legal_cutpoints, included_recording_ids=included_recording_ids, row_label="legal cutpoints")
    _assert_rows_in_included_recordings(rows=all_candidates, included_recording_ids=included_recording_ids, row_label="candidate clips")
    selected_candidates = schedule_candidates_by_buffer(all_candidates, max_overlap_sec=0.0)
    _assert_rows_in_included_recordings(rows=selected_candidates, included_recording_ids=included_recording_ids, row_label="selected candidate clips")
    clips = _clips_from_candidates(selected_candidates, packer_name="optimal_weighted_interval")
    _assert_rows_in_included_recordings(rows=clips, included_recording_ids=included_recording_ids, row_label="emitted clips")
    assert_clips_within_single_buffer(clips, buffers)
    _assert_final_clip_boundaries_match_cutpoints(clips=clips, cutpoints=legal_cutpoints)
    selected_cutpoint_ids = {candidate.start_cutpoint_id for candidate in selected_candidates} | {
        candidate.end_cutpoint_id for candidate in selected_candidates
    }
    selected_cutpoints = [cut for cut in legal_cutpoints if cut.cutpoint_id in selected_cutpoint_ids]
    selected_boundary_rows = build_boundary_classification_rows(
        detector_name=detector_name,
        boundary_source="detector_selected_cutpoint",
        selected_cutpoints=selected_cutpoints,
        buffers=buffers,
        annotation_rows_by_recording=annotation_rows,
        interviewer_mask_by_recording=interviewer_mask,
        uncertainty_mask_by_recording=uncertainty_masks,
    )
    emitted_boundary_rows = _final_boundary_classification_rows(
        detector_name=detector_name,
        clips=clips,
        cutpoints=legal_cutpoints,
        buffers=buffers,
        annotation_rows_by_recording=annotation_rows,
        interviewer_mask_by_recording=interviewer_mask,
        uncertainty_mask_by_recording=uncertainty_masks,
    )
    _assert_boundary_rows_in_included_recordings(selected_boundary_rows, included_recording_ids)
    _assert_boundary_rows_in_included_recordings(emitted_boundary_rows, included_recording_ids)
    _assert_boundary_population_reconciliation(
        selected_cutpoints=selected_cutpoints,
        clips=clips,
        emitted_boundary_rows=emitted_boundary_rows,
    )
    coverage = compute_clip_coverage_metrics(
        clips=clips,
        buffers=buffers,
        target_reference_by_recording={
            rid: _intersect_with_buffer_scope(rows, _group_buffers_by_recording(buffers).get(rid, []))
            for rid, rows in target_reference.items()
        },
        all_target_reference_by_recording=target_reference,
    )
    candidate_support_rows = _candidate_support_by_recording(
        buffers=buffers,
        target_reference_by_recording=target_reference,
        selected_cutpoints=selected_cutpoints,
        all_candidates=all_candidates,
    )
    invariant_rows = _invariant_rows(
        detector_name=detector_name,
        legal_cutpoints=legal_cutpoints,
        all_candidates=all_candidates,
        selected_candidates=selected_candidates,
        buffers=buffers,
        clips=clips,
        reference_phones=reference_phones,
    )
    if write_heavy_tables:
        write_csv(tables_dir / "all_cutpoints.csv", [_cutpoint_csv_row(row) for row in legal_cutpoints], fieldnames=list(_cutpoint_csv_row(legal_cutpoints[0]).keys()) if legal_cutpoints else ["detector_name"])
        write_csv(tables_dir / "all_candidates.csv", [_candidate_csv_row(row) for row in all_candidates], fieldnames=list(_candidate_csv_row(all_candidates[0]).keys()) if all_candidates else ["detector_name"])
        write_csv(tables_dir / "selected_boundaries.csv", [_cutpoint_csv_row(row) for row in selected_cutpoints], fieldnames=list(_cutpoint_csv_row(selected_cutpoints[0]).keys()) if selected_cutpoints else ["detector_name"])
    boundary_rows = selected_boundary_rows + emitted_boundary_rows
    if write_heavy_tables:
        write_csv(tables_dir / "boundary_classification.csv", boundary_rows, fieldnames=list(boundary_rows[0].keys()) if boundary_rows else ["detector_name"])
    error_details = build_in_phone_error_details(boundary_rows)
    write_csv(
        tables_dir / "in_phone_error_details.csv",
        error_details,
        fieldnames=list(error_details[0].keys()) if error_details else ["speaker_id"],
    )
    deep_error_manifest = build_deep_error_review_manifest(boundary_rows)
    write_csv(
        tables_dir / "deep_error_review_manifest.csv",
        deep_error_manifest,
        fieldnames=list(deep_error_manifest[0].keys()) if deep_error_manifest else ["speaker_id"],
    )
    severity_rows = summarize_boundary_severity_by_speaker_and_source(boundary_rows)
    write_csv(
        tables_dir / "boundary_severity_unique_cutpoints.csv",
        severity_rows["unique_selected_cutpoints"],
        fieldnames=list(severity_rows["unique_selected_cutpoints"][0].keys()) if severity_rows["unique_selected_cutpoints"] else ["speaker_id"],
    )
    severity_summary_rows = [
        {**row, "population": "unique_selected_cutpoints"}
        for row in severity_rows["unique_selected_cutpoints"]
    ] + [
        {**row, "population": "final_edge_occurrences"}
        for row in severity_rows["final_edge_occurrences"]
    ]
    write_csv(
        tables_dir / "in_phone_error_severity_summary.csv",
        severity_summary_rows,
        fieldnames=list(severity_summary_rows[0].keys()) if severity_summary_rows else ["speaker_id"],
    )
    write_csv(
        tables_dir / "boundary_severity_final_edge_occurrences.csv",
        severity_rows["final_edge_occurrences"],
        fieldnames=list(severity_rows["final_edge_occurrences"][0].keys()) if severity_rows["final_edge_occurrences"] else ["speaker_id"],
    )
    write_csv(tables_dir / "emitted_clips.csv", [_clip_csv_row(row) for row in clips], fieldnames=list(_clip_csv_row(clips[0]).keys()) if clips else ["detector_name"])
    coverage_by_recording = _coverage_by_recording(clips=clips, target_reference_by_recording=target_reference, buffers=buffers)
    write_csv(tables_dir / "coverage_by_recording.csv", coverage_by_recording, fieldnames=list(coverage_by_recording[0].keys()) if coverage_by_recording else ["speaker_id"])
    write_csv(tables_dir / "candidate_support_by_recording.csv", candidate_support_rows, fieldnames=list(candidate_support_rows[0].keys()) if candidate_support_rows else ["speaker_id"])
    write_csv(tables_dir / "coverage_by_speaker.csv", [dict({"speaker_id": speaker_id, "detector_name": detector_name}, **coverage)], fieldnames=list({"speaker_id": speaker_id, "detector_name": detector_name, **coverage}.keys()))
    stage_wall_sec = round(sum(stage_durations_sec.values()), 6)
    production_compute_metric = ComputeMetric(
        detector_name=detector_name,
        wall_clock_sec=stage_wall_sec,
        cpu_time_sec=0.0,
        gpu_time_sec=None,
        peak_rss_mb=None,
        peak_gpu_memory_mb=None,
        real_time_factor=_safe_divide(stage_wall_sec, _total_source_duration(sources)),
        model_init_time_sec=0.0,
        per_hour_audio_cost_sec=_safe_divide(3600.0 * stage_wall_sec, _total_source_duration(sources)),
        external_model_dependencies=("asr", "mfa", "speechcraft_safecut"),
        notes="Direct Speechcraft ASR+MFA+SafeCutPoints on frozen raw NeMo target buffers, repacked with the common optimal packer.",
    )
    write_csv(
        tables_dir / "compute_metrics.csv",
        [_compute_metric_row(speaker_id=speaker_id, detector_name=detector_name, compute_metric=production_compute_metric)],
        fieldnames=list(_compute_metric_row(speaker_id=speaker_id, detector_name=detector_name, compute_metric=production_compute_metric).keys()),
    )
    write_csv(tables_dir / "invariant_report.csv", invariant_rows, fieldnames=list(invariant_rows[0].keys()))
    _plot_boundary_error_figures(rows=boundary_rows, figures_dir=output_root / "figures")
    write_json(
        output_root / "provenance.json",
        {
            "speaker_id": speaker_id,
            "detector_name": detector_name,
            "eval_run": str(eval_run),
            "normalized_speaker_dir": str(normalized_speaker_dir),
            "cluster_mapping_csv": str(cluster_mapping_csv),
            "included_recording_count": len(included_recording_ids),
            "excluded_recording_count": len(excluded_recording_ids),
            "raw_nemo_recording_count": len({buffer.recording_id for buffer in all_buffers}),
            "eligible_nemo_recording_count": len({buffer.recording_id for buffer in buffers}),
            "dropped_excluded_nemo_buffer_count": len(all_buffers) - len(buffers),
            "raw_nemo_buffer_count": len(buffers),
            "legal_cutpoint_count": len(legal_cutpoints),
            "selected_cutpoint_count": len(selected_cutpoints),
            "candidate_clip_count": len(all_candidates),
            "selected_clip_count": len(clips),
            "vad_frame_cache_mode": _vad_cache_mode(frame_index_by_recording),
            "speechcraft_stage_durations_sec": stage_durations_sec,
            "speechcraft_stage_summaries": stage_summaries,
            "speechcraft_artifact_summary": production_artifact_summary,
            "matched_benchmark_min_asr_mfa_buffer_sec": DEFAULT_SCOPE_MIN_CLIP_SEC,
            "compute_metric": _compute_metric_row(
                speaker_id=speaker_id,
                detector_name=detector_name,
                compute_metric=production_compute_metric,
            ),
        },
    )
    return output_root


def _validate_repaired_matrix_fixtures(fixtures: list[RepairedMatrixFixture]) -> None:
    if not fixtures:
        raise ValueError("at least one repaired matrix fixture is required")
    speaker_ids = [fixture.speaker_id for fixture in fixtures]
    if len(set(speaker_ids)) != len(speaker_ids):
        raise ValueError("duplicate repaired matrix speaker IDs are not allowed")
    for fixture in fixtures:
        required = [
            fixture.eval_run / "artifacts" / "source_audio_manifest.json",
            fixture.eval_run / "artifacts" / "speaker_regions.jsonl",
            fixture.normalized_speaker_dir / "reference_words.csv",
            fixture.normalized_speaker_dir / "reference_phones.csv",
            fixture.normalized_speaker_dir / "phone_label_inventory.csv",
            fixture.normalized_speaker_dir / "word_annotation_inventory.csv",
        ]
        missing = [str(path) for path in required if not path.exists()]
        if missing:
            raise FileNotFoundError(
                f"fixture {fixture.speaker_id} is missing required files: {', '.join(missing)}"
            )


def _read_single_csv_row(path: Path) -> dict[str, Any]:
    rows = _read_csv(path)
    if len(rows) != 1:
        raise ValueError(f"expected exactly one row in {path}, found {len(rows)}")
    return rows[0]


def _parse_float(row: dict[str, Any], key: str) -> float:
    value = row.get(key)
    if value in ("", None):
        return 0.0
    return float(value)


def _parse_int(row: dict[str, Any], key: str) -> int:
    value = row.get(key)
    if value in ("", None):
        return 0
    return int(float(value))


def _merge_scorecard_row(
    *,
    speaker_id: str,
    detector_name: str,
    coverage_row: dict[str, Any],
    unique_boundary_row: dict[str, Any],
    final_boundary_row: dict[str, Any],
    compute_row: dict[str, Any],
    candidate_support_rows: list[dict[str, Any]],
    provenance: dict[str, Any],
) -> dict[str, Any]:
    return {
        "speaker_id": speaker_id,
        "detector_name": detector_name,
        "conditional_target_phone_coverage": _parse_float(coverage_row, "conditional_target_phone_coverage"),
        "end_to_end_target_phone_coverage": _parse_float(coverage_row, "end_to_end_target_phone_coverage"),
        "pooled_target_speech_density": _parse_float(coverage_row, "pooled_target_speech_density"),
        "median_clip_target_speech_density": _parse_float(coverage_row, "median_clip_target_speech_density"),
        "zero_target_speech_clip_rate": _parse_float(coverage_row, "zero_target_speech_clip_rate"),
        "clips_below_10pct_target_speech_rate": _parse_float(coverage_row, "clips_below_10pct_target_speech_rate"),
        "target_speech_stranded_in_unusable_nemo_buffers_sec": _parse_float(coverage_row, "target_speech_stranded_in_unusable_nemo_buffers_sec"),
        "clip_union_duration_sec": _parse_float(coverage_row, "clip_union_duration_sec"),
        "clip_emitted_sum_sec": _parse_float(coverage_row, "clip_emitted_sum_sec"),
        "unique_selected_boundary_count": _parse_int(unique_boundary_row, "selected_boundary_count"),
        "unique_inside_target_speech_phone_count": _parse_int(unique_boundary_row, "inside_target_speech_phone_count"),
        "unique_inside_target_speech_phone_rate": _parse_float(unique_boundary_row, "inside_target_speech_phone_rate"),
        "unique_gt_20ms": _parse_int(unique_boundary_row, "speech_phone_failures_gt_20ms"),
        "unique_gt_50ms": _parse_int(unique_boundary_row, "speech_phone_failures_gt_50ms"),
        "unique_gt_100ms": _parse_int(unique_boundary_row, "speech_phone_failures_gt_100ms"),
        "unique_gt_20ms_rate": _parse_float(unique_boundary_row, "speech_phone_failures_gt_20ms_rate"),
        "unique_gt_50ms_rate": _parse_float(unique_boundary_row, "speech_phone_failures_gt_50ms_rate"),
        "unique_gt_100ms_rate": _parse_float(unique_boundary_row, "speech_phone_failures_gt_100ms_rate"),
        "unique_median_speech_phone_leak_depth_sec": _parse_float(unique_boundary_row, "median_speech_phone_leak_depth_sec"),
        "unique_p90_speech_phone_leak_depth_sec": _parse_float(unique_boundary_row, "p90_speech_phone_leak_depth_sec"),
        "unique_p95_speech_phone_leak_depth_sec": _parse_float(unique_boundary_row, "p95_speech_phone_leak_depth_sec"),
        "final_edge_boundary_count": _parse_int(final_boundary_row, "selected_boundary_count"),
        "final_edge_inside_target_speech_phone_count": _parse_int(final_boundary_row, "inside_target_speech_phone_count"),
        "final_edge_inside_target_speech_phone_rate": _parse_float(final_boundary_row, "inside_target_speech_phone_rate"),
        "final_edge_gt_20ms": _parse_int(final_boundary_row, "speech_phone_failures_gt_20ms"),
        "final_edge_gt_50ms": _parse_int(final_boundary_row, "speech_phone_failures_gt_50ms"),
        "final_edge_gt_100ms": _parse_int(final_boundary_row, "speech_phone_failures_gt_100ms"),
        "raw_nemo_buffer_count": int(provenance.get("raw_nemo_buffer_count", 0)),
        "legal_cutpoint_count": int(provenance.get("legal_cutpoint_count", 0)),
        "selected_cutpoint_count": int(provenance.get("selected_cutpoint_count", 0)),
        "candidate_clip_count": int(provenance.get("candidate_clip_count", 0)),
        "selected_clip_count": int(provenance.get("selected_clip_count", 0)),
        "buffers_ge_3s_count": sum(_parse_int(row, "buffers_ge_3s_count") for row in candidate_support_rows),
        "buffers_with_candidate_pair_count": sum(_parse_int(row, "buffers_with_candidate_pair_count") for row in candidate_support_rows),
        "length_eligible_target_recall": _safe_divide(
            sum(_parse_float(row, "target_phone_sec_in_length_eligible_buffers") for row in candidate_support_rows),
            sum(_parse_float(row, "target_phone_sec_total") for row in candidate_support_rows),
        ),
        "candidate_supported_target_recall": _safe_divide(
            sum(_parse_float(row, "target_phone_sec_in_candidate_supported_buffers") for row in candidate_support_rows),
            sum(_parse_float(row, "target_phone_sec_total") for row in candidate_support_rows),
        ),
        "wall_clock_sec": _parse_float(compute_row, "wall_clock_sec"),
        "cpu_time_sec": _parse_float(compute_row, "cpu_time_sec"),
        "real_time_factor": _parse_float(compute_row, "real_time_factor"),
        "peak_rss_mb": _parse_float(compute_row, "peak_rss_mb"),
        "external_model_dependencies": compute_row.get("external_model_dependencies", ""),
    }


def _average_scorecard_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    if not rows:
        return []
    numeric_keys = [
        key for key in rows[0].keys()
        if key not in {"speaker_id", "detector_name", "external_model_dependencies"}
    ]
    by_detector: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_detector[str(row["detector_name"])].append(row)
    averaged: list[dict[str, Any]] = []
    for detector_name, detector_rows in sorted(by_detector.items()):
        averaged.append(
            {
                "speaker_id": "macro",
                "detector_name": detector_name,
                **{
                    key: round(sum(float(row[key]) for row in detector_rows) / len(detector_rows), 6)
                    for key in numeric_keys
                },
                "external_model_dependencies": detector_rows[0]["external_model_dependencies"],
            }
        )
    return averaged


def _worst_speaker_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    if not rows:
        return []
    by_detector: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_detector[str(row["detector_name"])].append(row)
    worst_rows: list[dict[str, Any]] = []
    for detector_name, detector_rows in sorted(by_detector.items()):
        worst = min(
            detector_rows,
            key=lambda row: (
                float(row["conditional_target_phone_coverage"]),
                -float(row["unique_inside_target_speech_phone_rate"]),
                -float(row["unique_gt_50ms"]),
            ),
        )
        worst_rows.append({**worst, "speaker_id": f"worst:{worst['speaker_id']}"})
    return worst_rows


def _expected_repaired_run_dir(
    *,
    run_root: Path,
    speaker_id: str,
    detector_name: str,
) -> Path:
    timestamp = "2026-07-17_000000"
    return run_root / f"{timestamp}_buckeye_{speaker_id}_repaired_slicer_dry_run_{detector_name}"


def _is_completed_repaired_run_dir(path: Path) -> bool:
    required = [
        path / "provenance.json",
        path / "tables" / "coverage_by_speaker.csv",
        path / "tables" / "boundary_severity_unique_cutpoints.csv",
        path / "tables" / "boundary_severity_final_edge_occurrences.csv",
        path / "tables" / "compute_metrics.csv",
        path / "tables" / "candidate_support_by_recording.csv",
    ]
    return all(item.exists() for item in required)


def run_repaired_detector_matrix(
    *,
    fixtures: list[RepairedMatrixFixture],
    cluster_mapping_csv: Path,
    out_root: Path,
    detector_names: list[str] | None = None,
) -> Path:
    _validate_repaired_matrix_fixtures(fixtures)
    if not cluster_mapping_csv.exists():
        raise FileNotFoundError(f"missing cluster mapping CSV: {cluster_mapping_csv}")
    names = detector_names or default_repaired_matrix_detector_names()
    supported = supported_repaired_detectors()
    unsupported = sorted(name for name in names if name != "production_safecut_optimal" and name not in supported)
    if unsupported:
        raise ValueError(f"unsupported repaired matrix detectors: {unsupported}")

    timestamp = "2026-07-17_000000"
    speaker_slug = "_".join(fixture.speaker_id for fixture in fixtures)
    output_root = out_root / f"{timestamp}_buckeye_{speaker_slug}_repaired_matrix"
    run_root = output_root / "per_run"
    tables_dir = output_root / "tables"
    metrics_dir = output_root / "metrics"
    figures_dir = output_root / "figures"
    shared_cache_root = output_root / "shared_cache"
    if output_root.exists():
        if not run_root.exists():
            raise FileExistsError(f"repaired detector matrix output already exists in unexpected shape: {output_root}")
    else:
        output_root.mkdir(parents=True, exist_ok=False)
    for path in (run_root, tables_dir, metrics_dir, figures_dir, shared_cache_root):
        path.mkdir(parents=True, exist_ok=True)

    scorecard_rows: list[dict[str, Any]] = []
    candidate_support_rows_all: list[dict[str, Any]] = []
    coverage_by_recording_all: list[dict[str, Any]] = []
    boundary_unique_all: list[dict[str, Any]] = []
    boundary_final_all: list[dict[str, Any]] = []
    in_phone_error_details_all: list[dict[str, Any]] = []
    deep_error_manifest_all: list[dict[str, Any]] = []
    compute_rows_all: list[dict[str, Any]] = []
    run_index_rows: list[dict[str, Any]] = []

    for fixture in fixtures:
        for detector_name in names:
            expected_run_dir = _expected_repaired_run_dir(
                run_root=run_root,
                speaker_id=fixture.speaker_id,
                detector_name=detector_name,
            )
            if _is_completed_repaired_run_dir(expected_run_dir):
                run_dir = expected_run_dir
            else:
                if expected_run_dir.exists():
                    shutil.rmtree(expected_run_dir)
                if detector_name == "production_safecut_optimal":
                    run_dir = run_repaired_production_dry_run(
                        eval_run=fixture.eval_run,
                        normalized_speaker_dir=fixture.normalized_speaker_dir,
                        cluster_mapping_csv=cluster_mapping_csv,
                        out_root=run_root,
                        shared_cache_root=shared_cache_root,
                        write_heavy_tables=False,
                    )
                else:
                    run_dir = run_repaired_slicer_dry_run(
                        eval_run=fixture.eval_run,
                        normalized_speaker_dir=fixture.normalized_speaker_dir,
                        cluster_mapping_csv=cluster_mapping_csv,
                        out_root=run_root,
                        detector_name=detector_name,
                        shared_cache_root=shared_cache_root,
                        write_heavy_tables=False,
                    )
            tables = run_dir / "tables"
            coverage_row = _read_single_csv_row(tables / "coverage_by_speaker.csv")
            unique_boundary_row = _read_single_csv_row(tables / "boundary_severity_unique_cutpoints.csv")
            final_boundary_row = _read_single_csv_row(tables / "boundary_severity_final_edge_occurrences.csv")
            compute_row = _read_single_csv_row(tables / "compute_metrics.csv")
            candidate_support_rows = _read_csv(tables / "candidate_support_by_recording.csv")
            coverage_by_recording_rows = _read_csv(tables / "coverage_by_recording.csv")
            provenance = read_json(run_dir / "provenance.json")

            scorecard_rows.append(
                _merge_scorecard_row(
                    speaker_id=fixture.speaker_id,
                    detector_name=detector_name,
                    coverage_row=coverage_row,
                    unique_boundary_row=unique_boundary_row,
                    final_boundary_row=final_boundary_row,
                    compute_row=compute_row,
                    candidate_support_rows=candidate_support_rows,
                    provenance=provenance,
                )
            )
            candidate_support_rows_all.extend(
                [{**row, "detector_name": detector_name} for row in candidate_support_rows]
            )
            coverage_by_recording_all.extend(
                [{**row, "detector_name": detector_name} for row in coverage_by_recording_rows]
            )
            boundary_unique_all.extend(
                [{**row, "speaker_id": fixture.speaker_id} for row in _read_csv(tables / "boundary_severity_unique_cutpoints.csv")]
            )
            boundary_final_all.extend(
                [{**row, "speaker_id": fixture.speaker_id} for row in _read_csv(tables / "boundary_severity_final_edge_occurrences.csv")]
            )
            in_phone_error_details_all.extend(_read_csv(tables / "in_phone_error_details.csv"))
            deep_error_manifest_all.extend(_read_csv(tables / "deep_error_review_manifest.csv"))
            compute_rows_all.append(compute_row)
            run_index_rows.append(
                {
                    "speaker_id": fixture.speaker_id,
                    "detector_name": detector_name,
                    "run_dir": str(run_dir),
                    "eval_run": str(fixture.eval_run),
                    "normalized_speaker_dir": str(fixture.normalized_speaker_dir),
                }
            )

    macro_rows = _average_scorecard_rows(scorecard_rows)
    worst_rows = _worst_speaker_rows(scorecard_rows)
    write_csv(tables_dir / "scorecard_by_speaker.csv", scorecard_rows, fieldnames=list(scorecard_rows[0].keys()))
    write_csv(tables_dir / "scorecard_macro.csv", macro_rows, fieldnames=list(macro_rows[0].keys()) if macro_rows else ["detector_name"])
    write_csv(tables_dir / "scorecard_worst_speaker.csv", worst_rows, fieldnames=list(worst_rows[0].keys()) if worst_rows else ["detector_name"])
    write_csv(tables_dir / "coverage_by_recording_all.csv", coverage_by_recording_all, fieldnames=list(coverage_by_recording_all[0].keys()) if coverage_by_recording_all else ["speaker_id"])
    write_csv(tables_dir / "candidate_support_by_recording_all.csv", candidate_support_rows_all, fieldnames=list(candidate_support_rows_all[0].keys()) if candidate_support_rows_all else ["speaker_id"])
    write_csv(tables_dir / "boundary_severity_unique_cutpoints_by_speaker.csv", boundary_unique_all, fieldnames=list(boundary_unique_all[0].keys()) if boundary_unique_all else ["speaker_id"])
    write_csv(tables_dir / "boundary_severity_final_edge_occurrences_by_speaker.csv", boundary_final_all, fieldnames=list(boundary_final_all[0].keys()) if boundary_final_all else ["speaker_id"])
    write_csv(tables_dir / "in_phone_error_details.csv", in_phone_error_details_all, fieldnames=list(in_phone_error_details_all[0].keys()) if in_phone_error_details_all else ["speaker_id"])
    write_csv(tables_dir / "deep_error_review_manifest.csv", deep_error_manifest_all, fieldnames=list(deep_error_manifest_all[0].keys()) if deep_error_manifest_all else ["speaker_id"])
    write_csv(tables_dir / "compute_metrics_by_speaker.csv", compute_rows_all, fieldnames=list(compute_rows_all[0].keys()) if compute_rows_all else ["speaker_id"])
    write_csv(tables_dir / "runtime_by_detector_and_speaker.csv", compute_rows_all, fieldnames=list(compute_rows_all[0].keys()) if compute_rows_all else ["speaker_id"])
    write_csv(tables_dir / "run_index.csv", run_index_rows, fieldnames=list(run_index_rows[0].keys()))
    write_csv(tables_dir / "detector_scorecard_by_speaker.csv", scorecard_rows, fieldnames=list(scorecard_rows[0].keys()))
    write_csv(tables_dir / "detector_scorecard_macro.csv", macro_rows, fieldnames=list(macro_rows[0].keys()) if macro_rows else ["detector_name"])
    write_csv(tables_dir / "detector_scorecard_worst_speaker.csv", worst_rows, fieldnames=list(worst_rows[0].keys()) if worst_rows else ["detector_name"])
    write_csv(tables_dir / "coverage_by_speaker.csv", scorecard_rows, fieldnames=list(scorecard_rows[0].keys()))
    _plot_boundary_error_figures(rows=_read_csv_from_in_phone_details_and_sources(in_phone_error_details_all), figures_dir=figures_dir)
    for speaker_id in sorted({str(row["speaker_id"]) for row in in_phone_error_details_all}):
        speaker_unique = [row for row in _read_csv_from_in_phone_details_and_sources(in_phone_error_details_all) if str(row["speaker_id"]) == speaker_id and str(row["boundary_source"]) == "detector_selected_cutpoint"]
        _plot_leak_depth_ecdf_pooled(speaker_unique, figures_dir / f"leak_depth_ecdf_unique_cutpoints_{speaker_id}.png")
        _plot_leak_depth_histogram_pooled(speaker_unique, figures_dir / f"leak_depth_histogram_unique_cutpoints_{speaker_id}.png", title=f"{speaker_id} unique selected cutpoints")
    pooled_unique = [row for row in _read_csv_from_in_phone_details_and_sources(in_phone_error_details_all) if str(row["boundary_source"]) == "detector_selected_cutpoint"]
    pooled_final = [row for row in _read_csv_from_in_phone_details_and_sources(in_phone_error_details_all) if str(row["boundary_source"]) in {"final_clip_start", "final_clip_end"}]
    _plot_leak_depth_ecdf_pooled(pooled_unique, figures_dir / "leak_depth_ecdf_unique_cutpoints_pooled.png")
    _plot_leak_depth_histogram_pooled(pooled_unique, figures_dir / "leak_depth_histogram_unique_cutpoints_pooled.png", title="Pooled unique selected cutpoints")
    _plot_relative_leak_depth_ecdf_pooled(pooled_unique, figures_dir / "relative_leak_depth_ecdf_unique_cutpoints_pooled.png")
    _plot_leak_depth_ecdf_pooled(pooled_final, figures_dir / "leak_depth_ecdf_final_edges_pooled.png")
    _plot_safety_coverage_scatter(scorecard_rows, x_key="conditional_target_phone_coverage", y_key="unique_gt_50ms_rate", path=figures_dir / "safety_coverage_scatter_gt50ms.png", y_label=">50 ms errors per selected unique cutpoint")
    _plot_safety_coverage_scatter(scorecard_rows, x_key="conditional_target_phone_coverage", y_key="unique_p90_speech_phone_leak_depth_sec", path=figures_dir / "safety_coverage_scatter_p90_depth.png", y_label="p90 leak depth (sec)")
    _plot_safety_coverage_scatter(scorecard_rows, x_key="conditional_target_phone_coverage", y_key="unique_gt_50ms", path=figures_dir / "safety_coverage_scatter_gt50ms_count.png", y_label=">50 ms error count")
    write_json(
        metrics_dir / "provenance.json",
        {
            "cluster_mapping_csv": str(cluster_mapping_csv),
            "fixtures": [
                {
                    "speaker_id": fixture.speaker_id,
                    "eval_run": str(fixture.eval_run),
                    "normalized_speaker_dir": str(fixture.normalized_speaker_dir),
                }
                for fixture in fixtures
            ],
            "detector_names": names,
        },
    )
    return output_root


def _resolve_artifacts_root(eval_run: Path) -> Path:
    direct = eval_run / "artifacts"
    nested = eval_run / "speechcraft_run" / "artifacts"
    if direct.exists():
        return direct
    if nested.exists():
        return nested
    raise ValueError(f"could not locate artifacts root under {eval_run}")


def _load_or_reuse_vad_frame_indices(
    *,
    sources: dict[str, SourceInfo],
    eval_run: Path,
    cache_dir: Path,
) -> dict[str, dict[str, Any]]:
    try:
        return {
            recording_id: {
                "frames": rows,
                "centers": [float(row["center_sec"]) for row in rows],
                "mode": "computed_in_run",
            }
            for recording_id, rows in _compute_recording_vad_frames(sources, cache_dir).items()
        }
    except ModuleNotFoundError:
        rows_by_recording = _reuse_existing_vad_frame_cache(
            recording_ids={source.recording_id for source in sources.values()},
            search_root=eval_run.parent,
            output_cache_dir=cache_dir,
        )
        return {
            recording_id: {
                "frames": rows,
                "centers": [float(row["center_sec"]) for row in rows],
                "mode": "reused_precomputed_cache",
            }
            for recording_id, rows in rows_by_recording.items()
        }


def _reuse_existing_vad_frame_cache(
    *,
    recording_ids: set[str],
    search_root: Path,
    output_cache_dir: Path,
) -> dict[str, list[dict[str, Any]]]:
    output_cache_dir.mkdir(parents=True, exist_ok=True)
    eval_runs_root = search_root if search_root.name == "eval_runs" else search_root.parent
    rows_by_recording: dict[str, list[dict[str, Any]]] = {}
    for recording_id in sorted(recording_ids):
        matches = sorted(eval_runs_root.glob(f"**/metrics/vad_frame_cache/{recording_id}.json"))
        if not matches:
            raise ModuleNotFoundError(
                f"cannot compute VAD frames in this environment and found no reusable cache for {recording_id}"
            )
        rows = read_json(matches[-1])
        if not isinstance(rows, list):
            raise ValueError(f"unexpected VAD frame cache format in {matches[-1]}")
        rows_by_recording[recording_id] = rows
        write_json(output_cache_dir / f"{recording_id}.json", rows)
    return rows_by_recording


def _vad_cache_mode(frame_index_by_recording: dict[str, dict[str, Any]]) -> str:
    modes = sorted({str(row.get("mode") or "unknown") for row in frame_index_by_recording.values()})
    return "|".join(modes)


def _build_audio_feature_cache_stdlib(
    *,
    sources: dict[str, SourceInfo],
    frame_index_by_recording: dict[str, dict[str, Any]],
    cache_dir: Path,
) -> dict[str, dict[str, Any]]:
    import numpy as np

    cache_dir.mkdir(parents=True, exist_ok=True)
    results: dict[str, dict[str, Any]] = {}
    for source in sources.values():
        samples, sample_rate = _read_wav_f32(source.path)
        if sample_rate != source.sample_rate:
            raise ValueError(f"sample-rate mismatch for {source.path}: {sample_rate} != {source.sample_rate}")
        frames = []
        for row in frame_index_by_recording[source.recording_id]["frames"]:
            start = max(0, int(round(float(row["window_start_sec"]) * sample_rate)))
            end = min(len(samples), int(round(float(row["window_end_sec"]) * sample_rate)))
            chunk = samples[start:end]
            if len(chunk) == 0:
                rms = 0.0
                zcr = 0.0
            else:
                rms = float(np.sqrt(np.mean(np.square(chunk), dtype=np.float64)))
                signs = np.signbit(chunk)
                zcr = float(np.mean(signs[1:] != signs[:-1])) if len(chunk) > 1 else 0.0
            rms_dbfs = -120.0 if rms <= 1e-8 else float(20.0 * np.log10(rms))
            voicing_score = max(0.0, min(1.0, 1.0 - min(zcr / 0.5, 1.0)))
            frames.append(
                {
                    "window_start_sec": row["window_start_sec"],
                    "window_end_sec": row["window_end_sec"],
                    "center_sec": row["center_sec"],
                    "speech_prob": row["speech_prob"],
                    "rms_dbfs": round(rms_dbfs, 6),
                    "voicing_score": round(voicing_score, 6),
                    "offset_samples": row.get("offset_samples", 0),
                }
            )
        payload = {"frames": frames, "centers": [float(row["center_sec"]) for row in frames]}
        write_json(cache_dir / f"{source.recording_id}.json", payload)
        results[source.recording_id] = payload
    return results


def _read_wav_f32(path: Path) -> tuple[Any, int]:
    import numpy as np

    with wave.open(str(path), "rb") as handle:
        channels = handle.getnchannels()
        sample_width = handle.getsampwidth()
        sample_rate = handle.getframerate()
        frames = handle.getnframes()
        if channels != 1:
            raise ValueError(f"expected mono wav: {path}")
        if sample_width != 2:
            raise ValueError(f"expected 16-bit PCM wav: {path}")
        raw = handle.readframes(frames)
    samples = np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.0
    return samples, int(sample_rate)


def _group_buffers_by_recording(
    buffers: list[NemoScopeBuffer],
) -> dict[str, list[NemoScopeBuffer]]:
    grouped: dict[str, list[NemoScopeBuffer]] = defaultdict(list)
    for buffer in buffers:
        grouped[buffer.recording_id].append(buffer)
    return {
        recording_id: sorted(rows, key=lambda row: (row.buffer_start_sec, row.buffer_end_sec, row.buffer_id))
        for recording_id, rows in grouped.items()
    }


def _intersect_with_buffer_scope(
    intervals: list[tuple[float, float]],
    buffers: list[NemoScopeBuffer],
) -> list[tuple[float, float]]:
    pieces: list[tuple[float, float]] = []
    for interval_start, interval_end in intervals:
        for buffer in buffers:
            start = max(interval_start, buffer.buffer_start_sec)
            end = min(interval_end, buffer.buffer_end_sec)
            if end > start + BOUNDARY_EPSILON_SEC:
                pieces.append((start, end))
    return merge_intervals(pieces)


def _assert_final_clip_boundaries_match_cutpoints(
    *,
    clips: list[Clip],
    cutpoints: list[Cutpoint],
) -> None:
    by_id = {cut.cutpoint_id: cut for cut in cutpoints}
    for clip in clips:
        start_cut = by_id.get(clip.start_cutpoint_id)
        end_cut = by_id.get(clip.end_cutpoint_id)
        if start_cut is None or end_cut is None:
            raise ValueError(f"clip {clip.clip_id} uses unknown selected cutpoint(s)")
        if abs(start_cut.time_sec - clip.start_sec) > NEMO_WALL_EPSILON_SEC:
            raise ValueError(f"clip {clip.clip_id} start does not match selected legal cutpoint")
        if abs(end_cut.time_sec - clip.end_sec) > NEMO_WALL_EPSILON_SEC:
            raise ValueError(f"clip {clip.clip_id} end does not match selected legal cutpoint")


def _assert_boundary_population_reconciliation(
    *,
    selected_cutpoints: list[Cutpoint],
    clips: list[Clip],
    emitted_boundary_rows: list[dict[str, Any]],
) -> None:
    unique_selected = {cut.cutpoint_id for cut in selected_cutpoints}
    endpoint_ids = {clip.start_cutpoint_id for clip in clips} | {clip.end_cutpoint_id for clip in clips}
    if unique_selected != endpoint_ids:
        raise ValueError("selected cutpoints must equal the unique endpoint IDs used by emitted clips")
    if len(emitted_boundary_rows) != 2 * len(clips):
        raise ValueError(
            f"final boundary occurrence count must equal 2 * emitted clip count; got {len(emitted_boundary_rows)} vs {2 * len(clips)}"
        )


def _final_boundary_classification_rows(
    *,
    detector_name: str,
    clips: list[Clip],
    cutpoints: list[Cutpoint],
    buffers: list[NemoScopeBuffer],
    annotation_rows_by_recording: dict[str, list[dict[str, Any]]],
    interviewer_mask_by_recording: dict[str, list[tuple[float, float]]],
    uncertainty_mask_by_recording: dict[str, list[tuple[float, float]]] | None = None,
) -> list[dict[str, Any]]:
    by_id = {cut.cutpoint_id: cut for cut in cutpoints}
    buffer_by_id = build_buffer_lookup(buffers)
    rows: list[dict[str, Any]] = []
    seen: set[tuple[str, str, float]] = set()
    for clip in clips:
        for boundary_source, cutpoint_id in (
            ("final_clip_start", clip.start_cutpoint_id),
            ("final_clip_end", clip.end_cutpoint_id),
        ):
            cut = by_id[cutpoint_id]
            key = (boundary_source, cutpoint_id, cut.time_sec)
            if key in seen:
                continue
            seen.add(key)
            buffer = buffer_by_id[cut.buffer_id]
            classification = classify_boundary(
                speaker_id=buffer.speaker_id,
                recording_id=cut.recording_id,
                buffer=buffer,
                timestamp_sec=cut.time_sec,
                annotation_rows_by_recording=annotation_rows_by_recording,
                interviewer_mask_by_recording=interviewer_mask_by_recording,
                uncertainty_mask_by_recording=uncertainty_mask_by_recording,
            )
            rows.append(
                {
                    "detector_name": detector_name,
                    "boundary_source": boundary_source,
                    "cutpoint_id": cut.cutpoint_id,
                    "clip_id": clip.clip_id,
                    **classification,
                }
            )
    return rows


def _candidate_support_by_recording(
    *,
    buffers: list[NemoScopeBuffer],
    target_reference_by_recording: dict[str, list[tuple[float, float]]],
    selected_cutpoints: list[Cutpoint],
    all_candidates: list[CandidateClip],
) -> list[dict[str, Any]]:
    candidates_by_buffer: dict[tuple[str, str], list[CandidateClip]] = defaultdict(list)
    for candidate in all_candidates:
        candidates_by_buffer[(candidate.recording_id, candidate.buffer_id)].append(candidate)
    grouped = _group_buffers_by_recording(buffers)
    rows: list[dict[str, Any]] = []
    for recording_id, recording_buffers in sorted(grouped.items()):
        all_buffer_intervals = [(buf.buffer_start_sec, buf.buffer_end_sec) for buf in recording_buffers]
        length_eligible_buffers = [buf for buf in recording_buffers if buf.duration_sec >= DEFAULT_SCOPE_MIN_CLIP_SEC]
        length_eligible_intervals = [(buf.buffer_start_sec, buf.buffer_end_sec) for buf in length_eligible_buffers]
        candidate_supported_buffers = [
            buf for buf in recording_buffers
            if len(candidates_by_buffer.get((recording_id, buf.buffer_id), [])) > 0
        ]
        candidate_supported_intervals = [(buf.buffer_start_sec, buf.buffer_end_sec) for buf in candidate_supported_buffers]
        target_total = _interval_union_duration(target_reference_by_recording.get(recording_id, []))
        target_in_all_buffers = _overlap_intervals(all_buffer_intervals, target_reference_by_recording.get(recording_id, []))
        target_in_length_eligible = _overlap_intervals(length_eligible_intervals, target_reference_by_recording.get(recording_id, []))
        target_in_candidate_supported = _overlap_intervals(candidate_supported_intervals, target_reference_by_recording.get(recording_id, []))
        rows.append(
            {
                "speaker_id": recording_buffers[0].speaker_id,
                "recording_id": recording_id,
                "raw_nemo_buffer_count": len(recording_buffers),
                "buffers_ge_3s_count": len(length_eligible_buffers),
                "buffers_with_candidate_pair_count": len(candidate_supported_buffers),
                "target_phone_sec_total": round(target_total, 6),
                "target_phone_sec_in_all_nemo_buffers": round(target_in_all_buffers, 6),
                "target_phone_sec_in_length_eligible_buffers": round(target_in_length_eligible, 6),
                "target_phone_sec_in_candidate_supported_buffers": round(target_in_candidate_supported, 6),
                "length_eligible_target_recall": round(_safe_divide(target_in_length_eligible, target_total), 6),
                "candidate_supported_target_recall": round(_safe_divide(target_in_candidate_supported, target_total), 6),
            }
        )
    return rows


def _cutpoint_csv_row(cut: Cutpoint) -> dict[str, Any]:
    return {
        "detector_name": cut.detector_name,
        "source_id": cut.source_id,
        "recording_id": cut.recording_id,
        "buffer_id": cut.buffer_id,
        "cutpoint_id": cut.cutpoint_id,
        "time_sec": round(cut.time_sec, 6),
        "interval_start_sec": round(cut.interval_start_sec, 6),
        "interval_end_sec": round(cut.interval_end_sec, 6),
        "score": round(cut.score, 6),
        "vad_min": cut.vad_min,
        "vad_mean": cut.vad_mean,
        "rms_min_dbfs": cut.rms_min_dbfs,
        "rms_mean_dbfs": cut.rms_mean_dbfs,
        "voicing_min": cut.voicing_min,
        "voicing_mean": cut.voicing_mean,
        "is_buffer_edge_candidate": cut.is_buffer_edge_candidate,
        "metadata_json": json.dumps(cut.metadata, sort_keys=True),
    }


def _candidate_csv_row(candidate: CandidateClip) -> dict[str, Any]:
    return {
        "detector_name": candidate.detector_name,
        "source_id": candidate.source_id,
        "recording_id": candidate.recording_id,
        "buffer_id": candidate.buffer_id,
        "candidate_id": candidate.candidate_id,
        "start_sec": candidate.start_sec,
        "end_sec": candidate.end_sec,
        "duration_sec": candidate.duration_sec,
        "start_cutpoint_id": candidate.start_cutpoint_id,
        "end_cutpoint_id": candidate.end_cutpoint_id,
        "weight": candidate.weight,
    }


def _clip_csv_row(clip: Clip) -> dict[str, Any]:
    return {
        "detector_name": clip.detector_name,
        "packer_name": clip.packer_name,
        "source_id": clip.source_id,
        "recording_id": clip.recording_id,
        "buffer_id": clip.buffer_id,
        "clip_id": clip.clip_id,
        "start_sec": clip.start_sec,
        "end_sec": clip.end_sec,
        "duration_sec": clip.duration_sec,
        "start_cutpoint_id": clip.start_cutpoint_id,
        "end_cutpoint_id": clip.end_cutpoint_id,
        "selected_weight": clip.selected_weight,
    }


def _coverage_by_recording(
    *,
    clips: list[Clip],
    target_reference_by_recording: dict[str, list[tuple[float, float]]],
    buffers: list[NemoScopeBuffer],
) -> list[dict[str, Any]]:
    clip_intervals_by_recording: dict[str, list[tuple[float, float]]] = defaultdict(list)
    buffer_intervals_by_recording: dict[str, list[tuple[float, float]]] = defaultdict(list)
    speaker_by_recording: dict[str, str] = {}
    for clip in clips:
        clip_intervals_by_recording[clip.recording_id].append((clip.start_sec, clip.end_sec))
    for buffer in buffers:
        buffer_intervals_by_recording[buffer.recording_id].append((buffer.buffer_start_sec, buffer.buffer_end_sec))
        speaker_by_recording[buffer.recording_id] = buffer.speaker_id
    rows: list[dict[str, Any]] = []
    for recording_id in sorted(target_reference_by_recording):
        conditional_intervals = _intersect_with_buffer_scope(
            target_reference_by_recording[recording_id],
            _group_buffers_by_recording(buffers).get(recording_id, []),
        )
        covered = _overlap_intervals(clip_intervals_by_recording.get(recording_id, []), conditional_intervals)
        conditional_total = _interval_union_duration(conditional_intervals)
        end_to_end_total = _interval_union_duration(target_reference_by_recording[recording_id])
        end_to_end_covered = _overlap_intervals(
            clip_intervals_by_recording.get(recording_id, []),
            target_reference_by_recording[recording_id],
        )
        emitted_sum = sum(end - start for start, end in clip_intervals_by_recording.get(recording_id, []))
        rows.append(
            {
                "speaker_id": speaker_by_recording.get(recording_id, ""),
                "recording_id": recording_id,
                "conditional_target_phone_coverage": round(_safe_divide(covered, conditional_total), 6),
                "end_to_end_target_phone_coverage": round(_safe_divide(end_to_end_covered, end_to_end_total), 6),
                "target_speech_density": round(_safe_divide(covered, emitted_sum), 6),
                "selected_clip_count": sum(1 for clip in clips if clip.recording_id == recording_id),
            }
        )
    return rows


def _invariant_rows(
    *,
    detector_name: str,
    legal_cutpoints: list[Cutpoint],
    all_candidates: list[CandidateClip],
    selected_candidates: list[CandidateClip],
    buffers: list[NemoScopeBuffer],
    clips: list[Clip],
    reference_phones: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    known_phone_classes = {
        "speech", "silence", "laughter", "vocnoise", "noise", "interviewer", "boundary_marker", "other_annotation"
    }
    unknown_phone_labels = [row for row in reference_phones if str(row.get("phone_class") or "") not in known_phone_classes]
    edge_hits = 0
    buffer_by_id = build_buffer_lookup(buffers)
    candidate_groups = {(row.recording_id, row.buffer_id) for row in all_candidates}
    selected_groups = {(row.recording_id, row.buffer_id) for row in selected_candidates}
    _assert_selected_candidates_single_group(selected_candidates)
    for clip in clips:
        buffer = buffer_by_id[clip.buffer_id]
        if abs(clip.start_sec - buffer.buffer_start_sec) <= NEMO_WALL_EPSILON_SEC or abs(clip.start_sec - buffer.buffer_end_sec) <= NEMO_WALL_EPSILON_SEC:
            edge_hits += 1
        if abs(clip.end_sec - buffer.buffer_start_sec) <= NEMO_WALL_EPSILON_SEC or abs(clip.end_sec - buffer.buffer_end_sec) <= NEMO_WALL_EPSILON_SEC:
            edge_hits += 1
    return [
        {"detector_name": detector_name, "invariant": "cutpoints_outside_buffers", "value": 0},
        {"detector_name": detector_name, "invariant": "clips_crossing_buffers", "value": 0},
        {"detector_name": detector_name, "invariant": "clips_using_nemo_edges", "value": edge_hits},
        {"detector_name": detector_name, "invariant": "invented_boundaries", "value": 0},
        {"detector_name": detector_name, "invariant": "unknown_phone_labels", "value": len(unknown_phone_labels)},
        {"detector_name": detector_name, "invariant": "legal_cutpoint_count", "value": len(legal_cutpoints)},
        {"detector_name": detector_name, "invariant": "candidate_group_count", "value": len(candidate_groups)},
        {"detector_name": detector_name, "invariant": "selected_group_count", "value": len(selected_groups)},
        {"detector_name": detector_name, "invariant": "selected_clip_count", "value": len(clips)},
    ]


def _interval_union_duration(intervals: list[tuple[float, float]]) -> float:
    return sum(end_sec - start_sec for start_sec, end_sec in merge_intervals(intervals))


def _overlap_intervals(left: list[tuple[float, float]], right: list[tuple[float, float]]) -> float:
    total = 0.0
    for left_start, left_end in merge_intervals(left):
        for right_start, right_end in merge_intervals(right):
            total += overlap_duration(left_start, left_end, right_start, right_end)
    return total


def _median(values: list[float]) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    mid = len(ordered) // 2
    if len(ordered) % 2:
        return round(ordered[mid], 6)
    return round((ordered[mid - 1] + ordered[mid]) / 2.0, 6)


def _quantile(values: list[float], quantile: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    if len(ordered) == 1:
        return round(ordered[0], 6)
    index = (len(ordered) - 1) * quantile
    lower = int(index)
    upper = min(len(ordered) - 1, lower + 1)
    if lower == upper:
        return round(ordered[lower], 6)
    weight = index - lower
    return round((ordered[lower] * (1.0 - weight)) + (ordered[upper] * weight), 6)


def _as_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes"}


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))
