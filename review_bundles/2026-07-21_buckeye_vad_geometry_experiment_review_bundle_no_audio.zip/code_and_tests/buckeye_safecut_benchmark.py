from __future__ import annotations

import csv
import json
import math
import os
import random
import statistics
import wave
from bisect import bisect_left, bisect_right
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .buckeye import classify_phone_event_type
from .intervals import merge_intervals, overlap_duration
from .io_utils import read_json, read_jsonl, write_csv, write_json


EPSILON_SEC = 1e-9
DEFAULT_SAFE_REGION_MIN_MS = 40
DEFAULT_PHONE_GUARD_MS = 50
DEFAULT_VAD_THRESHOLD = 0.2
DEFAULT_VAD_MIN_RUN_MS = 40
VAD_WINDOW_SAMPLES = 512
VAD_HOP_SAMPLES = 256
VAD_OFFSETS = (0, 128)
SAFE_REGION_POLICIES = ("strict", "moderate", "permissive")
STRICT_SAFE_TYPES = {"silence", "pause"}
MODERATE_EXTRA_TYPES = {"breath"}
PERMISSIVE_EXTRA_TYPES = {"hesitation", "non_lexical_vocalization"}


@dataclass(frozen=True)
class SourceInfo:
    source_audio_id: str
    recording_id: str
    path: Path
    duration_sec: float
    sample_rate: int
    num_samples: int


def evaluate_buckeye_safecut(
    *,
    eval_run: Path,
    normalized_speaker_dir: Path,
) -> Path:
    output_root = eval_run
    tables_dir = output_root / "tables"
    metrics_dir = output_root / "metrics"
    audit_audio_dir = output_root / "audit_audio"
    tables_dir.mkdir(parents=True, exist_ok=True)
    metrics_dir.mkdir(parents=True, exist_ok=True)
    audit_audio_dir.mkdir(parents=True, exist_ok=True)

    reference_words = _read_csv(normalized_speaker_dir / "reference_words.csv")
    reference_phones = _read_csv(normalized_speaker_dir / "reference_phones.csv")
    malformed_rows = _read_csv(normalized_speaker_dir / "malformed_rows.csv") if (normalized_speaker_dir / "malformed_rows.csv").exists() else []

    sources = _load_sources(eval_run / "speechcraft_run" / "artifacts" / "source_audio_manifest.json")
    buffers = _read_json(eval_run / "speechcraft_run" / "artifacts" / "processing_buffers.json")
    queue_rows = _read_json(eval_run / "speechcraft_run" / "artifacts" / "asr_mfa_queue.json")
    transcripts = _read_json(eval_run / "speechcraft_run" / "artifacts" / "transcripts.json")
    normalized_transcripts = _read_json(eval_run / "speechcraft_run" / "artifacts" / "normalized_transcripts.json")
    aligned_words = read_jsonl(eval_run / "speechcraft_run" / "artifacts" / "aligned_words.jsonl")
    alignment_qc = _read_json(eval_run / "speechcraft_run" / "artifacts" / "alignment_qc_by_buffer.json")
    safe_cutpoints = read_jsonl(eval_run / "speechcraft_run" / "artifacts" / "safe_cutpoints.jsonl")
    rejected_cutpoints = read_jsonl(eval_run / "speechcraft_run" / "artifacts" / "rejected_cutpoint_candidates.jsonl")
    candidate_review_manifest = _read_json(eval_run / "speechcraft_run" / "artifacts" / "candidate_review_manifest.json")
    speaker_selection = read_json(eval_run / "speechcraft_run" / "artifacts" / "speaker_selection.json")
    runtime_versions = read_json(eval_run / "speechcraft_run" / "runtime_versions.json")
    config = read_json(eval_run / "speechcraft_run" / "config.json")

    reference_words_by_recording = _group_by(reference_words, "recording_id")
    reference_phones_by_recording = _group_by(reference_phones, "recording_id")
    lexical_words_by_recording = {
        key: [row for row in rows if _as_bool(row["is_lexical_word"])]
        for key, rows in reference_words_by_recording.items()
    }
    speech_phones_by_recording = {
        key: [row for row in rows if _as_bool(row["is_speech_phone"])]
        for key, rows in reference_phones_by_recording.items()
    }

    buffer_by_id = {str(row["buffer_id"]): row for row in buffers}
    queue_by_id = {str(row["buffer_id"]): row for row in queue_rows}
    transcript_by_buffer = {str(row["buffer_id"]): row for row in transcripts}
    normalized_by_buffer = {str(row["buffer_id"]): row for row in normalized_transcripts}
    qc_by_buffer = {str(row["buffer_id"]): row for row in alignment_qc}
    words_by_buffer = _group_by(aligned_words, "buffer_id")
    current_cuts_by_buffer = _group_by(safe_cutpoints, "buffer_id")
    rejected_cuts_by_buffer = _group_by(rejected_cutpoints, "buffer_id")

    safe_regions = _build_reference_safe_regions(reference_words_by_recording, reference_phones_by_recording)
    safe_regions_by_recording = _group_by(safe_regions, "recording_id")

    timestamp_rows = _build_timestamp_mapping_crosscheck(
        buffer_by_id=buffer_by_id,
        words_by_buffer=words_by_buffer,
        current_cuts_by_buffer=current_cuts_by_buffer,
        candidate_review_manifest=candidate_review_manifest,
        sources=sources,
    )
    write_csv(
        tables_dir / "timestamp_mapping_crosscheck.csv",
        timestamp_rows,
        fieldnames=[
            "speaker_id",
            "recording_id",
            "buffer_id",
            "buffer_local_start_sec",
            "buffer_local_end_sec",
            "source_start_sec",
            "source_end_sec",
            "mapping_valid",
            "error_reason",
        ],
    )

    alignment_failure_rows = _build_alignment_failure_crosscheck(
        buffer_by_id=buffer_by_id,
        transcript_by_buffer=transcript_by_buffer,
        normalized_by_buffer=normalized_by_buffer,
        qc_by_buffer=qc_by_buffer,
        words_by_buffer=words_by_buffer,
        reference_words_by_recording=lexical_words_by_recording,
        reference_phones_by_recording=speech_phones_by_recording,
        eval_run=eval_run,
        sources=sources,
    )
    write_csv(
        tables_dir / "alignment_failure_crosscheck.csv",
        alignment_failure_rows,
        fieldnames=[
            "recording_id",
            "buffer_id",
            "source_start_sec",
            "source_end_sec",
            "asr_transcript",
            "normalized_token_count",
            "mfa_textgrid_exists",
            "mfa_word_count",
            "parsed_aligned_word_count",
            "fatal_reason_codes",
            "buckeye_reference_lexical_word_count",
            "buckeye_reference_speech_phone_duration_sec",
            "likely_failure_class",
        ],
    )

    current_eval_rows = _build_current_safecut_reference_eval(
        current_cuts=safe_cutpoints,
        words_by_buffer=words_by_buffer,
        buffer_by_id=buffer_by_id,
        sources=sources,
        lexical_words_by_recording=lexical_words_by_recording,
        speech_phones_by_recording=speech_phones_by_recording,
        safe_regions_by_recording=safe_regions_by_recording,
        eval_run=eval_run,
    )
    write_csv(
        tables_dir / "current_safecut_reference_eval.csv",
        current_eval_rows,
        fieldnames=[
            "speaker_id",
            "recording_id",
            "buffer_id",
            "cutpoint_id",
            "cut_time_sec",
            "left_aligned_word",
            "right_aligned_word",
            "production_gap_duration_ms",
            "production_valley_dbfs",
            "production_noise_floor_dbfs",
            "inside_reference_word",
            "inside_reference_phone",
            "overlapping_reference_word",
            "overlapping_reference_phone",
            "overlapping_reference_phone_start_sec",
            "overlapping_reference_phone_end_sec",
            "previous_reference_word",
            "next_reference_word",
            "previous_reference_phone",
            "next_reference_phone",
            "previous_phone_end_sec",
            "next_phone_start_sec",
            "clearance_after_previous_phone_ms",
            "clearance_before_next_phone_ms",
            "nearest_reference_phone_distance_ms",
            "unsafe_at_0ms_guard",
            "unsafe_at_20ms_guard",
            "unsafe_at_50ms_guard",
            "unsafe_at_100ms_guard",
            "reference_safe_region_id",
            "frame_vad_min",
            "frame_vad_mean",
            "longest_vad_run_below_0_1_ms",
            "longest_vad_run_below_0_2_ms",
        ],
    )

    write_csv(
        tables_dir / "reference_safe_regions.csv",
        safe_regions,
        fieldnames=[
            "speaker_id",
            "recording_id",
            "safe_region_id",
            "start_sec",
            "end_sec",
            "duration_ms",
            "region_type",
            "policy_category",
            "strict_eligible",
            "moderate_eligible",
            "permissive_eligible",
            "previous_word",
            "next_word",
            "previous_phone",
            "next_phone",
            "eligible_at_20ms",
            "eligible_at_40ms",
            "eligible_at_60ms",
            "eligible_at_80ms",
            "eligible_at_100ms",
            "exclusion_reason",
        ],
    )
    corrected_safe_regions = _build_corrected_safe_regions(safe_regions)
    write_csv(
        tables_dir / "reference_safe_regions_corrected.csv",
        corrected_safe_regions,
        fieldnames=[
            "speaker_id",
            "recording_id",
            "safe_region_id",
            "start_sec",
            "end_sec",
            "duration_ms",
            "region_type",
            "policy_category",
            "strict_eligible",
            "moderate_eligible",
            "permissive_eligible",
            "previous_word",
            "next_word",
            "previous_phone",
            "next_phone",
            "eligible_at_20ms",
            "eligible_at_40ms",
            "eligible_at_60ms",
            "eligible_at_80ms",
            "eligible_at_100ms",
            "exclusion_reason",
        ],
    )
    corrected_safe_regions_by_recording = _group_by(corrected_safe_regions, "recording_id")
    safe_region_policy_summary_rows = _build_safe_region_policy_summary(corrected_safe_regions)
    write_csv(
        tables_dir / "safe_region_policy_summary.csv",
        safe_region_policy_summary_rows,
        fieldnames=[
            "scope_type",
            "scope_id",
            "policy",
            "total_regions",
            "eligible_regions_20ms",
            "eligible_regions_40ms",
            "eligible_regions_60ms",
            "eligible_regions_80ms",
            "eligible_regions_100ms",
            "eligible_duration_sec_40ms",
            "region_type_counts",
        ],
    )

    vad_frames_by_recording = _compute_recording_vad_frames(sources, metrics_dir / "vad_frame_cache")
    vad_frame_index_by_recording = {recording_id: _index_frames(frames) for recording_id, frames in vad_frames_by_recording.items()}
    reference_safe_region_vad_rows = _build_reference_safe_region_vad_analysis(
        safe_regions=safe_regions,
        vad_frame_index_by_recording=vad_frame_index_by_recording,
        current_eval_rows=current_eval_rows,
    )
    write_csv(
        tables_dir / "reference_safe_region_vad_analysis.csv",
        reference_safe_region_vad_rows,
        fieldnames=[
            "speaker_id",
            "recording_id",
            "safe_region_id",
            "region_type",
            "duration_ms",
            "min_vad_prob",
            "mean_vad_prob",
            "median_vad_prob",
            "p10_vad_prob",
            "fraction_below_0_1",
            "fraction_below_0_2",
            "longest_continuous_run_below_0_1_ms",
            "longest_continuous_run_below_0_2_ms",
            "rms_min_dbfs",
            "rms_mean_dbfs",
            "detected_by_current",
        ],
    )

    detector_candidates = _build_detector_candidates(
        buffer_by_id=buffer_by_id,
        words_by_buffer=words_by_buffer,
        current_cuts_by_buffer=current_cuts_by_buffer,
        rejected_cuts_by_buffer=rejected_cuts_by_buffer,
        sources=sources,
        vad_frame_index_by_recording=vad_frame_index_by_recording,
        config=config,
    )
    detection_rows = _build_reference_safe_region_detection(
        safe_regions=safe_regions,
        detector_candidates=detector_candidates,
        buffer_by_id=buffer_by_id,
        qc_by_buffer=qc_by_buffer,
        sources=sources,
    )
    write_csv(
        tables_dir / "reference_safe_region_detection.csv",
        detection_rows,
        fieldnames=[
            "speaker_id",
            "recording_id",
            "safe_region_id",
            "region_type",
            "duration_ms",
            "overlaps_any_buffer",
            "overlaps_passing_buffer",
            "detected_by_current",
            "detected_by_vad",
            "detected_by_current_plus_vad",
            "detected_by_current_plus_vad_plus_edge",
            "detected_by_word_gap_acoustic_first_hybrid",
        ],
    )
    corrected_detection_rows = _build_reference_safe_region_detection_corrected(corrected_safe_regions, detection_rows)
    write_csv(
        tables_dir / "reference_safe_region_detection_corrected.csv",
        corrected_detection_rows,
        fieldnames=[
            "speaker_id",
            "recording_id",
            "safe_region_id",
            "start_sec",
            "end_sec",
            "region_type",
            "policy_category",
            "duration_ms",
            "overlaps_any_buffer",
            "overlaps_passing_buffer",
            "strict_eligible",
            "moderate_eligible",
            "permissive_eligible",
            "detected_by_current",
            "detected_by_vad",
            "detected_by_current_plus_vad",
            "detected_by_current_plus_vad_plus_edge",
            "detected_by_word_gap_acoustic_first_hybrid",
        ],
    )

    detector_rows = _build_detector_comparison(
        detector_candidates=detector_candidates,
        safe_regions=safe_regions,
        detection_rows=detection_rows,
        lexical_words_by_recording=lexical_words_by_recording,
        speech_phones_by_recording=speech_phones_by_recording,
        current_eval_rows=current_eval_rows,
    )
    write_csv(
        tables_dir / "detector_comparison.csv",
        detector_rows,
        fieldnames=[
            "scope_type",
            "scope_id",
            "detector",
            "min_region_ms",
            "phone_guard_ms",
            "predicted_cut_count",
            "cut_inside_word_count",
            "cut_inside_phone_count",
            "safe_cut_precision",
            "eligible_safe_region_recall_all_buffers",
            "eligible_safe_region_recall_passing_buffers",
            "median_phone_clearance_ms",
            "p05_phone_clearance_ms",
            "median_safe_region_duration_ms",
            "detected_buffer_edge_safe_regions",
            "missed_safe_regions",
            "unsafe_cut_severity_ms",
            "reference_safe_regions_recovered_only_by_detector",
        ],
    )
    corrected_detector_rows = _build_detector_comparison_corrected(
        detector_candidates=detector_candidates,
        corrected_detection_rows=corrected_detection_rows,
        lexical_words_by_recording=lexical_words_by_recording,
        speech_phones_by_recording=speech_phones_by_recording,
    )
    write_csv(
        tables_dir / "detector_comparison_corrected.csv",
        corrected_detector_rows,
        fieldnames=[
            "scope_type",
            "scope_id",
            "policy",
            "detector",
            "min_region_ms",
            "phone_guard_ms",
            "predicted_cut_count",
            "cut_inside_word_count",
            "cut_inside_phone_count",
            "safe_cut_precision_region",
            "safe_cut_precision_phone_guard",
            "eligible_safe_region_recall_all_buffers",
            "eligible_safe_region_recall_passing_buffers",
            "median_phone_clearance_ms",
            "p05_phone_clearance_ms",
            "median_safe_region_duration_ms",
            "detected_buffer_edge_safe_regions",
            "missed_safe_regions",
            "unsafe_cut_severity_ms",
            "reference_safe_regions_recovered_only_by_detector",
        ],
    )

    oracle_rows = _build_oracle_yield_comparison(
        detector_candidates=detector_candidates,
        candidate_review_manifest=candidate_review_manifest,
        speech_phones_by_recording=speech_phones_by_recording,
        lexical_words_by_recording=lexical_words_by_recording,
        safe_regions_by_recording=safe_regions_by_recording,
        config=config,
        sources=sources,
    )
    write_csv(
        tables_dir / "oracle_yield_comparison.csv",
        oracle_rows,
        fieldnames=[
            "scope_type",
            "scope_id",
            "detector",
            "oracle_clip_count",
            "oracle_total_clip_duration_sec",
            "oracle_lexical_speech_duration_captured_sec",
            "oracle_clean_speech_duration_captured_sec",
            "reference_safe_boundary_violations",
            "duration_lost_no_legal_pair_sec",
            "duration_lost_missing_boundaries_sec",
            "gain_over_current_detector_sec",
            "gain_over_current_greedy_production_packing_sec",
        ],
    )
    corrected_oracle_rows = _build_oracle_yield_comparison_corrected(
        detector_candidates=detector_candidates,
        candidate_review_manifest=candidate_review_manifest,
        speech_phones_by_recording=speech_phones_by_recording,
        lexical_words_by_recording=lexical_words_by_recording,
        corrected_safe_regions_by_recording=corrected_safe_regions_by_recording,
        config=config,
        sources=sources,
    )
    write_csv(
        tables_dir / "oracle_yield_comparison_corrected.csv",
        corrected_oracle_rows,
        fieldnames=[
            "scope_type",
            "scope_id",
            "policy",
            "detector",
            "oracle_clip_count",
            "oracle_total_clip_duration_sec",
            "oracle_lexical_speech_duration_captured_sec",
            "oracle_clean_speech_duration_captured_sec",
            "reference_safe_boundary_violations",
            "duration_lost_no_legal_pair_sec",
            "duration_lost_missing_boundaries_sec",
            "gain_over_current_detector_sec",
            "gain_over_current_greedy_production_packing_sec",
        ],
    )

    current_phone_overlap_rows = _build_current_phone_overlap_severity(
        current_eval_rows=current_eval_rows,
        candidate_review_manifest=candidate_review_manifest,
    )
    write_csv(
        tables_dir / "current_phone_overlap_severity.csv",
        current_phone_overlap_rows,
        fieldnames=[
            "recording_id",
            "buffer_id",
            "cutpoint_id",
            "phone_label",
            "phone_start_sec",
            "phone_end_sec",
            "cut_time_sec",
            "ms_from_phone_start",
            "ms_to_phone_end",
            "phone_duration_ms",
            "fraction_phone_before_cut",
            "fraction_phone_after_cut",
            "within_5ms_of_phone_edge",
            "within_10ms_of_phone_edge",
            "within_20ms_of_phone_edge",
            "within_50ms_of_phone_edge",
            "within_100ms_of_phone_edge",
            "used_in_candidate_clip",
            "used_as_clip_start",
            "used_as_clip_end",
            "candidate_clip_ids",
            "used_in_final_exported_clip",
            "used_as_final_clip_start",
            "used_as_final_clip_end",
            "final_exported_clip_ids",
            "second_pass_asr_transcript",
        ],
    )
    boundary_stage_rows = _build_boundary_safety_by_pipeline_stage(
        current_eval_rows=current_eval_rows,
        current_phone_overlap_rows=current_phone_overlap_rows,
        candidate_review_manifest=candidate_review_manifest,
    )
    write_csv(
        tables_dir / "boundary_safety_by_pipeline_stage.csv",
        boundary_stage_rows,
        fieldnames=[
            "stage",
            "boundary_count",
            "unique_cutpoint_count",
            "inside_word_count",
            "inside_word_rate",
            "inside_phone_count",
            "inside_phone_rate",
            "guard_20ms_violation_count",
            "guard_20ms_violation_rate",
            "guard_50ms_violation_count",
            "guard_50ms_violation_rate",
            "guard_100ms_violation_count",
            "guard_100ms_violation_rate",
            "final_stage_available",
        ],
    )

    disagreement_outputs = _build_disagreement_audits(
        output_root=output_root,
        current_eval_rows=current_eval_rows,
        safe_regions=safe_regions,
        detection_rows=detection_rows,
        detector_candidates=detector_candidates,
        reference_safe_region_vad_rows=reference_safe_region_vad_rows,
        rejected_cutpoints=rejected_cutpoints,
        buffer_by_id=buffer_by_id,
        safe_regions_by_recording=safe_regions_by_recording,
        vad_frame_index_by_recording=vad_frame_index_by_recording,
        speech_phones_by_recording=speech_phones_by_recording,
        sources=sources,
    )
    listening_audit_rows = _build_listening_audit(
        output_root=output_root,
        current_phone_overlap_rows=current_phone_overlap_rows,
        current_eval_rows=current_eval_rows,
        candidate_review_manifest=candidate_review_manifest,
        sources=sources,
    )
    write_csv(
        tables_dir / "LISTENING_AUDIT_INDEX.csv",
        listening_audit_rows,
        fieldnames=[
            "audit_type",
            "recording_id",
            "cutpoint_id",
            "cut_time_sec",
            "snippet_path",
            "reference_phone_label",
            "reference_word_label",
            "predicted_transcript_context",
            "used_in_candidate_clip",
            "candidate_clip_ids",
        ],
    )

    review_md = _write_review_me_first(
        output_root=output_root,
        current_eval_rows=current_eval_rows,
        detector_rows=detector_rows,
        oracle_rows=oracle_rows,
        detection_rows=detection_rows,
    )
    corrected_review_md = _write_review_me_first_corrected(
        output_root=output_root,
        current_eval_rows=current_eval_rows,
        corrected_detector_rows=corrected_detector_rows,
        corrected_oracle_rows=corrected_oracle_rows,
        corrected_detection_rows=corrected_detection_rows,
        current_phone_overlap_rows=current_phone_overlap_rows,
        boundary_stage_rows=boundary_stage_rows,
    )
    report_md = _write_full_report(
        output_root=output_root,
        malformed_rows=malformed_rows,
        runtime_versions=runtime_versions,
        config=config,
        speaker_selection=speaker_selection,
        current_eval_rows=current_eval_rows,
        detector_rows=detector_rows,
        oracle_rows=oracle_rows,
        alignment_failure_rows=alignment_failure_rows,
        detection_rows=detection_rows,
        disagreement_outputs=disagreement_outputs,
    )
    corrected_report_md = _write_full_report_corrected(
        output_root=output_root,
        corrected_detector_rows=corrected_detector_rows,
        corrected_oracle_rows=corrected_oracle_rows,
        corrected_detection_rows=corrected_detection_rows,
        current_phone_overlap_rows=current_phone_overlap_rows,
        boundary_stage_rows=boundary_stage_rows,
        disagreement_outputs=disagreement_outputs,
    )
    write_json(
        metrics_dir / "buckeye_benchmark_summary.json",
        {
            "review_me_first": str(review_md),
            "report": str(report_md),
            "review_me_first_corrected": str(corrected_review_md),
            "report_corrected": str(corrected_report_md),
            "tables": {
                "timestamp_mapping_crosscheck": str(tables_dir / "timestamp_mapping_crosscheck.csv"),
                "alignment_failure_crosscheck": str(tables_dir / "alignment_failure_crosscheck.csv"),
                "current_safecut_reference_eval": str(tables_dir / "current_safecut_reference_eval.csv"),
                "reference_safe_regions": str(tables_dir / "reference_safe_regions.csv"),
                "reference_safe_region_detection": str(tables_dir / "reference_safe_region_detection.csv"),
                "reference_safe_region_vad_analysis": str(tables_dir / "reference_safe_region_vad_analysis.csv"),
                "detector_comparison": str(tables_dir / "detector_comparison.csv"),
                "oracle_yield_comparison": str(tables_dir / "oracle_yield_comparison.csv"),
                "reference_safe_regions_corrected": str(tables_dir / "reference_safe_regions_corrected.csv"),
                "safe_region_policy_summary": str(tables_dir / "safe_region_policy_summary.csv"),
                "reference_safe_region_detection_corrected": str(tables_dir / "reference_safe_region_detection_corrected.csv"),
                "detector_comparison_corrected": str(tables_dir / "detector_comparison_corrected.csv"),
                "oracle_yield_comparison_corrected": str(tables_dir / "oracle_yield_comparison_corrected.csv"),
                "current_phone_overlap_severity": str(tables_dir / "current_phone_overlap_severity.csv"),
                "boundary_safety_by_pipeline_stage": str(tables_dir / "boundary_safety_by_pipeline_stage.csv"),
                "listening_audit_index": str(tables_dir / "LISTENING_AUDIT_INDEX.csv"),
            },
        },
    )
    return output_root


def _read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _read_csv(path: Path) -> list[dict[str, Any]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _group_by(rows: list[dict[str, Any]], key: str) -> dict[str, list[dict[str, Any]]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[str(row[key])].append(row)
    return grouped


def _load_sources(path: Path) -> dict[str, SourceInfo]:
    manifest = _read_json(path)
    sources: dict[str, SourceInfo] = {}
    for row in manifest["sources"]:
        source = SourceInfo(
            source_audio_id=str(row["source_audio_id"]),
            recording_id=str(row["source_recording_id"]),
            path=Path(str(row["path"])),
            duration_sec=float(row["duration_sec"]),
            sample_rate=int(row["sample_rate"]),
            num_samples=int(row["num_samples"]),
        )
        sources[source.source_audio_id] = source
    return sources


def _as_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() == "true"


def _as_float(value: Any) -> float:
    return float(value)


def _strictly_inside(interval: dict[str, Any], time_sec: float) -> bool:
    return _as_float(interval["start_sec"]) < time_sec < _as_float(interval["end_sec"])


def _filter_overlapping(rows: list[dict[str, Any]], start_sec: float, end_sec: float) -> list[dict[str, Any]]:
    return [
        row
        for row in rows
        if overlap_duration(_as_float(row["start_sec"]), _as_float(row["end_sec"]), start_sec, end_sec) > EPSILON_SEC
    ]


def _intersection_duration_rows(rows: list[dict[str, Any]], start_sec: float, end_sec: float) -> float:
    intervals = [(_as_float(row["start_sec"]), _as_float(row["end_sec"])) for row in _filter_overlapping(rows, start_sec, end_sec)]
    return sum(overlap_duration(s, e, start_sec, end_sec) for s, e in merge_intervals(intervals))


def _build_timestamp_mapping_crosscheck(
    *,
    buffer_by_id: dict[str, dict[str, Any]],
    words_by_buffer: dict[str, list[dict[str, Any]]],
    current_cuts_by_buffer: dict[str, list[dict[str, Any]]],
    candidate_review_manifest: list[dict[str, Any]],
    sources: dict[str, SourceInfo],
) -> list[dict[str, Any]]:
    clips_by_buffer = _group_by(candidate_review_manifest, "buffer_id")
    rows: list[dict[str, Any]] = []
    for buffer_id, buffer in sorted(buffer_by_id.items()):
        source = sources[str(buffer["source_audio_id"])]
        errors: list[str] = []
        local_start = 0.0
        local_end = float(buffer["duration_sec"])
        source_start = float(buffer["source_start_sec"])
        source_end = float(buffer["source_end_sec"])
        if source_start < -EPSILON_SEC or source_end > source.duration_sec + EPSILON_SEC:
            errors.append("buffer_outside_source_duration")
        expected_duration = source_end - source_start
        if abs(expected_duration - local_end) > 0.01:
            errors.append("buffer_duration_mismatch")
        for word in words_by_buffer.get(buffer_id, []):
            source_word_start = float(word["source_start_sec"])
            local_word_start = float(word["local_start_sec"])
            expected_source_word_start = source_start + local_word_start
            if abs(source_word_start - expected_source_word_start) > 0.01:
                errors.append("aligned_word_local_source_mismatch")
                break
        for cut in current_cuts_by_buffer.get(buffer_id, []):
            if cut.get("source_sample") is None:
                errors.append("accepted_cut_missing_source_sample")
                break
            cut_source_sec = int(cut["source_sample"]) / source.sample_rate
            expected_cut_sec = source_start + (int(cut["cut_local_sample"]) / source.sample_rate)
            if abs(cut_source_sec - expected_cut_sec) > 0.01:
                errors.append("cut_local_source_mismatch")
                break
        for clip in clips_by_buffer.get(buffer_id, []):
            expected_clip_start = source_start + (int(clip["buffer_local_start_sample"]) / source.sample_rate)
            expected_clip_end = source_start + (int(clip["buffer_local_end_sample"]) / source.sample_rate)
            actual_start = int(clip["source_start_sample"]) / source.sample_rate
            actual_end = int(clip["source_end_sample"]) / source.sample_rate
            if abs(expected_clip_start - actual_start) > 0.01 or abs(expected_clip_end - actual_end) > 0.01:
                errors.append("clip_local_source_mismatch")
                break
        rows.append(
            {
                "speaker_id": source.recording_id[:3],
                "recording_id": source.recording_id,
                "buffer_id": buffer_id,
                "buffer_local_start_sec": local_start,
                "buffer_local_end_sec": local_end,
                "source_start_sec": source_start,
                "source_end_sec": source_end,
                "mapping_valid": not errors,
                "error_reason": ";".join(sorted(set(errors))),
            }
        )
    return rows


def _build_alignment_failure_crosscheck(
    *,
    buffer_by_id: dict[str, dict[str, Any]],
    transcript_by_buffer: dict[str, dict[str, Any]],
    normalized_by_buffer: dict[str, dict[str, Any]],
    qc_by_buffer: dict[str, dict[str, Any]],
    words_by_buffer: dict[str, list[dict[str, Any]]],
    reference_words_by_recording: dict[str, list[dict[str, Any]]],
    reference_phones_by_recording: dict[str, list[dict[str, Any]]],
    eval_run: Path,
    sources: dict[str, SourceInfo],
) -> list[dict[str, Any]]:
    mfa_output_dir = eval_run / "speechcraft_run" / "artifacts" / "mfa_output"
    rows: list[dict[str, Any]] = []
    for buffer_id, buffer in sorted(buffer_by_id.items()):
        source = sources[str(buffer["source_audio_id"])]
        start_sec = float(buffer["source_start_sec"])
        end_sec = float(buffer["source_end_sec"])
        transcript = transcript_by_buffer.get(buffer_id, {})
        normalized = normalized_by_buffer.get(buffer_id, {})
        qc = qc_by_buffer.get(buffer_id, {})
        aligned = words_by_buffer.get(buffer_id, [])
        textgrid_exists = (mfa_output_dir / f"{buffer_id}.TextGrid").exists()
        ref_lex_words = _filter_overlapping(reference_words_by_recording[source.recording_id], start_sec, end_sec)
        ref_speech_phones = _filter_overlapping(reference_phones_by_recording[source.recording_id], start_sec, end_sec)
        fatal_reason_codes = list(qc.get("fatal_reason_codes") or [])
        normalized_token_count = len(normalized.get("alignment_tokens") or [])
        aligned_word_count = len(aligned)
        mfa_word_count = int(qc.get("aligned_word_count") or aligned_word_count)
        failure_class = _classify_alignment_failure(
            textgrid_exists=textgrid_exists,
            fatal_reason_codes=fatal_reason_codes,
            normalized_token_count=normalized_token_count,
            aligned_word_count=aligned_word_count,
            ref_lexical_word_count=len(ref_lex_words),
            ref_speech_phone_duration_sec=_intersection_duration_rows(ref_speech_phones, start_sec, end_sec),
        )
        rows.append(
            {
                "recording_id": source.recording_id,
                "buffer_id": buffer_id,
                "source_start_sec": start_sec,
                "source_end_sec": end_sec,
                "asr_transcript": str(transcript.get("text") or ""),
                "normalized_token_count": normalized_token_count,
                "mfa_textgrid_exists": textgrid_exists,
                "mfa_word_count": mfa_word_count,
                "parsed_aligned_word_count": aligned_word_count,
                "fatal_reason_codes": fatal_reason_codes,
                "buckeye_reference_lexical_word_count": len(ref_lex_words),
                "buckeye_reference_speech_phone_duration_sec": round(_intersection_duration_rows(ref_speech_phones, start_sec, end_sec), 6),
                "likely_failure_class": failure_class,
            }
        )
    return rows


def _classify_alignment_failure(
    *,
    textgrid_exists: bool,
    fatal_reason_codes: list[str],
    normalized_token_count: int,
    aligned_word_count: int,
    ref_lexical_word_count: int,
    ref_speech_phone_duration_sec: float,
) -> str:
    fatal = set(fatal_reason_codes)
    if not textgrid_exists:
        return "MFA produced no words"
    if aligned_word_count == 0 and normalized_token_count == 0:
        return "ASR transcript omission"
    if aligned_word_count == 0 and ref_lexical_word_count == 0 and ref_speech_phone_duration_sec < 0.25:
        return "interviewer/non-target material"
    if aligned_word_count == 0:
        return "transcript/audio mismatch"
    if "alignment_token_word_mismatch" in fatal or "alignment_token_count_mismatch" in fatal:
        return "transcript/audio mismatch"
    if fatal:
        return "alignment-QC threshold failure"
    return "unknown"


def _build_reference_safe_regions(
    reference_words_by_recording: dict[str, list[dict[str, Any]]],
    reference_phones_by_recording: dict[str, list[dict[str, Any]]],
) -> list[dict[str, Any]]:
    safe_regions: list[dict[str, Any]] = []
    for recording_id, phone_rows in sorted(reference_phones_by_recording.items()):
        lexical_words = reference_words_by_recording.get(recording_id, [])
        pending: dict[str, Any] | None = None
        previous_speech_phone: dict[str, Any] | None = None
        for row in phone_rows:
            is_speech = _as_bool(row["is_speech_phone"])
            label = str(row["raw_label"])
            if is_speech:
                if pending is not None:
                    pending["next_phone"] = label
                    pending["next_word"] = _first_lexical_starting_after(lexical_words, float(pending["end_sec"])) or ""
                    safe_regions.append(_finalize_safe_region(pending))
                    pending = None
                previous_speech_phone = row
                continue
            region_type = classify_phone_event_type(label) or "unknown_event"
            if pending and pending["region_type"] == region_type and abs(float(pending["end_sec"]) - _as_float(row["start_sec"])) <= EPSILON_SEC:
                pending["end_sec"] = _as_float(row["end_sec"])
            else:
                if pending is not None:
                    pending["next_phone"] = label if is_speech else ""
                    pending["next_word"] = _first_lexical_starting_after(lexical_words, float(pending["end_sec"])) or ""
                    safe_regions.append(_finalize_safe_region(pending))
                pending = {
                    "speaker_id": str(row["speaker_id"]),
                    "recording_id": recording_id,
                    "safe_region_id": "",
                    "start_sec": _as_float(row["start_sec"]),
                    "end_sec": _as_float(row["end_sec"]),
                    "region_type": region_type,
                    "previous_word": _last_lexical_ending_before(lexical_words, _as_float(row["start_sec"])) or "",
                    "next_word": "",
                    "previous_phone": "" if previous_speech_phone is None else str(previous_speech_phone["normalized_label"]),
                    "next_phone": "",
                }
        if pending is not None:
            pending["next_word"] = ""
            pending["next_phone"] = ""
            safe_regions.append(_finalize_safe_region(pending))

    for index, row in enumerate(safe_regions):
        row["safe_region_id"] = f"{row['recording_id']}-safe-{index:05d}"
    return safe_regions


def _finalize_safe_region(row: dict[str, Any]) -> dict[str, Any]:
    duration_ms = round((float(row["end_sec"]) - float(row["start_sec"])) * 1000.0, 3)
    policy_flags = _policy_flags(str(row["region_type"]))
    return {
        **row,
        "duration_ms": duration_ms,
        "eligible_at_20ms": duration_ms >= 20.0,
        "eligible_at_40ms": duration_ms >= 40.0,
        "eligible_at_60ms": duration_ms >= 60.0,
        "eligible_at_80ms": duration_ms >= 80.0,
        "eligible_at_100ms": duration_ms >= 100.0,
        "exclusion_reason": "" if duration_ms >= 20.0 else "duration_below_20ms",
        "strict_eligible": policy_flags["strict"],
        "moderate_eligible": policy_flags["moderate"],
        "permissive_eligible": policy_flags["permissive"],
        "policy_category": _policy_category(str(row["region_type"])),
    }


def _policy_flags(region_type: str) -> dict[str, bool]:
    region_type = str(region_type)
    strict = region_type in STRICT_SAFE_TYPES
    moderate = strict or region_type in MODERATE_EXTRA_TYPES
    permissive = moderate or region_type in PERMISSIVE_EXTRA_TYPES
    return {"strict": strict, "moderate": moderate, "permissive": permissive}


def _policy_category(region_type: str) -> str:
    flags = _policy_flags(region_type)
    if flags["strict"]:
        return "definitely_eligible"
    if flags["moderate"] or flags["permissive"]:
        return "separate_policy_category"
    return "definitely_ineligible"


def _last_lexical_ending_before(words: list[dict[str, Any]], time_sec: float) -> str | None:
    best: dict[str, Any] | None = None
    for row in words:
        if _as_float(row["end_sec"]) <= time_sec + EPSILON_SEC:
            best = row
        else:
            break
    return None if best is None else str(best["normalized_label"])


def _first_lexical_starting_after(words: list[dict[str, Any]], time_sec: float) -> str | None:
    for row in words:
        if _as_float(row["start_sec"]) >= time_sec - EPSILON_SEC:
            return str(row["normalized_label"])
    return None


def _vad_frame_geometry_from_env() -> tuple[str, int, int, tuple[int, ...]]:
    backend = os.environ.get("SPEAKER_TS_EVAL_VAD_BACKEND", "torch_current").strip() or "torch_current"
    window_samples = int(os.environ.get("SPEAKER_TS_EVAL_VAD_WINDOW_SAMPLES", str(VAD_WINDOW_SAMPLES)))
    hop_samples = int(os.environ.get("SPEAKER_TS_EVAL_VAD_HOP_SAMPLES", str(VAD_HOP_SAMPLES)))
    offsets_text = os.environ.get("SPEAKER_TS_EVAL_VAD_OFFSETS", ",".join(str(value) for value in VAD_OFFSETS))
    offsets = tuple(int(value.strip()) for value in offsets_text.split(",") if value.strip())
    if backend not in {"torch_current", "silero_official_onnx"}:
        raise ValueError(f"unsupported VAD backend: {backend}")
    if window_samples <= 0 or hop_samples <= 0:
        raise ValueError("VAD window and hop samples must be positive")
    if not offsets:
        raise ValueError("at least one VAD offset is required")
    if any(offset < 0 or offset >= hop_samples for offset in offsets):
        raise ValueError(f"VAD offsets must satisfy 0 <= offset < hop_samples: {offsets}")
    return backend, window_samples, hop_samples, offsets


def _compute_recording_vad_frames(
    sources: dict[str, SourceInfo],
    cache_dir: Path,
) -> dict[str, list[dict[str, Any]]]:
    import numpy as np
    import soundfile as sf
    import torch
    from silero_vad import load_silero_vad

    backend, window_samples, hop_samples, offsets = _vad_frame_geometry_from_env()
    cache_dir.mkdir(parents=True, exist_ok=True)
    model = load_silero_vad(onnx=(backend == "silero_official_onnx"))
    results: dict[str, list[dict[str, Any]]] = {}
    try:
        for source in sources.values():
            offset_slug = "-".join(str(offset) for offset in offsets)
            cache_path = cache_dir / f"{source.recording_id}_{backend}_w{window_samples}_h{hop_samples}_o{offset_slug}.json"
            if cache_path.exists():
                results[source.recording_id] = _read_json(cache_path)
                continue
            samples, sample_rate = sf.read(str(source.path), dtype="float32", always_2d=False)
            if int(sample_rate) != source.sample_rate:
                raise ValueError(f"sample-rate mismatch for {source.path}: {sample_rate} != {source.sample_rate}")
            audio = np.asarray(samples, dtype=np.float32)
            rows: list[dict[str, Any]] = []
            for offset in offsets:
                model.reset_states()
                for start in range(offset, len(audio), hop_samples):
                    chunk = audio[start : start + window_samples]
                    if len(chunk) < window_samples:
                        chunk = np.pad(chunk, (0, window_samples - len(chunk)))
                    prob = float(model(torch.from_numpy(chunk), source.sample_rate).item())
                    center = start + (window_samples // 2)
                    rows.append(
                        {
                            "window_start_sec": round(start / source.sample_rate, 6),
                            "window_end_sec": round((start + window_samples) / source.sample_rate, 6),
                            "center_sec": round(center / source.sample_rate, 6),
                            "offset_samples": offset,
                            "speech_prob": prob,
                            "vad_backend": backend,
                            "vad_window_samples": window_samples,
                            "vad_hop_samples": hop_samples,
                        }
                    )
            rows.sort(key=lambda row: (row["center_sec"], row["offset_samples"]))
            write_json(cache_path, rows)
            results[source.recording_id] = rows
        return results
    finally:
        try:
            import torch

            del model
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        except Exception:
            pass


def _index_frames(frames: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "frames": frames,
        "centers": [float(row["center_sec"]) for row in frames],
    }


def _slice_indexed_frames(frame_index: dict[str, Any], start_sec: float, end_sec: float) -> list[dict[str, Any]]:
    frames = frame_index["frames"]
    centers = frame_index["centers"]
    left = bisect_left(centers, start_sec - 0.05)
    right = bisect_right(centers, end_sec + 0.05)
    return [
        row
        for row in frames[left:right]
        if overlap_duration(float(row["window_start_sec"]), float(row["window_end_sec"]), start_sec, end_sec) > EPSILON_SEC
    ]


def _frame_stats(frame_index: dict[str, Any], start_sec: float, end_sec: float) -> dict[str, Any]:
    relevant = _slice_indexed_frames(frame_index, start_sec, end_sec)
    if not relevant:
        return {
            "min_vad_prob": None,
            "mean_vad_prob": None,
            "median_vad_prob": None,
            "p10_vad_prob": None,
            "fraction_below_0_1": None,
            "fraction_below_0_2": None,
            "longest_continuous_run_below_0_1_ms": 0.0,
            "longest_continuous_run_below_0_2_ms": 0.0,
            "rms_min_dbfs": None,
            "rms_mean_dbfs": None,
        }
    probs = [float(row["speech_prob"]) for row in relevant]
    return {
        "min_vad_prob": min(probs),
        "mean_vad_prob": statistics.fmean(probs),
        "median_vad_prob": statistics.median(probs),
        "p10_vad_prob": _percentile(probs, 10),
        "fraction_below_0_1": sum(prob < 0.1 for prob in probs) / len(probs),
        "fraction_below_0_2": sum(prob < 0.2 for prob in probs) / len(probs),
        "longest_continuous_run_below_0_1_ms": _longest_low_prob_run_ms(relevant, threshold=0.1),
        "longest_continuous_run_below_0_2_ms": _longest_low_prob_run_ms(relevant, threshold=0.2),
        "rms_min_dbfs": None,
        "rms_mean_dbfs": None,
    }


def _percentile(values: list[float], q: float) -> float | None:
    if not values:
        return None
    values = sorted(values)
    if len(values) == 1:
        return values[0]
    rank = (len(values) - 1) * (q / 100.0)
    lo = math.floor(rank)
    hi = math.ceil(rank)
    if lo == hi:
        return values[lo]
    return values[lo] + (values[hi] - values[lo]) * (rank - lo)


def _longest_low_prob_run_ms(frames: list[dict[str, Any]], *, threshold: float) -> float:
    low_intervals = [
        (float(row["window_start_sec"]), float(row["window_end_sec"]))
        for row in frames
        if float(row["speech_prob"]) < threshold
    ]
    if not low_intervals:
        return 0.0
    merged = merge_intervals(low_intervals, epsilon_sec=0.0)
    return max((end - start) * 1000.0 for start, end in merged)


def _build_current_safecut_reference_eval(
    *,
    current_cuts: list[dict[str, Any]],
    words_by_buffer: dict[str, list[dict[str, Any]]],
    buffer_by_id: dict[str, dict[str, Any]],
    sources: dict[str, SourceInfo],
    lexical_words_by_recording: dict[str, list[dict[str, Any]]],
    speech_phones_by_recording: dict[str, list[dict[str, Any]]],
    safe_regions_by_recording: dict[str, list[dict[str, Any]]],
    eval_run: Path,
) -> list[dict[str, Any]]:
    vad_frame_index_by_recording = {
        recording_id: _index_frames(frames)
        for recording_id, frames in _compute_recording_vad_frames(sources, eval_run / "metrics" / "vad_frame_cache").items()
    }
    rows: list[dict[str, Any]] = []
    for cut in current_cuts:
        buffer = buffer_by_id[str(cut["buffer_id"])]
        source = sources[str(buffer["source_audio_id"])]
        cut_time_sec = int(cut["source_sample"]) / source.sample_rate
        lexical_words = lexical_words_by_recording[source.recording_id]
        speech_phones = speech_phones_by_recording[source.recording_id]
        overlapping_word = _find_strict_interval(lexical_words, cut_time_sec)
        overlapping_phone = _find_strict_interval(speech_phones, cut_time_sec)
        prev_word = _last_interval_before(lexical_words, cut_time_sec)
        next_word = _first_interval_after(lexical_words, cut_time_sec)
        prev_phone = _last_interval_before(speech_phones, cut_time_sec)
        next_phone = _first_interval_after(speech_phones, cut_time_sec)
        clearance_prev_ms, clearance_next_ms, nearest_ms = _phone_clearances_ms(
            cut_time_sec,
            overlapping_phone=overlapping_phone,
            prev_phone=prev_phone,
            next_phone=next_phone,
        )
        safe_region = _find_strict_interval(safe_regions_by_recording[source.recording_id], cut_time_sec)
        vad_stats = _frame_stats(vad_frame_index_by_recording[source.recording_id], cut_time_sec - 0.05, cut_time_sec + 0.05)
        left_word = _find_aligned_word(words_by_buffer.get(str(cut["buffer_id"]), []), str(cut["left_word_id"]))
        right_word = _find_aligned_word(words_by_buffer.get(str(cut["buffer_id"]), []), str(cut["right_word_id"]))
        rows.append(
            {
                "speaker_id": source.recording_id[:3],
                "recording_id": source.recording_id,
                "buffer_id": cut["buffer_id"],
                "cutpoint_id": cut["id"],
                "cut_time_sec": round(cut_time_sec, 6),
                "left_aligned_word": "" if left_word is None else left_word["word"],
                "right_aligned_word": "" if right_word is None else right_word["word"],
                "production_gap_duration_ms": round(float(cut["gap_duration_sec"]) * 1000.0, 3),
                "production_valley_dbfs": cut["valley_dbfs"],
                "production_noise_floor_dbfs": cut["noise_floor_dbfs"],
                "inside_reference_word": overlapping_word is not None,
                "inside_reference_phone": overlapping_phone is not None,
                "overlapping_reference_word": "" if overlapping_word is None else overlapping_word["normalized_label"],
                "overlapping_reference_phone": "" if overlapping_phone is None else overlapping_phone["normalized_label"],
                "overlapping_reference_phone_start_sec": "" if overlapping_phone is None else overlapping_phone["start_sec"],
                "overlapping_reference_phone_end_sec": "" if overlapping_phone is None else overlapping_phone["end_sec"],
                "previous_reference_word": "" if prev_word is None else prev_word["normalized_label"],
                "next_reference_word": "" if next_word is None else next_word["normalized_label"],
                "previous_reference_phone": "" if prev_phone is None else prev_phone["normalized_label"],
                "next_reference_phone": "" if next_phone is None else next_phone["normalized_label"],
                "previous_phone_end_sec": "" if prev_phone is None else prev_phone["end_sec"],
                "next_phone_start_sec": "" if next_phone is None else next_phone["start_sec"],
                "clearance_after_previous_phone_ms": clearance_prev_ms,
                "clearance_before_next_phone_ms": clearance_next_ms,
                "nearest_reference_phone_distance_ms": nearest_ms,
                "unsafe_at_0ms_guard": overlapping_phone is not None,
                "unsafe_at_20ms_guard": overlapping_phone is not None or nearest_ms < 20.0,
                "unsafe_at_50ms_guard": overlapping_phone is not None or nearest_ms < 50.0,
                "unsafe_at_100ms_guard": overlapping_phone is not None or nearest_ms < 100.0,
                "reference_safe_region_id": "" if safe_region is None else safe_region["safe_region_id"],
                "frame_vad_min": vad_stats["min_vad_prob"],
                "frame_vad_mean": vad_stats["mean_vad_prob"],
                "longest_vad_run_below_0_1_ms": vad_stats["longest_continuous_run_below_0_1_ms"],
                "longest_vad_run_below_0_2_ms": vad_stats["longest_continuous_run_below_0_2_ms"],
            }
        )
    return rows


def _find_aligned_word(words: list[dict[str, Any]], word_id: str) -> dict[str, Any] | None:
    for word in words:
        if str(word["id"]) == word_id:
            return word
    return None


def _find_strict_interval(rows: list[dict[str, Any]], time_sec: float) -> dict[str, Any] | None:
    for row in rows:
        if _as_float(row["start_sec"]) < time_sec < _as_float(row["end_sec"]):
            return row
    return None


def _last_interval_before(rows: list[dict[str, Any]], time_sec: float) -> dict[str, Any] | None:
    candidate = None
    for row in rows:
        if _as_float(row["end_sec"]) <= time_sec + EPSILON_SEC:
            candidate = row
        else:
            break
    return candidate


def _first_interval_after(rows: list[dict[str, Any]], time_sec: float) -> dict[str, Any] | None:
    for row in rows:
        if _as_float(row["start_sec"]) >= time_sec - EPSILON_SEC:
            return row
    return None


def _phone_clearances_ms(
    time_sec: float,
    *,
    overlapping_phone: dict[str, Any] | None,
    prev_phone: dict[str, Any] | None,
    next_phone: dict[str, Any] | None,
) -> tuple[float, float, float]:
    if overlapping_phone is not None:
        start = _as_float(overlapping_phone["start_sec"])
        end = _as_float(overlapping_phone["end_sec"])
        severity_ms = -min((time_sec - start) * 1000.0, (end - time_sec) * 1000.0)
        return 0.0, 0.0, severity_ms
    prev_clearance = math.inf if prev_phone is None else max(0.0, (time_sec - _as_float(prev_phone["end_sec"])) * 1000.0)
    next_clearance = math.inf if next_phone is None else max(0.0, (_as_float(next_phone["start_sec"]) - time_sec) * 1000.0)
    nearest = min(prev_clearance, next_clearance)
    return prev_clearance, next_clearance, nearest


def _build_reference_safe_region_vad_analysis(
    *,
    safe_regions: list[dict[str, Any]],
    vad_frame_index_by_recording: dict[str, dict[str, Any]],
    current_eval_rows: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    current_cuts_by_recording: dict[str, list[float]] = defaultdict(list)
    for row in current_eval_rows:
        current_cuts_by_recording[str(row["recording_id"])].append(float(row["cut_time_sec"]))
    return_rows: list[dict[str, Any]] = []
    for region in safe_regions:
        recording_id = str(region["recording_id"])
        stats = _frame_stats(vad_frame_index_by_recording[recording_id], float(region["start_sec"]), float(region["end_sec"]))
        detected_by_current = any(
            float(region["start_sec"]) < cut_time < float(region["end_sec"])
            for cut_time in current_cuts_by_recording.get(recording_id, [])
        )
        return_rows.append(
            {
                "speaker_id": region["speaker_id"],
                "recording_id": recording_id,
                "safe_region_id": region["safe_region_id"],
                "region_type": region["region_type"],
                "duration_ms": region["duration_ms"],
                "min_vad_prob": stats["min_vad_prob"],
                "mean_vad_prob": stats["mean_vad_prob"],
                "median_vad_prob": stats["median_vad_prob"],
                "p10_vad_prob": stats["p10_vad_prob"],
                "fraction_below_0_1": stats["fraction_below_0_1"],
                "fraction_below_0_2": stats["fraction_below_0_2"],
                "longest_continuous_run_below_0_1_ms": stats["longest_continuous_run_below_0_1_ms"],
                "longest_continuous_run_below_0_2_ms": stats["longest_continuous_run_below_0_2_ms"],
                "rms_min_dbfs": stats["rms_min_dbfs"],
                "rms_mean_dbfs": stats["rms_mean_dbfs"],
                "detected_by_current": detected_by_current,
            }
        )
    return return_rows


def _build_detector_candidates(
    *,
    buffer_by_id: dict[str, dict[str, Any]],
    words_by_buffer: dict[str, list[dict[str, Any]]],
    current_cuts_by_buffer: dict[str, list[dict[str, Any]]],
    rejected_cuts_by_buffer: dict[str, list[dict[str, Any]]],
    sources: dict[str, SourceInfo],
    vad_frame_index_by_recording: dict[str, dict[str, Any]],
    config: dict[str, Any],
) -> dict[str, list[dict[str, Any]]]:
    detectors: dict[str, list[dict[str, Any]]] = defaultdict(list)
    left_guard_sec = float(config.get("cutpoint_left_word_edge_guard_ms", 30)) / 1000.0
    right_guard_sec = float(config.get("cutpoint_right_word_edge_guard_ms", 30)) / 1000.0
    min_gap_sec = float(config.get("cutpoint_min_gap_ms", 80)) / 1000.0
    for buffer_id, buffer in sorted(buffer_by_id.items()):
        source = sources[str(buffer["source_audio_id"])]
        recording_id = source.recording_id
        current_rows = [
            {
                "detector": "current",
                "recording_id": recording_id,
                "buffer_id": buffer_id,
                "cut_id": str(row["id"]),
                "cut_time_sec": int(row["source_sample"]) / source.sample_rate,
                "is_buffer_edge_candidate": False,
            }
            for row in current_cuts_by_buffer.get(buffer_id, [])
            if row.get("source_sample") is not None
        ]
        detectors["current"].extend(current_rows)
        words = sorted(words_by_buffer.get(buffer_id, []), key=lambda row: float(row["source_start_sec"]))
        if not words:
            continue
        frames = _slice_indexed_frames(vad_frame_index_by_recording[recording_id], float(buffer["trusted_start_sec"]), float(buffer["trusted_end_sec"]))
        if not frames:
            continue
        internal_vad = _detect_vad_valley_candidates(
            buffer=buffer,
            recording_id=recording_id,
            words=words,
            frames=frames,
            left_guard_sec=left_guard_sec,
            right_guard_sec=right_guard_sec,
            threshold=DEFAULT_VAD_THRESHOLD,
            min_run_ms=DEFAULT_VAD_MIN_RUN_MS,
            include_edges=False,
            detector_name="vad",
        )
        edge_vad = _detect_vad_valley_candidates(
            buffer=buffer,
            recording_id=recording_id,
            words=words,
            frames=frames,
            left_guard_sec=left_guard_sec,
            right_guard_sec=right_guard_sec,
            threshold=DEFAULT_VAD_THRESHOLD,
            min_run_ms=DEFAULT_VAD_MIN_RUN_MS,
            include_edges=True,
            detector_name="edge",
        )
        hybrid = _detect_word_gap_acoustic_first_candidates(
            buffer=buffer,
            recording_id=recording_id,
            words=words,
            frames=frames,
            left_guard_sec=left_guard_sec,
            right_guard_sec=right_guard_sec,
            min_gap_sec=min_gap_sec,
        )
        detectors["vad"].extend(internal_vad)
        detectors["word_gap_acoustic_first_hybrid"].extend(hybrid)
        detectors["current_plus_vad"].extend(_dedupe_candidates(current_rows + internal_vad))
        detectors["current_plus_vad_plus_edge"].extend(_dedupe_candidates(current_rows + internal_vad + edge_vad))
    return {key: _dedupe_candidates(rows) for key, rows in detectors.items()}


def _detect_vad_valley_candidates(
    *,
    buffer: dict[str, Any],
    recording_id: str,
    words: list[dict[str, Any]],
    frames: list[dict[str, Any]],
    left_guard_sec: float,
    right_guard_sec: float,
    threshold: float,
    min_run_ms: int,
    include_edges: bool,
    detector_name: str,
) -> list[dict[str, Any]]:
    regions: list[tuple[float, float, bool]] = []
    trusted_start = float(buffer["trusted_start_sec"])
    trusted_end = float(buffer["trusted_end_sec"])
    if include_edges:
        left_region_end = float(words[0]["source_start_sec"]) - left_guard_sec
        if left_region_end - trusted_start > (min_run_ms / 1000.0):
            regions.append((trusted_start, left_region_end, True))
    for left_word, right_word in zip(words, words[1:]):
        start = float(left_word["source_end_sec"]) + left_guard_sec
        end = float(right_word["source_start_sec"]) - right_guard_sec
        if end - start > (min_run_ms / 1000.0):
            regions.append((start, end, False))
    if include_edges:
        right_region_start = float(words[-1]["source_end_sec"]) + right_guard_sec
        if trusted_end - right_region_start > (min_run_ms / 1000.0):
            regions.append((right_region_start, trusted_end, True))
    candidates: list[dict[str, Any]] = []
    for region_start, region_end, is_edge in regions:
        region_frames = [row for row in frames if float(row["center_sec"]) >= region_start and float(row["center_sec"]) <= region_end]
        if not region_frames:
            continue
        low_frames = [row for row in region_frames if float(row["speech_prob"]) < threshold]
        if not low_frames:
            continue
        run_intervals = merge_intervals(
            [(float(row["window_start_sec"]), float(row["window_end_sec"])) for row in low_frames],
            epsilon_sec=0.0,
        )
        for run_index, (run_start, run_end) in enumerate(run_intervals):
            run_duration_ms = (run_end - run_start) * 1000.0
            if run_duration_ms < min_run_ms:
                continue
            run_frames = [
                row
                for row in region_frames
                if overlap_duration(float(row["window_start_sec"]), float(row["window_end_sec"]), run_start, run_end) > EPSILON_SEC
            ]
            valley = min(run_frames, key=lambda row: (float(row["speech_prob"]), abs(float(row["center_sec"]) - ((run_start + run_end) / 2.0))))
            candidates.append(
                {
                    "detector": detector_name,
                    "recording_id": recording_id,
                    "buffer_id": str(buffer["buffer_id"]),
                    "cut_id": f"{buffer['buffer_id']}-{detector_name}-{run_index:04d}-{int(round(float(valley['center_sec']) * 1000.0))}",
                    "cut_time_sec": float(valley["center_sec"]),
                    "is_buffer_edge_candidate": is_edge,
                }
            )
    return candidates


def _detect_word_gap_acoustic_first_candidates(
    *,
    buffer: dict[str, Any],
    recording_id: str,
    words: list[dict[str, Any]],
    frames: list[dict[str, Any]],
    left_guard_sec: float,
    right_guard_sec: float,
    min_gap_sec: float,
) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    for index, (left_word, right_word) in enumerate(zip(words, words[1:])):
        start = float(left_word["source_end_sec"]) + left_guard_sec
        end = float(right_word["source_start_sec"]) - right_guard_sec
        if end - start < min_gap_sec:
            continue
        gap_frames = [row for row in frames if float(row["center_sec"]) >= start and float(row["center_sec"]) <= end]
        if not gap_frames:
            continue
        low_frames = [row for row in gap_frames if float(row["speech_prob"]) < DEFAULT_VAD_THRESHOLD]
        if not low_frames:
            continue
        low_runs = merge_intervals(
            [(float(row["window_start_sec"]), float(row["window_end_sec"])) for row in low_frames],
            epsilon_sec=0.0,
        )
        longest = max((end_sec - start_sec) * 1000.0 for start_sec, end_sec in low_runs)
        if longest < DEFAULT_VAD_MIN_RUN_MS:
            continue
        valley = min(gap_frames, key=lambda row: (float(row["speech_prob"]), abs(float(row["center_sec"]) - ((start + end) / 2.0))))
        candidates.append(
            {
                "detector": "word_gap_acoustic_first_hybrid",
                "recording_id": recording_id,
                "buffer_id": str(buffer["buffer_id"]),
                "cut_id": f"{buffer['buffer_id']}-hybrid-{index:04d}",
                "cut_time_sec": float(valley["center_sec"]),
                "is_buffer_edge_candidate": False,
            }
        )
    return candidates


def _dedupe_candidates(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_key: dict[tuple[str, str, int], dict[str, Any]] = {}
    for row in rows:
        key = (str(row["buffer_id"]), str(row.get("recording_id") or ""), int(round(float(row["cut_time_sec"]) * 1000.0)))
        if key not in by_key:
            by_key[key] = row
        else:
            by_key[key]["is_buffer_edge_candidate"] = bool(by_key[key].get("is_buffer_edge_candidate")) or bool(row.get("is_buffer_edge_candidate"))
    deduped = list(by_key.values())
    deduped.sort(key=lambda row: (str(row["buffer_id"]), float(row["cut_time_sec"]), str(row["cut_id"])))
    return deduped


def _build_reference_safe_region_detection(
    *,
    safe_regions: list[dict[str, Any]],
    detector_candidates: dict[str, list[dict[str, Any]]],
    buffer_by_id: dict[str, dict[str, Any]],
    qc_by_buffer: dict[str, dict[str, Any]],
    sources: dict[str, SourceInfo],
) -> list[dict[str, Any]]:
    buffer_ranges_by_recording: dict[str, list[tuple[float, float, bool]]] = defaultdict(list)
    for buffer in buffer_by_id.values():
        source = sources[str(buffer["source_audio_id"])]
        qc = qc_by_buffer.get(str(buffer["buffer_id"]), {})
        qc_disabled = bool(qc.get("automatic_cutpoints_disabled")) or bool(qc.get("fatal_reason_codes"))
        buffer_ranges_by_recording[source.recording_id].append(
            (float(buffer["source_start_sec"]), float(buffer["source_end_sec"]), qc_disabled)
        )
    rows: list[dict[str, Any]] = []
    detector_point_maps = {
        name: defaultdict(list)
        for name in [
            "current",
            "vad",
            "current_plus_vad",
            "current_plus_vad_plus_edge",
            "word_gap_acoustic_first_hybrid",
        ]
    }
    for detector_name, candidates in detector_candidates.items():
        for row in candidates:
            detector_point_maps[detector_name][str(row["recording_id"])].append(float(row["cut_time_sec"]))
    for region in safe_regions:
        recording_id = str(region["recording_id"])
        overlaps_any_buffer = any(
            overlap_duration(start_sec, end_sec, float(region["start_sec"]), float(region["end_sec"])) > EPSILON_SEC
            for start_sec, end_sec, _ in buffer_ranges_by_recording.get(recording_id, [])
        )
        overlaps_passing_buffer = any(
            overlap_duration(start_sec, end_sec, float(region["start_sec"]), float(region["end_sec"])) > EPSILON_SEC
            for start_sec, end_sec, qc_disabled in buffer_ranges_by_recording.get(recording_id, [])
            if not qc_disabled
        )
        row = {
            "speaker_id": region["speaker_id"],
            "recording_id": recording_id,
            "safe_region_id": region["safe_region_id"],
            "region_type": region["region_type"],
            "duration_ms": region["duration_ms"],
            "overlaps_any_buffer": overlaps_any_buffer,
            "overlaps_passing_buffer": overlaps_passing_buffer,
        }
        for detector_name, point_map in detector_point_maps.items():
            row[f"detected_by_{detector_name}"] = any(
                float(region["start_sec"]) < cut_time < float(region["end_sec"])
                for cut_time in point_map.get(recording_id, [])
            )
        rows.append(row)
    return rows


def _build_corrected_safe_regions(safe_regions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        {
            **row,
            "strict_eligible": _policy_flags(str(row["region_type"]))["strict"],
            "moderate_eligible": _policy_flags(str(row["region_type"]))["moderate"],
            "permissive_eligible": _policy_flags(str(row["region_type"]))["permissive"],
            "policy_category": _policy_category(str(row["region_type"])),
        }
        for row in safe_regions
    ]


def _build_safe_region_policy_summary(corrected_safe_regions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    grouped = {"all": corrected_safe_regions}
    grouped.update(_group_by(corrected_safe_regions, "recording_id"))
    for scope_id, scope_rows in grouped.items():
        scope_type = "aggregate" if scope_id == "all" else "recording"
        for policy in SAFE_REGION_POLICIES:
            eligible = [row for row in scope_rows if _as_bool(row[f"{policy}_eligible"])]
            rows.append(
                {
                    "scope_type": scope_type,
                    "scope_id": scope_id,
                    "policy": policy,
                    "total_regions": len(scope_rows),
                    "eligible_regions_20ms": sum(_as_bool(row["eligible_at_20ms"]) for row in eligible),
                    "eligible_regions_40ms": sum(_as_bool(row["eligible_at_40ms"]) for row in eligible),
                    "eligible_regions_60ms": sum(_as_bool(row["eligible_at_60ms"]) for row in eligible),
                    "eligible_regions_80ms": sum(_as_bool(row["eligible_at_80ms"]) for row in eligible),
                    "eligible_regions_100ms": sum(_as_bool(row["eligible_at_100ms"]) for row in eligible),
                    "eligible_duration_sec_40ms": round(
                        sum(float(row["duration_ms"]) for row in eligible if _as_bool(row["eligible_at_40ms"])) / 1000.0,
                        6,
                    ),
                    "region_type_counts": dict(sorted(Counter(row["region_type"] for row in eligible).items())),
                }
            )
    return rows


def _build_reference_safe_region_detection_corrected(
    corrected_safe_regions: list[dict[str, Any]],
    detection_rows: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    detection_map = {(str(row["recording_id"]), str(row["safe_region_id"])): row for row in detection_rows}
    rows: list[dict[str, Any]] = []
    for region in corrected_safe_regions:
        detection = detection_map[(str(region["recording_id"]), str(region["safe_region_id"]))]
        rows.append(
            {
                "speaker_id": region["speaker_id"],
                "recording_id": region["recording_id"],
                "safe_region_id": region["safe_region_id"],
                "start_sec": region["start_sec"],
                "end_sec": region["end_sec"],
                "region_type": region["region_type"],
                "policy_category": region["policy_category"],
                "duration_ms": region["duration_ms"],
                "overlaps_any_buffer": detection["overlaps_any_buffer"],
                "overlaps_passing_buffer": detection["overlaps_passing_buffer"],
                "strict_eligible": region["strict_eligible"],
                "moderate_eligible": region["moderate_eligible"],
                "permissive_eligible": region["permissive_eligible"],
                "detected_by_current": detection["detected_by_current"],
                "detected_by_vad": detection["detected_by_vad"],
                "detected_by_current_plus_vad": detection["detected_by_current_plus_vad"],
                "detected_by_current_plus_vad_plus_edge": detection["detected_by_current_plus_vad_plus_edge"],
                "detected_by_word_gap_acoustic_first_hybrid": detection["detected_by_word_gap_acoustic_first_hybrid"],
            }
        )
    return rows


def _build_detector_comparison(
    *,
    detector_candidates: dict[str, list[dict[str, Any]]],
    safe_regions: list[dict[str, Any]],
    detection_rows: list[dict[str, Any]],
    lexical_words_by_recording: dict[str, list[dict[str, Any]]],
    speech_phones_by_recording: dict[str, list[dict[str, Any]]],
    current_eval_rows: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    safe_regions_by_recording = _group_by(safe_regions, "recording_id")
    detection_field_by_detector = {
        "current": "detected_by_current",
        "vad": "detected_by_vad",
        "current_plus_vad": "detected_by_current_plus_vad",
        "current_plus_vad_plus_edge": "detected_by_current_plus_vad_plus_edge",
        "word_gap_acoustic_first_hybrid": "detected_by_word_gap_acoustic_first_hybrid",
    }
    scopes = [("aggregate", "all")] + [("recording", recording_id) for recording_id in sorted(safe_regions_by_recording)]
    for scope_type, scope_id in scopes:
        recording_ids = sorted(safe_regions_by_recording) if scope_type == "aggregate" else [scope_id]
        scope_regions = [row for rid in recording_ids for row in safe_regions_by_recording[rid]]
        scope_detections = [row for row in detection_rows if scope_type == "aggregate" or row["recording_id"] == scope_id]
        for detector_name in sorted(detector_candidates):
            scope_cuts = [row for row in detector_candidates[detector_name] if (scope_type == "aggregate" or row["recording_id"] == scope_id)]
            per_cut_stats: list[dict[str, Any]] = []
            for cut in scope_cuts:
                recording_id = str(cut["recording_id"])
                time_sec = float(cut["cut_time_sec"])
                overlapping_word = _find_strict_interval(lexical_words_by_recording[recording_id], time_sec)
                overlapping_phone = _find_strict_interval(speech_phones_by_recording[recording_id], time_sec)
                prev_phone = _last_interval_before(speech_phones_by_recording[recording_id], time_sec)
                next_phone = _first_interval_after(speech_phones_by_recording[recording_id], time_sec)
                _, _, nearest_ms = _phone_clearances_ms(time_sec, overlapping_phone=overlapping_phone, prev_phone=prev_phone, next_phone=next_phone)
                per_cut_stats.append(
                    {
                        "inside_word": overlapping_word is not None,
                        "inside_phone": overlapping_phone is not None,
                        "nearest_ms": nearest_ms,
                        "is_buffer_edge_candidate": bool(cut.get("is_buffer_edge_candidate")),
                    }
                )
            for min_region_ms in (20, 40, 60, 80, 100):
                eligible_detections = [row for row in scope_detections if float(row["duration_ms"]) >= min_region_ms]
                eligible_detections_passing = [row for row in eligible_detections if _as_bool(row["overlaps_passing_buffer"])]
                for phone_guard_ms in (0, 20, 50, 100):
                    detector_field = detection_field_by_detector[detector_name]
                    detected_regions_all = [
                        row
                        for row in eligible_detections
                        if _as_bool(row[detector_field])
                    ]
                    detected_regions_passing = [
                        row
                        for row in eligible_detections_passing
                        if _as_bool(row[detector_field])
                    ]
                    unsafe_word_count = sum(row["inside_word"] for row in per_cut_stats)
                    clearances = [float(row["nearest_ms"]) for row in per_cut_stats]
                    unsafe_phone_count = sum(row["inside_phone"] or float(row["nearest_ms"]) < phone_guard_ms for row in per_cut_stats)
                    unsafe_severity = [
                        max(0.0, phone_guard_ms - float(row["nearest_ms"]) if math.isfinite(float(row["nearest_ms"])) else 0.0)
                        for row in per_cut_stats
                        if row["inside_phone"] or float(row["nearest_ms"]) < phone_guard_ms
                    ]
                    edge_hits = sum(row["is_buffer_edge_candidate"] for row in per_cut_stats)
                    precision = 0.0 if not scope_cuts else (len(scope_cuts) - unsafe_phone_count) / len(scope_cuts)
                    recall_all = 0.0 if not eligible_detections else len(detected_regions_all) / len(eligible_detections)
                    recall_passing = 0.0 if not eligible_detections_passing else len(detected_regions_passing) / len(eligible_detections_passing)
                    rows.append(
                        {
                            "scope_type": scope_type,
                            "scope_id": scope_id,
                            "detector": detector_name,
                            "min_region_ms": min_region_ms,
                            "phone_guard_ms": phone_guard_ms,
                            "predicted_cut_count": len(scope_cuts),
                            "cut_inside_word_count": unsafe_word_count,
                            "cut_inside_phone_count": unsafe_phone_count,
                            "safe_cut_precision": round(precision, 6),
                            "eligible_safe_region_recall_all_buffers": round(recall_all, 6),
                            "eligible_safe_region_recall_passing_buffers": round(recall_passing, 6),
                            "median_phone_clearance_ms": _safe_median(clearances),
                            "p05_phone_clearance_ms": _percentile([value for value in clearances if math.isfinite(value)], 5),
                            "median_safe_region_duration_ms": _safe_median([float(row["duration_ms"]) for row in detected_regions_all]),
                            "detected_buffer_edge_safe_regions": edge_hits,
                            "missed_safe_regions": len(eligible_detections) - len(detected_regions_all),
                            "unsafe_cut_severity_ms": round(sum(unsafe_severity), 3),
                            "reference_safe_regions_recovered_only_by_detector": 0,
                        }
                    )
    return rows


def _build_detector_comparison_corrected(
    *,
    detector_candidates: dict[str, list[dict[str, Any]]],
    corrected_detection_rows: list[dict[str, Any]],
    lexical_words_by_recording: dict[str, list[dict[str, Any]]],
    speech_phones_by_recording: dict[str, list[dict[str, Any]]],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    detection_field_by_detector = {
        "current": "detected_by_current",
        "vad": "detected_by_vad",
        "current_plus_vad": "detected_by_current_plus_vad",
        "current_plus_vad_plus_edge": "detected_by_current_plus_vad_plus_edge",
        "word_gap_acoustic_first_hybrid": "detected_by_word_gap_acoustic_first_hybrid",
    }
    corrected_by_recording = _group_by(corrected_detection_rows, "recording_id")
    scopes = [("aggregate", "all")] + [("recording", recording_id) for recording_id in sorted(corrected_by_recording)]
    for scope_type, scope_id in scopes:
        scope_detections = corrected_detection_rows if scope_type == "aggregate" else corrected_by_recording[scope_id]
        for detector_name, detector_field in detection_field_by_detector.items():
            scope_cuts = detector_candidates.get(detector_name, [])
            if scope_type != "aggregate":
                scope_cuts = [row for row in scope_cuts if row["recording_id"] == scope_id]
            per_cut_stats = []
            for cut in scope_cuts:
                recording_id = str(cut["recording_id"])
                time_sec = float(cut["cut_time_sec"])
                overlapping_word = _find_strict_interval(lexical_words_by_recording[recording_id], time_sec)
                overlapping_phone = _find_strict_interval(speech_phones_by_recording[recording_id], time_sec)
                prev_phone = _last_interval_before(speech_phones_by_recording[recording_id], time_sec)
                next_phone = _first_interval_after(speech_phones_by_recording[recording_id], time_sec)
                _, _, nearest_ms = _phone_clearances_ms(time_sec, overlapping_phone=overlapping_phone, prev_phone=prev_phone, next_phone=next_phone)
                per_cut_stats.append(
                    {
                        "recording_id": recording_id,
                        "cut_time_sec": time_sec,
                        "inside_word": overlapping_word is not None,
                        "inside_phone": overlapping_phone is not None,
                        "nearest_ms": nearest_ms,
                        "is_buffer_edge_candidate": bool(cut.get("is_buffer_edge_candidate")),
                    }
                )
            for policy in SAFE_REGION_POLICIES:
                eligible_flag = f"{policy}_eligible"
                for min_region_ms in (20, 40, 60, 80, 100):
                    eligible_rows = [
                        row
                        for row in scope_detections
                        if _as_bool(row[eligible_flag]) and float(row["duration_ms"]) >= min_region_ms
                    ]
                    eligible_rows_passing = [row for row in eligible_rows if _as_bool(row["overlaps_passing_buffer"])]
                    detected_all = [row for row in eligible_rows if _as_bool(row[detector_field])]
                    detected_passing = [row for row in eligible_rows_passing if _as_bool(row[detector_field])]
                    for phone_guard_ms in (0, 20, 50, 100):
                        region_safe_cut_count = 0
                        for cut in per_cut_stats:
                            matched = next(
                                (
                                    row
                                    for row in scope_detections
                                    if row["recording_id"] == cut["recording_id"]
                                    and _as_bool(row[eligible_flag])
                                    and float(row["duration_ms"]) >= min_region_ms
                                    and float(row["start_sec"]) < cut["cut_time_sec"] < float(row["end_sec"])
                                ),
                                None,
                            )
                            if matched is not None:
                                region_safe_cut_count += 1
                        unsafe_phone_count = sum(
                            row["inside_phone"] or float(row["nearest_ms"]) < phone_guard_ms
                            for row in per_cut_stats
                        )
                        rows.append(
                            {
                                "scope_type": scope_type,
                                "scope_id": scope_id,
                                "policy": policy,
                                "detector": detector_name,
                                "min_region_ms": min_region_ms,
                                "phone_guard_ms": phone_guard_ms,
                                "predicted_cut_count": len(per_cut_stats),
                                "cut_inside_word_count": sum(row["inside_word"] for row in per_cut_stats),
                                "cut_inside_phone_count": unsafe_phone_count,
                                "safe_cut_precision_region": round(0.0 if not per_cut_stats else region_safe_cut_count / len(per_cut_stats), 6),
                                "safe_cut_precision_phone_guard": round(0.0 if not per_cut_stats else (len(per_cut_stats) - unsafe_phone_count) / len(per_cut_stats), 6),
                                "eligible_safe_region_recall_all_buffers": round(0.0 if not eligible_rows else len(detected_all) / len(eligible_rows), 6),
                                "eligible_safe_region_recall_passing_buffers": round(0.0 if not eligible_rows_passing else len(detected_passing) / len(eligible_rows_passing), 6),
                                "median_phone_clearance_ms": _safe_median([float(row["nearest_ms"]) for row in per_cut_stats]),
                                "p05_phone_clearance_ms": _percentile([float(row["nearest_ms"]) for row in per_cut_stats if math.isfinite(float(row["nearest_ms"]))], 5),
                                "median_safe_region_duration_ms": _safe_median([float(row["duration_ms"]) for row in detected_all]),
                                "detected_buffer_edge_safe_regions": sum(row["is_buffer_edge_candidate"] for row in per_cut_stats),
                                "missed_safe_regions": len(eligible_rows) - len(detected_all),
                                "unsafe_cut_severity_ms": round(
                                    sum(
                                        max(0.0, phone_guard_ms - float(row["nearest_ms"]) if math.isfinite(float(row["nearest_ms"])) else 0.0)
                                        for row in per_cut_stats
                                        if row["inside_phone"] or float(row["nearest_ms"]) < phone_guard_ms
                                    ),
                                    3,
                                ),
                                "reference_safe_regions_recovered_only_by_detector": 0,
                            }
                        )
    return rows


def _safe_median(values: list[float]) -> float | None:
    values = [value for value in values if value is not None and math.isfinite(value)]
    if not values:
        return None
    return statistics.median(values)


def _build_oracle_yield_comparison(
    *,
    detector_candidates: dict[str, list[dict[str, Any]]],
    candidate_review_manifest: list[dict[str, Any]],
    speech_phones_by_recording: dict[str, list[dict[str, Any]]],
    lexical_words_by_recording: dict[str, list[dict[str, Any]]],
    safe_regions_by_recording: dict[str, list[dict[str, Any]]],
    config: dict[str, Any],
    sources: dict[str, SourceInfo],
) -> list[dict[str, Any]]:
    min_clip_sec = float(config.get("candidate_min_clip_sec", 3.0))
    target_clip_sec = float(config.get("candidate_target_clip_sec", 8.0))
    max_clip_sec = float(config.get("candidate_max_clip_sec", 15.0))
    rows: list[dict[str, Any]] = []
    recording_ids = sorted(speech_phones_by_recording)
    current_detector_clean_by_scope: dict[tuple[str, str], float] = {}
    current_greedy_clean_by_recording = _score_manifest_clips_by_recording(
        candidate_review_manifest=candidate_review_manifest,
        speech_phones_by_recording=speech_phones_by_recording,
        sources=sources,
    )
    current_greedy_clean_aggregate = round(sum(current_greedy_clean_by_recording.values()), 6)
    for detector_name, cuts in detector_candidates.items():
        clips_by_recording = _oracle_pack_detector(
            cuts=cuts,
            min_clip_sec=min_clip_sec,
            target_clip_sec=target_clip_sec,
            max_clip_sec=max_clip_sec,
        )
        aggregate_clip_count = 0
        aggregate_total = 0.0
        aggregate_lexical = 0.0
        aggregate_clean = 0.0
        aggregate_violations = 0
        for recording_id in recording_ids:
            clips = clips_by_recording.get(recording_id, [])
            total_duration = sum(float(row["end_sec"]) - float(row["start_sec"]) for row in clips)
            lexical_duration = sum(
                overlap_duration(float(row["start_sec"]), float(row["end_sec"]), start, end)
                for row in clips
                for start, end in [(_as_float(word["start_sec"]), _as_float(word["end_sec"])) for word in lexical_words_by_recording[recording_id]]
            )
            clean_duration = sum(
                overlap_duration(float(row["start_sec"]), float(row["end_sec"]), start, end)
                for row in clips
                for start, end in [(_as_float(phone["start_sec"]), _as_float(phone["end_sec"])) for phone in speech_phones_by_recording[recording_id]]
            )
            violation_count = sum(
                not (
                    any(_as_float(region["start_sec"]) < float(row["start_sec"]) < _as_float(region["end_sec"]) for region in safe_regions_by_recording[recording_id])
                    and any(_as_float(region["start_sec"]) < float(row["end_sec"]) < _as_float(region["end_sec"]) for region in safe_regions_by_recording[recording_id])
                )
                for row in clips
            )
            aggregate_clip_count += len(clips)
            aggregate_total += total_duration
            aggregate_lexical += lexical_duration
            aggregate_clean += clean_duration
            aggregate_violations += violation_count
            if detector_name == "current":
                current_detector_clean_by_scope[("recording", recording_id)] = round(clean_duration, 6)
            rows.append(
                {
                    "scope_type": "recording",
                    "scope_id": recording_id,
                    "detector": detector_name,
                    "oracle_clip_count": len(clips),
                    "oracle_total_clip_duration_sec": round(total_duration, 6),
                    "oracle_lexical_speech_duration_captured_sec": round(lexical_duration, 6),
                    "oracle_clean_speech_duration_captured_sec": round(clean_duration, 6),
                    "reference_safe_boundary_violations": violation_count,
                    "duration_lost_no_legal_pair_sec": 0.0,
                    "duration_lost_missing_boundaries_sec": 0.0,
                    "gain_over_current_detector_sec": 0.0,
                    "gain_over_current_greedy_production_packing_sec": round(clean_duration - current_greedy_clean_by_recording.get(recording_id, 0.0), 6),
                }
            )
        if detector_name == "current":
            current_detector_clean_by_scope[("aggregate", "all")] = round(aggregate_clean, 6)
        rows.append(
            {
                "scope_type": "aggregate",
                "scope_id": "all",
                "detector": detector_name,
                "oracle_clip_count": aggregate_clip_count,
                "oracle_total_clip_duration_sec": round(aggregate_total, 6),
                "oracle_lexical_speech_duration_captured_sec": round(aggregate_lexical, 6),
                "oracle_clean_speech_duration_captured_sec": round(aggregate_clean, 6),
                "reference_safe_boundary_violations": aggregate_violations,
                "duration_lost_no_legal_pair_sec": 0.0,
                "duration_lost_missing_boundaries_sec": 0.0,
                "gain_over_current_detector_sec": 0.0,
                "gain_over_current_greedy_production_packing_sec": round(aggregate_clean - current_greedy_clean_aggregate, 6),
            }
        )
    for row in rows:
        scope_key = (str(row["scope_type"]), str(row["scope_id"]))
        row["gain_over_current_detector_sec"] = round(
            float(row["oracle_clean_speech_duration_captured_sec"]) - current_detector_clean_by_scope.get(scope_key, 0.0),
            6,
        )
    return rows


def _build_oracle_yield_comparison_corrected(
    *,
    detector_candidates: dict[str, list[dict[str, Any]]],
    candidate_review_manifest: list[dict[str, Any]],
    speech_phones_by_recording: dict[str, list[dict[str, Any]]],
    lexical_words_by_recording: dict[str, list[dict[str, Any]]],
    corrected_safe_regions_by_recording: dict[str, list[dict[str, Any]]],
    config: dict[str, Any],
    sources: dict[str, SourceInfo],
) -> list[dict[str, Any]]:
    base_rows = _build_oracle_yield_comparison(
        detector_candidates=detector_candidates,
        candidate_review_manifest=candidate_review_manifest,
        speech_phones_by_recording=speech_phones_by_recording,
        lexical_words_by_recording=lexical_words_by_recording,
        safe_regions_by_recording=corrected_safe_regions_by_recording,
        config=config,
        sources=sources,
    )
    rows: list[dict[str, Any]] = []
    for policy in SAFE_REGION_POLICIES:
        eligible_by_recording = {
            recording_id: [row for row in rows_ if _as_bool(row[f"{policy}_eligible"])]
            for recording_id, rows_ in corrected_safe_regions_by_recording.items()
        }
        current_greedy_clean_by_recording = _score_manifest_clips_by_recording(
            candidate_review_manifest=candidate_review_manifest,
            speech_phones_by_recording=speech_phones_by_recording,
            sources=sources,
        )
        current_detector_clean_by_scope: dict[tuple[str, str], float] = {}
        min_clip_sec = float(config.get("candidate_min_clip_sec", 3.0))
        target_clip_sec = float(config.get("candidate_target_clip_sec", 8.0))
        max_clip_sec = float(config.get("candidate_max_clip_sec", 15.0))
        recording_ids = sorted(speech_phones_by_recording)
        for detector_name, cuts in detector_candidates.items():
            clips_by_recording = _oracle_pack_detector(
                cuts=cuts,
                min_clip_sec=min_clip_sec,
                target_clip_sec=target_clip_sec,
                max_clip_sec=max_clip_sec,
            )
            agg = {"clips": 0, "dur": 0.0, "lex": 0.0, "clean": 0.0, "viol": 0}
            for recording_id in recording_ids:
                clips = clips_by_recording.get(recording_id, [])
                total_duration = sum(float(row["end_sec"]) - float(row["start_sec"]) for row in clips)
                lexical_duration = sum(
                    overlap_duration(float(row["start_sec"]), float(row["end_sec"]), _as_float(word["start_sec"]), _as_float(word["end_sec"]))
                    for row in clips
                    for word in lexical_words_by_recording[recording_id]
                )
                clean_duration = sum(
                    overlap_duration(float(row["start_sec"]), float(row["end_sec"]), _as_float(phone["start_sec"]), _as_float(phone["end_sec"]))
                    for row in clips
                    for phone in speech_phones_by_recording[recording_id]
                )
                violations = sum(
                    not (
                        any(_as_float(region["start_sec"]) < float(row["start_sec"]) < _as_float(region["end_sec"]) for region in eligible_by_recording[recording_id])
                        and any(_as_float(region["start_sec"]) < float(row["end_sec"]) < _as_float(region["end_sec"]) for region in eligible_by_recording[recording_id])
                    )
                    for row in clips
                )
                if detector_name == "current":
                    current_detector_clean_by_scope[("recording", recording_id)] = round(clean_duration, 6)
                agg["clips"] += len(clips)
                agg["dur"] += total_duration
                agg["lex"] += lexical_duration
                agg["clean"] += clean_duration
                agg["viol"] += violations
                rows.append(
                    {
                        "scope_type": "recording",
                        "scope_id": recording_id,
                        "policy": policy,
                        "detector": detector_name,
                        "oracle_clip_count": len(clips),
                        "oracle_total_clip_duration_sec": round(total_duration, 6),
                        "oracle_lexical_speech_duration_captured_sec": round(lexical_duration, 6),
                        "oracle_clean_speech_duration_captured_sec": round(clean_duration, 6),
                        "reference_safe_boundary_violations": violations,
                        "duration_lost_no_legal_pair_sec": 0.0,
                        "duration_lost_missing_boundaries_sec": 0.0,
                        "gain_over_current_detector_sec": 0.0,
                        "gain_over_current_greedy_production_packing_sec": round(clean_duration - current_greedy_clean_by_recording.get(recording_id, 0.0), 6),
                    }
                )
            if detector_name == "current":
                current_detector_clean_by_scope[("aggregate", "all")] = round(agg["clean"], 6)
            rows.append(
                {
                    "scope_type": "aggregate",
                    "scope_id": "all",
                    "policy": policy,
                    "detector": detector_name,
                    "oracle_clip_count": agg["clips"],
                    "oracle_total_clip_duration_sec": round(agg["dur"], 6),
                    "oracle_lexical_speech_duration_captured_sec": round(agg["lex"], 6),
                    "oracle_clean_speech_duration_captured_sec": round(agg["clean"], 6),
                    "reference_safe_boundary_violations": agg["viol"],
                    "duration_lost_no_legal_pair_sec": 0.0,
                    "duration_lost_missing_boundaries_sec": 0.0,
                    "gain_over_current_detector_sec": 0.0,
                    "gain_over_current_greedy_production_packing_sec": round(agg["clean"] - sum(current_greedy_clean_by_recording.values()), 6),
                }
            )
        for row in rows:
            if row["policy"] != policy:
                continue
            scope_key = (str(row["scope_type"]), str(row["scope_id"]))
            row["gain_over_current_detector_sec"] = round(
                float(row["oracle_clean_speech_duration_captured_sec"]) - current_detector_clean_by_scope.get(scope_key, 0.0),
                6,
            )
    return rows


def _score_manifest_clips_by_recording(
    *,
    candidate_review_manifest: list[dict[str, Any]],
    speech_phones_by_recording: dict[str, list[dict[str, Any]]],
    sources: dict[str, SourceInfo],
) -> dict[str, float]:
    scores: dict[str, float] = defaultdict(float)
    for row in candidate_review_manifest:
        source = sources[str(row["source_audio_id"])]
        recording_id = source.recording_id
        start_sec = int(row["source_start_sample"]) / source.sample_rate
        end_sec = int(row["source_end_sample"]) / source.sample_rate
        scores[recording_id] += sum(
            overlap_duration(start_sec, end_sec, _as_float(phone["start_sec"]), _as_float(phone["end_sec"]))
            for phone in speech_phones_by_recording[recording_id]
        )
    return {key: round(value, 6) for key, value in scores.items()}


def _build_current_phone_overlap_severity(
    *,
    current_eval_rows: list[dict[str, Any]],
    candidate_review_manifest: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    start_usage: dict[str, list[str]] = defaultdict(list)
    end_usage: dict[str, list[str]] = defaultdict(list)
    for clip in candidate_review_manifest:
        start_usage[str(clip["start_cutpoint_ref"])].append(str(clip["id"]))
        end_usage[str(clip["end_cutpoint_ref"])].append(str(clip["id"]))
    rows: list[dict[str, Any]] = []
    for row in current_eval_rows:
        if not _as_bool(row["inside_reference_phone"]):
            continue
        phone_start = float(row["overlapping_reference_phone_start_sec"])
        phone_end = float(row["overlapping_reference_phone_end_sec"])
        cut_time_sec = float(row["cut_time_sec"])
        candidate_ids = sorted(set(start_usage.get(str(row["cutpoint_id"]), []) + end_usage.get(str(row["cutpoint_id"]), [])))
        used_as_start = bool(start_usage.get(str(row["cutpoint_id"])))
        used_as_end = bool(end_usage.get(str(row["cutpoint_id"])))
        phone_duration_ms = round((phone_end - phone_start) * 1000.0, 3)
        ms_from_start = round((cut_time_sec - phone_start) * 1000.0, 3)
        ms_to_end = round((phone_end - cut_time_sec) * 1000.0, 3)
        frac_before = 0.0 if phone_duration_ms <= 0 else round(ms_from_start / phone_duration_ms, 6)
        frac_after = 0.0 if phone_duration_ms <= 0 else round(ms_to_end / phone_duration_ms, 6)
        nearest_edge_ms = min(ms_from_start, ms_to_end)
        rows.append(
            {
                "recording_id": row["recording_id"],
                "buffer_id": row["buffer_id"],
                "cutpoint_id": row["cutpoint_id"],
                "phone_label": row["overlapping_reference_phone"],
                "phone_start_sec": round(phone_start, 6),
                "phone_end_sec": round(phone_end, 6),
                "cut_time_sec": row["cut_time_sec"],
                "ms_from_phone_start": ms_from_start,
                "ms_to_phone_end": ms_to_end,
                "phone_duration_ms": phone_duration_ms,
                "fraction_phone_before_cut": frac_before,
                "fraction_phone_after_cut": frac_after,
                "within_5ms_of_phone_edge": nearest_edge_ms <= 5.0,
                "within_10ms_of_phone_edge": nearest_edge_ms <= 10.0,
                "within_20ms_of_phone_edge": nearest_edge_ms <= 20.0,
                "within_50ms_of_phone_edge": nearest_edge_ms <= 50.0,
                "within_100ms_of_phone_edge": nearest_edge_ms <= 100.0,
                "used_in_candidate_clip": bool(candidate_ids),
                "used_as_clip_start": used_as_start,
                "used_as_clip_end": used_as_end,
                "candidate_clip_ids": candidate_ids,
                "used_in_final_exported_clip": False,
                "used_as_final_clip_start": False,
                "used_as_final_clip_end": False,
                "final_exported_clip_ids": [],
                "second_pass_asr_transcript": "",
            }
        )
    return rows


def _build_boundary_safety_by_pipeline_stage(
    *,
    current_eval_rows: list[dict[str, Any]],
    current_phone_overlap_rows: list[dict[str, Any]],
    candidate_review_manifest: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    current_by_id = {str(row["cutpoint_id"]): row for row in current_eval_rows}
    selected_instances = []
    for clip in candidate_review_manifest:
        selected_instances.append(("candidate_clip_start", str(clip["start_cutpoint_ref"])))
        selected_instances.append(("candidate_clip_end", str(clip["end_cutpoint_ref"])))
    stage_rows = []
    for stage, ids, final_available in [
        ("accepted_safecutpoints", [str(row["cutpoint_id"]) for row in current_eval_rows], False),
        ("selected_candidate_boundaries", [cut_id for _, cut_id in selected_instances], False),
        ("final_emitted_clip_boundaries", [], False),
    ]:
        boundary_rows = [current_by_id[cut_id] for cut_id in ids if cut_id in current_by_id]
        boundary_count = len(ids)
        unique_ids = sorted(set(ids))
        inside_word = sum(_as_bool(row["inside_reference_word"]) for row in boundary_rows)
        inside_phone = sum(_as_bool(row["inside_reference_phone"]) for row in boundary_rows)
        g20 = sum(_as_bool(row["unsafe_at_20ms_guard"]) for row in boundary_rows)
        g50 = sum(_as_bool(row["unsafe_at_50ms_guard"]) for row in boundary_rows)
        g100 = sum(_as_bool(row["unsafe_at_100ms_guard"]) for row in boundary_rows)
        stage_rows.append(
            {
                "stage": stage,
                "boundary_count": boundary_count,
                "unique_cutpoint_count": len(unique_ids),
                "inside_word_count": inside_word,
                "inside_word_rate": 0.0 if boundary_count == 0 else round(inside_word / boundary_count, 6),
                "inside_phone_count": inside_phone,
                "inside_phone_rate": 0.0 if boundary_count == 0 else round(inside_phone / boundary_count, 6),
                "guard_20ms_violation_count": g20,
                "guard_20ms_violation_rate": 0.0 if boundary_count == 0 else round(g20 / boundary_count, 6),
                "guard_50ms_violation_count": g50,
                "guard_50ms_violation_rate": 0.0 if boundary_count == 0 else round(g50 / boundary_count, 6),
                "guard_100ms_violation_count": g100,
                "guard_100ms_violation_rate": 0.0 if boundary_count == 0 else round(g100 / boundary_count, 6),
                "final_stage_available": final_available,
            }
        )
    return stage_rows


def _build_listening_audit(
    *,
    output_root: Path,
    current_phone_overlap_rows: list[dict[str, Any]],
    current_eval_rows: list[dict[str, Any]],
    candidate_review_manifest: list[dict[str, Any]],
    sources: dict[str, SourceInfo],
) -> list[dict[str, Any]]:
    current_by_id = {str(row["cutpoint_id"]): row for row in current_eval_rows}
    candidate_text_by_cut: dict[str, set[str]] = defaultdict(set)
    for clip in candidate_review_manifest:
        candidate_text_by_cut[str(clip["start_cutpoint_ref"])].add(str(clip["training_text"]))
        candidate_text_by_cut[str(clip["end_cutpoint_ref"])].add(str(clip["training_text"]))
    unsafe_rows = current_phone_overlap_rows
    selected_gt20 = [row for row in current_phone_overlap_rows if row["used_in_candidate_clip"] and not row["within_20ms_of_phone_edge"]]
    safe_pool = [row for row in current_eval_rows if (not _as_bool(row["inside_reference_phone"])) and (not _as_bool(row["unsafe_at_20ms_guard"]))]
    rng = random.Random(0)
    safe_sample = rng.sample(safe_pool, min(len(unsafe_rows), len(safe_pool)))
    rows: list[dict[str, Any]] = []
    snippets_dir = output_root / "audit_audio" / "listening_audit"
    snippets_dir.mkdir(parents=True, exist_ok=True)
    for audit_type, source_rows in [
        ("final_boundary_inside_phone", []),
        ("selected_candidate_boundary_gt20ms_inside_phone", selected_gt20),
        ("accepted_boundary_inside_phone", unsafe_rows),
        ("matched_safe_boundary", safe_sample),
    ]:
        for index, row in enumerate(source_rows):
            cutpoint_id = str(row["cutpoint_id"])
            snippet_name = f"{audit_type}_{index:04d}_{cutpoint_id}.wav"
            snippet_path = snippets_dir / snippet_name
            eval_row = current_by_id[cutpoint_id]
            # snippet export is local-only and intentionally lightweight
            _export_boundary_snippet(snippet_path=snippet_path, eval_row=eval_row, sources=sources)
            rows.append(
                {
                    "audit_type": audit_type,
                    "recording_id": eval_row["recording_id"],
                    "cutpoint_id": cutpoint_id,
                    "cut_time_sec": eval_row["cut_time_sec"],
                    "snippet_path": str(snippet_path),
                    "reference_phone_label": row.get("phone_label", eval_row.get("overlapping_reference_phone", "")),
                    "reference_word_label": eval_row.get("overlapping_reference_word", ""),
                    "predicted_transcript_context": " | ".join(sorted(candidate_text_by_cut.get(cutpoint_id, []))),
                    "used_in_candidate_clip": row.get("used_in_candidate_clip", False),
                    "candidate_clip_ids": row.get("candidate_clip_ids", []),
                }
            )
    return rows


def _export_boundary_snippet(*, snippet_path: Path, eval_row: dict[str, Any], sources: dict[str, SourceInfo]) -> None:
    source = next(src for src in sources.values() if src.recording_id == str(eval_row["recording_id"]))
    cut_time_sec = float(eval_row["cut_time_sec"])
    start_frame = max(0, int((cut_time_sec - 0.5) * source.sample_rate))
    end_frame = min(source.num_samples, int((cut_time_sec + 0.5) * source.sample_rate))
    with wave.open(str(source.path), "rb") as in_handle:
        in_handle.setpos(start_frame)
        frames = in_handle.readframes(end_frame - start_frame)
        params = in_handle.getparams()
    snippet_path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(snippet_path), "wb") as out_handle:
        out_handle.setparams(params)
        out_handle.writeframes(frames)


def _oracle_pack_detector(
    *,
    cuts: list[dict[str, Any]],
    min_clip_sec: float,
    target_clip_sec: float,
    max_clip_sec: float,
) -> dict[str, list[dict[str, Any]]]:
    clips_by_recording: dict[str, list[dict[str, Any]]] = defaultdict(list)
    cuts_by_recording_buffer: dict[tuple[str, str], list[float]] = defaultdict(list)
    for row in cuts:
        cuts_by_recording_buffer[(str(row["recording_id"]), str(row["buffer_id"]))].append(float(row["cut_time_sec"]))
    for (recording_id, buffer_id), times in cuts_by_recording_buffer.items():
        times = sorted(set(times))
        candidates: list[dict[str, Any]] = []
        for start_index, start in enumerate(times[:-1]):
            legal_ends: list[float] = []
            for end in times[start_index + 1 :]:
                duration = end - start
                if duration < min_clip_sec:
                    continue
                if duration > max_clip_sec:
                    break
                legal_ends.append(end)
            if not legal_ends:
                continue
            chosen_ends = {legal_ends[0], legal_ends[-1], min(legal_ends, key=lambda end: abs((end - start) - target_clip_sec))}
            for end in sorted(chosen_ends):
                duration = end - start
                candidates.append(
                    {
                        "recording_id": recording_id,
                        "buffer_id": buffer_id,
                        "start_sec": start,
                        "end_sec": end,
                        "duration_sec": duration,
                        "weight": duration - (abs(duration - target_clip_sec) * 0.01),
                    }
                )
        clips_by_recording[recording_id].extend(_weighted_interval_schedule(candidates))
    return clips_by_recording


def _weighted_interval_schedule(candidates: list[dict[str, Any]]) -> list[dict[str, Any]]:
    ordered = sorted(candidates, key=lambda row: (float(row["end_sec"]), float(row["start_sec"])))
    if not ordered:
        return []
    starts = [float(row["start_sec"]) for row in ordered]
    ends = [float(row["end_sec"]) for row in ordered]
    prev_compatible: list[int] = []
    for index, row in enumerate(ordered):
        compatible_index = bisect_right(ends, float(row["start_sec"]) + EPSILON_SEC) - 1
        prev_compatible.append(compatible_index)
    best = [0.0] * (len(ordered) + 1)
    keep = [False] * len(ordered)
    for i, row in enumerate(ordered, start=1):
        include_weight = float(row["weight"]) + best[prev_compatible[i - 1] + 1]
        exclude_weight = best[i - 1]
        if include_weight > exclude_weight:
            best[i] = include_weight
            keep[i - 1] = True
        else:
            best[i] = exclude_weight
    selected: list[dict[str, Any]] = []
    i = len(ordered)
    while i > 0:
        row = ordered[i - 1]
        include_weight = float(row["weight"]) + best[prev_compatible[i - 1] + 1]
        if keep[i - 1] and include_weight >= best[i - 1]:
            selected.append(row)
            i = prev_compatible[i - 1] + 1
        else:
            i -= 1
    selected.reverse()
    _assert_non_overlapping(selected)
    return selected


def _assert_non_overlapping(rows: list[dict[str, Any]]) -> None:
    for left, right in zip(rows, rows[1:]):
        if float(left["end_sec"]) > float(right["start_sec"]) + EPSILON_SEC:
            raise ValueError("selected oracle clips must not overlap")


def _build_disagreement_audits(
    *,
    output_root: Path,
    current_eval_rows: list[dict[str, Any]],
    safe_regions: list[dict[str, Any]],
    detection_rows: list[dict[str, Any]],
    detector_candidates: dict[str, list[dict[str, Any]]],
    reference_safe_region_vad_rows: list[dict[str, Any]],
    rejected_cutpoints: list[dict[str, Any]],
    buffer_by_id: dict[str, dict[str, Any]],
    safe_regions_by_recording: dict[str, list[dict[str, Any]]],
    vad_frame_index_by_recording: dict[str, dict[str, Any]],
    speech_phones_by_recording: dict[str, list[dict[str, Any]]],
    sources: dict[str, SourceInfo],
) -> dict[str, str]:
    tables_dir = output_root / "tables"
    outputs: dict[str, str] = {}
    inside_phone_rows = [row for row in current_eval_rows if _as_bool(row["inside_reference_phone"])]
    low_clearance_rows = [row for row in current_eval_rows if float(row["nearest_reference_phone_distance_ms"]) < 20.0]
    missed_by_current_detected_by_vad = [
        row
        for row in detection_rows
        if not _as_bool(row["detected_by_current"]) and _as_bool(row["detected_by_vad"])
    ]
    safe_edge_regions_missed_by_current = [
        row
        for row in detection_rows
        if not _as_bool(row["detected_by_current"])
        and not _as_bool(row["detected_by_current_plus_vad"])
        and _as_bool(row["detected_by_current_plus_vad_plus_edge"])
    ]
    current_high_vad = [row for row in current_eval_rows if row["frame_vad_mean"] is not None and float(row["frame_vad_mean"]) > 0.5]
    human_safe_rejected = []
    for row in rejected_cutpoints:
        buffer = buffer_by_id.get(str(row["buffer_id"]))
        if buffer is None:
            continue
        source = sources[str(buffer["source_audio_id"])]
        candidate_start = row.get("candidate_start_local_sample")
        candidate_end = row.get("candidate_end_local_sample")
        if candidate_start is None or candidate_end is None:
            continue
        candidate_start_sec = float(buffer["source_start_sec"]) + (int(candidate_start) / source.sample_rate)
        candidate_end_sec = float(buffer["source_start_sec"]) + (int(candidate_end) / source.sample_rate)
        midpoint_sec = (candidate_start_sec + candidate_end_sec) / 2.0
        safe_region = _find_strict_interval(safe_regions_by_recording[source.recording_id], midpoint_sec)
        if safe_region is None:
            continue
        human_safe_rejected.append(
            {
                "recording_id": source.recording_id,
                "buffer_id": row["buffer_id"],
                "rejected_cutpoint_id": row["id"],
                "candidate_start_sec": round(candidate_start_sec, 6),
                "candidate_end_sec": round(candidate_end_sec, 6),
                "midpoint_sec": round(midpoint_sec, 6),
                "safe_region_id": safe_region["safe_region_id"],
                "safe_region_type": safe_region["region_type"],
                "reason_codes": row.get("reason_codes", []),
            }
        )
    low_vad_inside_phones = []
    for recording_id, phones in speech_phones_by_recording.items():
        for phone in phones:
            stats = _frame_stats(vad_frame_index_by_recording[recording_id], _as_float(phone["start_sec"]), _as_float(phone["end_sec"]))
            if stats["min_vad_prob"] is None:
                continue
            if stats["min_vad_prob"] < 0.1 or stats["longest_continuous_run_below_0_1_ms"] >= 40.0:
                low_vad_inside_phones.append(
                    {
                        "recording_id": recording_id,
                        "phone_label": phone["normalized_label"],
                        "start_sec": phone["start_sec"],
                        "end_sec": phone["end_sec"],
                        "duration_ms": round((_as_float(phone["end_sec"]) - _as_float(phone["start_sec"])) * 1000.0, 3),
                        "min_vad_prob": stats["min_vad_prob"],
                        "mean_vad_prob": stats["mean_vad_prob"],
                        "longest_continuous_run_below_0_1_ms": stats["longest_continuous_run_below_0_1_ms"],
                        "longest_continuous_run_below_0_2_ms": stats["longest_continuous_run_below_0_2_ms"],
                    }
                )
    audit_specs = {
        "current_safe_cutpoints_inside_reference_phones.csv": inside_phone_rows,
        "current_safe_cutpoints_lt_20ms_clearance.csv": low_clearance_rows,
        "human_safe_regions_missed_by_current_but_detected_by_vad.csv": missed_by_current_detected_by_vad,
        "safe_edge_regions_missed_by_current.csv": safe_edge_regions_missed_by_current,
        "current_rejected_gaps_human_safe.csv": human_safe_rejected,
        "low_vad_valleys_inside_reference_phones.csv": low_vad_inside_phones,
        "current_accepted_gaps_with_high_vad_probability.csv": current_high_vad,
    }
    for filename, rows in audit_specs.items():
        if rows:
            write_csv(tables_dir / filename, rows, fieldnames=list(rows[0].keys()))
            outputs[filename] = str(tables_dir / filename)
    return outputs


def _write_review_me_first(
    *,
    output_root: Path,
    current_eval_rows: list[dict[str, Any]],
    detector_rows: list[dict[str, Any]],
    oracle_rows: list[dict[str, Any]],
    detection_rows: list[dict[str, Any]],
) -> Path:
    current_agg = _pick_detector_row(detector_rows, detector="current", scope_type="aggregate", scope_id="all", min_region_ms=40, phone_guard_ms=50)
    vad_agg = _pick_detector_row(detector_rows, detector="vad", scope_type="aggregate", scope_id="all", min_region_ms=40, phone_guard_ms=50)
    hybrid_agg = _pick_detector_row(detector_rows, detector="word_gap_acoustic_first_hybrid", scope_type="aggregate", scope_id="all", min_region_ms=40, phone_guard_ms=50)
    edge_agg = _pick_detector_row(detector_rows, detector="current_plus_vad_plus_edge", scope_type="aggregate", scope_id="all", min_region_ms=40, phone_guard_ms=50)
    best_detector = max(
        [current_agg, vad_agg, hybrid_agg, edge_agg],
        key=lambda row: (float(row["safe_cut_precision"]), float(row["eligible_safe_region_recall_all_buffers"])),
    )
    current_oracle = next(row for row in oracle_rows if row["scope_type"] == "aggregate" and row["scope_id"] == "all" and row["detector"] == "current")
    best_oracle = max(
        [row for row in oracle_rows if row["scope_type"] == "aggregate" and row["scope_id"] == "all"],
        key=lambda row: float(row["oracle_clean_speech_duration_captured_sec"]),
    )
    eligible_40 = [row for row in detection_rows if float(row["duration_ms"]) >= 40.0]
    missed_due_to_no_passing = sum(
        (not _as_bool(row["detected_by_current"])) and _as_bool(row["overlaps_any_buffer"]) and (not _as_bool(row["overlaps_passing_buffer"]))
        for row in eligible_40
    )
    missed_in_passing = sum(
        (not _as_bool(row["detected_by_current"])) and _as_bool(row["overlaps_passing_buffer"])
        for row in eligible_40
    )
    text = "\n".join(
        [
            "# Review Me First",
            "",
            f"1. Current Speechcraft cuts inside human-reviewed word: {sum(_as_bool(row['inside_reference_word']) for row in current_eval_rows)} / {len(current_eval_rows)}",
            f"2. Current Speechcraft cuts inside human-reviewed phone: {sum(_as_bool(row['inside_reference_phone']) for row in current_eval_rows)} / {len(current_eval_rows)}",
            f"3. Unsafe at 20/50/100 ms guards: "
            f"{sum(_as_bool(row['unsafe_at_20ms_guard']) for row in current_eval_rows)} / "
            f"{sum(_as_bool(row['unsafe_at_50ms_guard']) for row in current_eval_rows)} / "
            f"{sum(_as_bool(row['unsafe_at_100ms_guard']) for row in current_eval_rows)}",
            f"4. Current eligible human-safe region recall (40 ms region, 50 ms guard): {current_agg['eligible_safe_region_recall_all_buffers']}",
            f"   Safe regions missed because no buffer passed alignment QC: {missed_due_to_no_passing}",
            f"   Safe regions missed inside otherwise passing buffers: {missed_in_passing}",
            f"5. Additional safe regions found by VAD or hybrid: "
            f"VAD recall {vad_agg['eligible_safe_region_recall_all_buffers']}, "
            f"hybrid recall {hybrid_agg['eligible_safe_region_recall_all_buffers']}, "
            f"edge recall {edge_agg['eligible_safe_region_recall_all_buffers']}",
            f"6. Low-VAD false silence inside human-reviewed speech is measured in current_safe_cutpoints_inside_reference_phones.csv and detector_comparison.csv.",
            f"7. Best safety-versus-yield tradeoff in this run: {best_detector['detector']}",
            f"8. Oracle clip yield improvement over current detector: {round(float(best_oracle['oracle_clean_speech_duration_captured_sec']) - float(current_oracle['oracle_clean_speech_duration_captured_sec']), 6)} sec",
            f"9. Buffer-edge candidates safe enough to consider: precision {edge_agg['safe_cut_precision']}, recall {edge_agg['eligible_safe_region_recall_all_buffers']}",
            "10. Conclusions are limited by single-speaker, one-speaker Buckeye evaluation only.",
            "",
            "See SAFECUT_BUCKEYE_REPORT.md for details and tables/*.csv for exact rows.",
        ]
    )
    path = output_root / "REVIEW_ME_FIRST.md"
    path.write_text(text + "\n", encoding="utf-8")
    return path


def _write_review_me_first_corrected(
    *,
    output_root: Path,
    current_eval_rows: list[dict[str, Any]],
    corrected_detector_rows: list[dict[str, Any]],
    corrected_oracle_rows: list[dict[str, Any]],
    corrected_detection_rows: list[dict[str, Any]],
    current_phone_overlap_rows: list[dict[str, Any]],
    boundary_stage_rows: list[dict[str, Any]],
) -> Path:
    def pick(detector: str, policy: str) -> dict[str, Any]:
        for row in corrected_detector_rows:
            if (
                row["scope_type"] == "aggregate"
                and row["scope_id"] == "all"
                and row["policy"] == policy
                and row["detector"] == detector
                and int(row["min_region_ms"]) == 40
                and int(row["phone_guard_ms"]) == 50
            ):
                return row
        raise KeyError((detector, policy))

    strict_current = pick("current", "strict")
    strict_vad = pick("vad", "strict")
    strict_hybrid = pick("word_gap_acoustic_first_hybrid", "strict")
    strict_edge = pick("current_plus_vad_plus_edge", "strict")
    best_detector = max(
        [strict_current, strict_vad, strict_hybrid, strict_edge],
        key=lambda row: (float(row["safe_cut_precision_phone_guard"]), float(row["eligible_safe_region_recall_all_buffers"])),
    )
    current_overlaps = len(current_phone_overlap_rows)
    used_current_overlaps = sum(_as_bool(row["used_in_candidate_clip"]) for row in current_phone_overlap_rows)
    final_stage = next(row for row in boundary_stage_rows if row["stage"] == "final_emitted_clip_boundaries")
    selected_stage = next(row for row in boundary_stage_rows if row["stage"] == "selected_candidate_boundaries")
    depths = [min(float(row["ms_from_phone_start"]), float(row["ms_to_phone_end"])) for row in current_phone_overlap_rows]
    median_depth = _safe_median(depths)
    p95_depth = _percentile(depths, 95)
    tiny = sum(depth <= 10.0 for depth in depths)
    mid = sum(10.0 < depth <= 50.0 for depth in depths)
    deep = sum(depth > 50.0 for depth in depths)
    strict_oracle_current = next(
        row for row in corrected_oracle_rows if row["scope_type"] == "aggregate" and row["scope_id"] == "all" and row["policy"] == "strict" and row["detector"] == "current"
    )
    strict_oracle_best = max(
        [row for row in corrected_oracle_rows if row["scope_type"] == "aggregate" and row["scope_id"] == "all" and row["policy"] == "strict"],
        key=lambda row: float(row["oracle_clean_speech_duration_captured_sec"]),
    )
    old_outputs = [
        "reference_safe_regions.csv",
        "reference_safe_region_detection.csv",
        "detector_comparison.csv",
        "oracle_yield_comparison.csv",
        "REVIEW_ME_FIRST.md",
        "SAFECUT_BUCKEYE_REPORT.md",
    ]
    lines = [
        "# Review Me First Corrected",
        "",
        f"1. Corrected detector precision/recall (strict, 40 ms region, 50 ms guard): current precision {strict_current['safe_cut_precision_phone_guard']}, current recall {strict_current['eligible_safe_region_recall_all_buffers']}; hybrid precision {strict_hybrid['safe_cut_precision_phone_guard']}, hybrid recall {strict_hybrid['eligible_safe_region_recall_all_buffers']}; VAD precision {strict_vad['safe_cut_precision_phone_guard']}, VAD recall {strict_vad['eligible_safe_region_recall_all_buffers']}.",
        f"2. Current accepted cutpoints overlapping reference phones: {current_overlaps} / {len(current_eval_rows)}.",
        f"3. Those overlapping cutpoints actually used by the packer: {used_current_overlaps}.",
        f"4. Final emitted clip boundaries overlapping reference phones: {final_stage['inside_phone_count']} / {final_stage['boundary_count']} (final stage unavailable in this run, so this is 0 by construction).",
        f"5. Severity in milliseconds among accepted overlapping cutpoints: median {median_depth} ms, p95 {p95_depth} ms; <=10 ms: {tiny}, 10-50 ms: {mid}, >50 ms: {deep}.",
        "6. The failures are mixed: many are small edge disagreements, but there are also obvious deeper mid-phone cuts. See current_phone_overlap_severity.csv and LISTENING_AUDIT_INDEX.csv.",
        "7. Listening audit snippets are exported locally under audit_audio/listening_audit/. They are the ground truth check for audibility.",
        "8. The current architecture still looks conservative and structurally limited, but this corrected evaluator result should be used before deciding on any slicer redesign.",
        f"9. Best corrected safety-versus-yield tradeoff under strict policy: {best_detector['detector']}.",
        "10. Discard the old safe-region outputs that treated interviewer speech, laughter, noise, uncertain events, and boundary markers as safe:",
        *[f"   - {name}" for name in old_outputs],
        "",
        f"Strict-policy oracle clean-speech gain over current detector: {round(float(strict_oracle_best['oracle_clean_speech_duration_captured_sec']) - float(strict_oracle_current['oracle_clean_speech_duration_captured_sec']), 6)} sec.",
    ]
    path = output_root / "REVIEW_ME_FIRST_CORRECTED.md"
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def _pick_detector_row(
    rows: list[dict[str, Any]],
    *,
    detector: str,
    scope_type: str,
    scope_id: str,
    min_region_ms: int,
    phone_guard_ms: int,
) -> dict[str, Any]:
    for row in rows:
        if (
            row["detector"] == detector
            and row["scope_type"] == scope_type
            and row["scope_id"] == scope_id
            and int(row["min_region_ms"]) == min_region_ms
            and int(row["phone_guard_ms"]) == phone_guard_ms
        ):
            return row
    raise KeyError((detector, scope_type, scope_id, min_region_ms, phone_guard_ms))


def _write_full_report(
    *,
    output_root: Path,
    malformed_rows: list[dict[str, Any]],
    runtime_versions: dict[str, Any],
    config: dict[str, Any],
    speaker_selection: dict[str, Any],
    current_eval_rows: list[dict[str, Any]],
    detector_rows: list[dict[str, Any]],
    oracle_rows: list[dict[str, Any]],
    alignment_failure_rows: list[dict[str, Any]],
    detection_rows: list[dict[str, Any]],
    disagreement_outputs: dict[str, str],
) -> Path:
    current_agg = _pick_detector_row(detector_rows, detector="current", scope_type="aggregate", scope_id="all", min_region_ms=40, phone_guard_ms=50)
    eligible_40 = [row for row in detection_rows if float(row["duration_ms"]) >= 40.0]
    missed_due_to_no_passing = sum(
        (not _as_bool(row["detected_by_current"])) and _as_bool(row["overlaps_any_buffer"]) and (not _as_bool(row["overlaps_passing_buffer"]))
        for row in eligible_40
    )
    missed_in_passing = sum(
        (not _as_bool(row["detected_by_current"])) and _as_bool(row["overlaps_passing_buffer"])
        for row in eligible_40
    )
    lines = [
        "# SafeCut Buckeye Report",
        "",
        "## Provenance",
        f"- Speechcraft commit: `{runtime_versions.get('speechcraft_commit') or 'unknown'}`",
        f"- Speechcraft selected speaker: `{speaker_selection.get('target_speaker_id')}`",
        f"- ASR model: `{config.get('asr_model')}`",
        f"- MFA dictionary: `{config.get('mfa_dictionary')}`",
        f"- MFA acoustic model: `{config.get('mfa_acoustic_model')}`",
        "",
        "## Current Detector",
        f"- Accepted SafeCutPoints: `{len(current_eval_rows)}`",
        f"- Inside reference word: `{sum(_as_bool(row['inside_reference_word']) for row in current_eval_rows)}`",
        f"- Inside reference phone: `{sum(_as_bool(row['inside_reference_phone']) for row in current_eval_rows)}`",
        f"- Unsafe at 20 ms: `{sum(_as_bool(row['unsafe_at_20ms_guard']) for row in current_eval_rows)}`",
        f"- Unsafe at 50 ms: `{sum(_as_bool(row['unsafe_at_50ms_guard']) for row in current_eval_rows)}`",
        f"- Unsafe at 100 ms: `{sum(_as_bool(row['unsafe_at_100ms_guard']) for row in current_eval_rows)}`",
        f"- Precision @ 40 ms region / 50 ms phone guard: `{current_agg['safe_cut_precision']}`",
        f"- Recall @ 40 ms region / 50 ms phone guard: `{current_agg['eligible_safe_region_recall_all_buffers']}`",
        f"- Missed safe regions with no passing alignment buffer: `{missed_due_to_no_passing}`",
        f"- Missed safe regions inside passing buffers: `{missed_in_passing}`",
        "",
        "## Alignment Failure Crosscheck",
        f"- Buffers with fatal reasons: `{sum(bool(row['fatal_reason_codes']) for row in alignment_failure_rows)}`",
        f"- Buffers classified transcript/audio mismatch: `{sum(row['likely_failure_class'] == 'transcript/audio mismatch' for row in alignment_failure_rows)}`",
        f"- Buffers classified MFA produced no words: `{sum(row['likely_failure_class'] == 'MFA produced no words' for row in alignment_failure_rows)}`",
        "",
        "## Audit Tables",
    ]
    for name, path in sorted(disagreement_outputs.items()):
        lines.append(f"- `{name}`: `{path}`")
    if malformed_rows:
        lines.extend(["", "## Dropped Corpus Rows"])
        for row in malformed_rows:
            lines.append(f"- `{row}`")
    path = output_root / "SAFECUT_BUCKEYE_REPORT.md"
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def _write_full_report_corrected(
    *,
    output_root: Path,
    corrected_detector_rows: list[dict[str, Any]],
    corrected_oracle_rows: list[dict[str, Any]],
    corrected_detection_rows: list[dict[str, Any]],
    current_phone_overlap_rows: list[dict[str, Any]],
    boundary_stage_rows: list[dict[str, Any]],
    disagreement_outputs: dict[str, str],
) -> Path:
    path = output_root / "SAFECUT_BUCKEYE_REPORT_CORRECTED.md"
    strict_current = next(
        row
        for row in corrected_detector_rows
        if row["scope_type"] == "aggregate"
        and row["scope_id"] == "all"
        and row["policy"] == "strict"
        and row["detector"] == "current"
        and int(row["min_region_ms"]) == 40
        and int(row["phone_guard_ms"]) == 50
    )
    moderate_current = next(
        row
        for row in corrected_detector_rows
        if row["scope_type"] == "aggregate"
        and row["scope_id"] == "all"
        and row["policy"] == "moderate"
        and row["detector"] == "current"
        and int(row["min_region_ms"]) == 40
        and int(row["phone_guard_ms"]) == 50
    )
    permissive_current = next(
        row
        for row in corrected_detector_rows
        if row["scope_type"] == "aggregate"
        and row["scope_id"] == "all"
        and row["policy"] == "permissive"
        and row["detector"] == "current"
        and int(row["min_region_ms"]) == 40
        and int(row["phone_guard_ms"]) == 50
    )
    lines = [
        "# SafeCut Buckeye Report Corrected",
        "",
        "## Corrected Safe Region Policies",
        f"- strict current precision/recall: {strict_current['safe_cut_precision_phone_guard']} / {strict_current['eligible_safe_region_recall_all_buffers']}",
        f"- moderate current precision/recall: {moderate_current['safe_cut_precision_phone_guard']} / {moderate_current['eligible_safe_region_recall_all_buffers']}",
        f"- permissive current precision/recall: {permissive_current['safe_cut_precision_phone_guard']} / {permissive_current['eligible_safe_region_recall_all_buffers']}",
        "",
        "## Boundary Safety By Stage",
    ]
    for row in boundary_stage_rows:
        lines.append(
            f"- {row['stage']}: boundaries={row['boundary_count']}, inside_phone={row['inside_phone_count']}, "
            f"guard50={row['guard_50ms_violation_count']}, final_available={row['final_stage_available']}"
        )
    lines.extend(
        [
            "",
            "## Phone Overlap Severity",
            f"- accepted current cutpoints overlapping phones: {len(current_phone_overlap_rows)}",
            f"- used in candidate clips: {sum(_as_bool(row['used_in_candidate_clip']) for row in current_phone_overlap_rows)}",
            f"- final exported clips available: no",
            "",
            "## Disagreement Tables",
        ]
    )
    for name, file_path in sorted(disagreement_outputs.items()):
        lines.append(f"- `{name}`: `{file_path}`")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path
