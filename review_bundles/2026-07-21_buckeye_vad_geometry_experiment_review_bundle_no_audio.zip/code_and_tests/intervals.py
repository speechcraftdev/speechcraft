from __future__ import annotations

from typing import Any


def _validate_bounds(start_sec: float, end_sec: float) -> tuple[float, float]:
    if not (float("-inf") < start_sec < float("inf") and float("-inf") < end_sec < float("inf")):
        raise ValueError(f"interval bounds must be finite: {start_sec}, {end_sec}")
    if start_sec >= end_sec:
        raise ValueError(f"interval start must be < end: {start_sec}, {end_sec}")
    return start_sec, end_sec


def _bounds(row: dict[str, Any]) -> tuple[float, float]:
    return _validate_bounds(float(row["start_sec"]), float(row["end_sec"]))


def overlap_duration(
    left_start: float,
    left_end: float,
    right_start: float,
    right_end: float,
) -> float:
    _validate_bounds(left_start, left_end)
    _validate_bounds(right_start, right_end)
    return max(0.0, min(left_end, right_end) - max(left_start, right_start))


def intersects_positive(
    left_start: float,
    left_end: float,
    right_start: float,
    right_end: float,
    *,
    epsilon_sec: float,
) -> bool:
    return overlap_duration(left_start, left_end, right_start, right_end) > epsilon_sec


def merge_intervals(
    intervals: list[tuple[float, float]],
    *,
    epsilon_sec: float = 0.0,
) -> list[tuple[float, float]]:
    merged: list[list[float]] = []
    for start_sec, end_sec in sorted(_validate_bounds(float(start), float(end)) for start, end in intervals):
        if not merged or start_sec > (merged[-1][1] + epsilon_sec):
            merged.append([start_sec, end_sec])
        else:
            merged[-1][1] = max(merged[-1][1], end_sec)
    return [(start_sec, end_sec) for start_sec, end_sec in merged]


def total_duration(rows: list[dict[str, Any]]) -> float:
    return sum(end_sec - start_sec for start_sec, end_sec in merge_intervals([_bounds(row) for row in rows]))


def intersection_duration(
    left_intervals: list[tuple[float, float]],
    right_intervals: list[tuple[float, float]],
    *,
    epsilon_sec: float = 0.0,
) -> float:
    left = merge_intervals(left_intervals, epsilon_sec=epsilon_sec)
    right = merge_intervals(right_intervals, epsilon_sec=epsilon_sec)
    total = 0.0
    left_index = 0
    right_index = 0
    while left_index < len(left) and right_index < len(right):
        left_start, left_end = left[left_index]
        right_start, right_end = right[right_index]
        overlap_sec = max(0.0, min(left_end, right_end) - max(left_start, right_start))
        total += overlap_sec
        if left_end <= right_end:
            left_index += 1
        else:
            right_index += 1
    if total < -epsilon_sec:
        raise ValueError(f"union intersection duration must be >= 0, got {total}")
    return max(0.0, total)


def overlap_rows(
    left_rows: list[dict[str, Any]],
    right_rows: list[dict[str, Any]],
) -> float:
    return intersection_duration([_bounds(row) for row in left_rows], [_bounds(row) for row in right_rows])
