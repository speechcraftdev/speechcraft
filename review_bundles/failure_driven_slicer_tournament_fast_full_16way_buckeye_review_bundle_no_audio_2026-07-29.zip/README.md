# Failure-Driven Slicer Tournament

This bundle contains the tournament configuration manifest, code, tests, and any executed result summaries.

Important: most entrants require new detector or packer implementation before they can be validly run.
The runner records those as `not_implemented` instead of silently claiming baseline-equivalent results.

Executed configurations: 16

No audio, feature caches, model files, all-candidate dumps, or raw NeMo outputs are included.
