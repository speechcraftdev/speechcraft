# Geometry Blocker Fix Review

This bundle validates the A-vs-D geometry blocker in the fast failure-driven tournament runner.

What changed:
- Patched the fast runner so VAD frame caches are geometry-aware.
- Patched fallback cache materialization so it runs under config-specific VAD env, not the default A geometry.
- Added Buckeye eval_runs search roots so existing proper-D caches are reused instead of failing in environments without soundfile.

What is included:
- Patched tournament runner and policy/test files
- Full-cohort proper_D_baseline outputs
- Reference current_A_baseline tables from the completed 16-way fast Buckeye tournament
- A-vs-D cohort comparison tables

Key blocker outcome:
- A and D are no longer identical.
- Hash comparison shows divergence for emitted clips, selected boundaries, coverage, candidate support, boundary severity, and invariants.
- Macro comparison shows proper_D_baseline differs materially from current_A_baseline.

Important comparison files:
- comparison/a_vs_d_hash_comparison.csv
- comparison/a_vs_d_macro_comparison.csv
- comparison/a_vs_d_speaker_metric_deltas.csv
