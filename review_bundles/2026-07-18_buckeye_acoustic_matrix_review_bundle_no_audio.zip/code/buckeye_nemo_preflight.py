from __future__ import annotations

import csv
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from collections import defaultdict
from pathlib import Path
from typing import Any

from .buckeye import inspect_wav
from .buckeye_safecut_benchmark import _read_csv
from .io_utils import write_csv, write_json
from .nemo_buckeye_audit import build_reference_masks, load_speaker_regions, score_cluster, _duration, _merge, Interval
from .repaired_buckeye_benchmark import build_raw_nemo_target_buffers, load_nemo_cluster_mapping, run_repaired_slicer_dry_run


AMBIGUOUS_TARGET_RATIO = 0.85
AMBIGUOUS_TARGET_MIN_SEC = 5.0
LOW_TARGET_OVERLAP_SEC = 30.0
HIGH_INTERVIEWER_LEAKAGE_RATE = 0.10
HIGH_INTERVIEWER_LEAKAGE_SEC = 5.0
DISK_ABORT_FLOOR_BYTES = 20 * 1024 * 1024 * 1024


def _sha256_file(path: Path, *, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return f"sha256:{digest.hexdigest()}"


def _disk_free_bytes(path: Path) -> int:
    return shutil.disk_usage(path).free


def _dir_size_bytes(path: Path) -> int:
    total = 0
    if not path.exists():
        return 0
    for child in path.rglob("*"):
        if child.is_file():
            total += child.stat().st_size
    return total


def _import_speechcraft_dataset():
    dataset_root = Path("/home/aaravthegreat/Projects/speechcraft/workers/dataset")
    if str(dataset_root) not in sys.path:
        sys.path.insert(0, str(dataset_root))
    from speechcraft_dataset.run import config_hash, default_config, run_audio_variants, run_prepare_sources, runtime_versions
    from speechcraft_dataset.vad import run_silero_vad
    from speechcraft_dataset.diarization import run_diarization

    return {
        "config_hash": config_hash,
        "default_config": default_config,
        "run_prepare_sources": run_prepare_sources,
        "run_audio_variants": run_audio_variants,
        "run_silero_vad": run_silero_vad,
        "run_diarization": run_diarization,
        "runtime_versions": runtime_versions,
    }


def build_included_recording_manifest(
    *,
    normalized_root: Path,
    speaker_ids: list[str],
    out_csv: Path | None = None,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    all_included: set[tuple[str, str]] = set()
    all_excluded: set[tuple[str, str]] = set()
    filesystem_ids: dict[str, set[str]] = {}

    for speaker_id in speaker_ids:
        speaker_dir = normalized_root / speaker_id
        reconciliation_rows = _read_csv(speaker_dir / "reference_reconciliation.csv")
        excluded_rows = _read_csv(speaker_dir / "excluded_recordings.csv")
        phone_rows = _read_csv(speaker_dir / "reference_phones.csv")
        word_rows = _read_csv(speaker_dir / "reference_words.csv")
        uncertainty_rows = _read_csv(speaker_dir / "uncertainty_masks.csv")
        masks = build_reference_masks(normalized_root, speaker_id)
        excluded_ids = {str(row["recording_id"]) for row in excluded_rows}
        included_ids = {str(row["recording_id"]) for row in reconciliation_rows}
        if not included_ids:
            raise ValueError(f"included set is empty for {speaker_id}")
        if included_ids & excluded_ids:
            raise ValueError(f"included/excluded overlap for {speaker_id}: {sorted(included_ids & excluded_ids)}")

        raw_speaker_root = Path(phone_rows[0]["audio_path"]).parent.parent if phone_rows else None
        fs_ids: set[str] = set()
        if raw_speaker_root is not None:
            for part_dir in sorted(path for path in raw_speaker_root.iterdir() if path.is_dir()):
                recording_id = part_dir.name
                if any((part_dir / f"{recording_id}{suffix}").exists() for suffix in (".wav", ".words", ".phones", ".phons")):
                    fs_ids.add(recording_id)
        filesystem_ids[speaker_id] = fs_ids
        if fs_ids != included_ids | excluded_ids:
            missing = sorted(fs_ids - (included_ids | excluded_ids))
            extra = sorted((included_ids | excluded_ids) - fs_ids)
            raise ValueError(f"filesystem/include-exclude mismatch for {speaker_id}: missing={missing} extra={extra}")

        uncertainty_by_recording: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for row in uncertainty_rows:
            uncertainty_by_recording[str(row["recording_id"])].append(row)
        phone_path_by_recording = {str(row["recording_id"]): str(row["annotation_path"]) for row in phone_rows}
        word_path_by_recording = {str(row["recording_id"]): str(row["annotation_path"]) for row in word_rows}
        audio_path_by_recording = {str(row["recording_id"]): str(row["audio_path"]) for row in phone_rows}

        for recon in reconciliation_rows:
            recording_id = str(recon["recording_id"])
            wav_path = Path(audio_path_by_recording[recording_id])
            phone_path = Path(phone_path_by_recording[recording_id])
            word_path = Path(word_path_by_recording[recording_id])
            if not wav_path.exists():
                raise FileNotFoundError(f"missing WAV for {speaker_id}/{recording_id}: {wav_path}")
            if not phone_path.exists() or not word_path.exists():
                raise FileNotFoundError(f"missing references for {speaker_id}/{recording_id}")
            info = inspect_wav(wav_path)
            target_sec = round(_duration(masks[recording_id]["target_speech"]), 6)
            interviewer_sec = round(_duration(masks[recording_id]["interviewer"]), 6)
            row = {
                "speaker_id": speaker_id,
                "recording_id": recording_id,
                "wav_path": str(wav_path),
                "wav_size_bytes": wav_path.stat().st_size,
                "wav_duration_sec": round(info.duration_sec, 6),
                "sample_rate_hz": info.sample_rate,
                "channel_count": info.channels,
                "audio_hash": _sha256_file(wav_path),
                "normalized_phone_path": str(phone_path),
                "normalized_word_path": str(word_path),
                "uncertainty_mask_path": str((speaker_dir / "uncertainty_masks.csv").resolve()),
                "reference_target_speech_sec": target_sec,
                "reference_interviewer_sec": interviewer_sec,
                "uncertainty_interval_count": len(uncertainty_by_recording.get(recording_id, [])),
                "uncertain_reference_sec": round(sum(float(r["duration_sec"]) for r in uncertainty_by_recording.get(recording_id, [])), 6),
            }
            rows.append(row)
            all_included.add((speaker_id, recording_id))
        for row in excluded_rows:
            all_excluded.add((speaker_id, str(row["recording_id"])))

    if all_included & all_excluded:
        raise ValueError("global included/excluded overlap detected")
    if len({(row["speaker_id"], row["recording_id"]) for row in rows}) != len(rows):
        raise ValueError("duplicate recording ids in included manifest")
    if out_csv is not None:
        write_csv(out_csv, rows, fieldnames=list(rows[0].keys()))
    return rows


def freeze_nemo_config(
    *,
    source_wavs: list[Path],
    template_config_path: Path,
    out_json: Path,
    out_hash_json: Path,
) -> dict[str, Any]:
    worker = _import_speechcraft_dataset()
    template = json.loads(template_config_path.read_text(encoding="utf-8"))
    config = worker["default_config"](source_wavs, single_speaker=False, target_speaker_label="speaker_0")
    config.update({k: v for k, v in template.items() if k not in {"source_wavs", "target_speaker_label", "config_hash"}})
    config["source_wavs"] = [str(path.resolve()) for path in source_wavs]
    config["target_speaker_label"] = "speaker_0"
    config["config_hash"] = worker["config_hash"](config)
    runtime = worker["runtime_versions"]()
    git_commit = subprocess.run(["git", "rev-parse", "HEAD"], cwd="/home/aaravthegreat/Projects/speechcraft", capture_output=True, text=True, check=False).stdout.strip()
    git_status = subprocess.run(["git", "status", "--porcelain"], cwd="/home/aaravthegreat/Projects/speechcraft", capture_output=True, text=True, check=False).stdout.splitlines()
    payload = {
        "config": config,
        "runtime_versions": runtime,
        "git_commit": git_commit,
        "git_dirty": bool(git_status),
        "git_status": git_status,
    }
    write_json(out_json, payload)
    write_json(out_hash_json, {
        "config_hash": config["config_hash"],
        "config_file_hash": _sha256_file(out_json),
        "git_commit": git_commit,
        "git_dirty": bool(git_status),
    })
    return payload


def run_nemo_pipeline_for_manifest(
    *,
    run_root: Path,
    manifest_rows: list[dict[str, Any]],
    config: dict[str, Any],
) -> dict[str, Any]:
    worker = _import_speechcraft_dataset()
    if run_root.exists():
        shutil.rmtree(run_root)
    (run_root / "artifacts").mkdir(parents=True, exist_ok=True)
    (run_root / "logs").mkdir(parents=True, exist_ok=True)
    write_json(run_root / "config.json", config)
    write_json(run_root / "runtime_versions.json", worker["runtime_versions"]())
    free_before = _disk_free_bytes(run_root)
    stage_sizes: list[dict[str, Any]] = []
    peak_dir_size = 0
    peak_temp_growth = 0

    def mark(stage_name: str) -> None:
        nonlocal peak_dir_size, peak_temp_growth
        dir_size = _dir_size_bytes(run_root)
        peak_dir_size = max(peak_dir_size, dir_size)
        peak_temp_growth = max(peak_temp_growth, free_before - _disk_free_bytes(run_root))
        stage_sizes.append({"stage": stage_name, "run_root_size_bytes": dir_size, "free_bytes": _disk_free_bytes(run_root)})

    worker["run_prepare_sources"](run_root, config)
    mark("source_audio")
    source_manifest = json.loads((run_root / "artifacts" / "source_audio_manifest.json").read_text(encoding="utf-8"))
    input_ids = [str(row["recording_id"]) for row in manifest_rows]
    manifest_ids = [str(row["source_recording_id"]) for row in source_manifest["sources"]]
    if sorted(input_ids) != sorted(manifest_ids):
        raise ValueError(f"NeMo input IDs mismatch included IDs: expected={sorted(input_ids)} got={sorted(manifest_ids)}")
    worker["run_audio_variants"](run_root, config)
    mark("audio_variants")
    worker["run_silero_vad"](run_root, config)
    mark("vad")
    worker["run_diarization"](run_root, config)
    mark("diarization")

    return {
        "run_root": str(run_root),
        "stage_sizes": stage_sizes,
        "peak_run_root_size_bytes": peak_dir_size,
        "peak_temp_growth_bytes": peak_temp_growth,
        "free_bytes_after": _disk_free_bytes(run_root),
    }


def build_mapping_diagnostics(
    *,
    speaker_id: str,
    run_root: Path,
    normalized_root: Path,
    out_dir: Path,
) -> dict[str, Any]:
    masks_by_recording = build_reference_masks(normalized_root, speaker_id)
    regions = load_speaker_regions(run_root)
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in regions:
        grouped[(str(row["recording_id"]), str(row["speaker_id"]))].append(row)

    cluster_rows: list[dict[str, Any]] = []
    benchmark_mapping_rows: list[dict[str, Any]] = []
    for (recording_id, speaker), rows in sorted(grouped.items()):
        stats = score_cluster(rows, masks_by_recording)
        target_overlap = float(stats["target_overlap_sec"])
        interviewer_overlap = float(stats["interviewer_overlap_sec"])
        target_minus_interviewer = target_overlap - interviewer_overlap
        target_overlap_rate = target_overlap / max(1e-9, _duration(masks_by_recording[recording_id]["target_speech"]))
        interviewer_leakage_rate = interviewer_overlap / max(1e-9, sum(Interval(float(r["start_sec"]), float(r["end_sec"])).duration for r in rows))
        cluster_rows.append({
            "speaker_id": speaker_id,
            "recording_id": recording_id,
            "nemo_cluster": speaker,
            "target_speech_overlap_sec": round(target_overlap, 6),
            "interviewer_overlap_sec": round(interviewer_overlap, 6),
            "target_overlap_rate": round(target_overlap_rate, 6),
            "interviewer_leakage_rate": round(interviewer_leakage_rate, 6),
            "target_minus_interviewer_score": round(target_minus_interviewer, 6),
            "assigned_role": stats["assigned_role"],
            "mapping_confidence": round(float(stats["mapping_confidence"]), 6),
        })
        benchmark_mapping_rows.append(
            {
                "dataset_id": speaker_id,
                "recording_id": recording_id,
                "nemo_cluster": speaker,
                "assigned_role": stats["assigned_role"],
                "mapping_confidence": round(float(stats["mapping_confidence"]), 6),
            }
        )

    recording_rows: list[dict[str, Any]] = []
    for recording_id in sorted({row["recording_id"] for row in cluster_rows}):
        rows = [row for row in cluster_rows if row["recording_id"] == recording_id]
        ordered = sorted(rows, key=lambda row: (float(row["target_speech_overlap_sec"]), float(row["target_minus_interviewer_score"])), reverse=True)
        top = ordered[0] if ordered else None
        second = ordered[1] if len(ordered) > 1 else None
        ambiguous_reasons: list[str] = []
        if top is not None and second is not None:
            if float(second["target_speech_overlap_sec"]) >= AMBIGUOUS_TARGET_MIN_SEC and float(second["target_speech_overlap_sec"]) >= AMBIGUOUS_TARGET_RATIO * float(top["target_speech_overlap_sec"]):
                ambiguous_reasons.append("top_two_target_clusters_close")
        if top is not None:
            if float(top["target_speech_overlap_sec"]) < LOW_TARGET_OVERLAP_SEC:
                ambiguous_reasons.append("low_target_recovery")
            if float(top["interviewer_leakage_rate"]) > HIGH_INTERVIEWER_LEAKAGE_RATE or float(top["interviewer_overlap_sec"]) > HIGH_INTERVIEWER_LEAKAGE_SEC:
                ambiguous_reasons.append("high_interviewer_leakage")
        target_clusters = [row for row in rows if row["assigned_role"] == "target"]
        if len(target_clusters) > 1:
            ambiguous_reasons.append("multiple_target_clusters")
        recording_rows.append({
            "speaker_id": speaker_id,
            "recording_id": recording_id,
            "primary_target_cluster": top["nemo_cluster"] if top else "",
            "primary_target_overlap_sec": top["target_speech_overlap_sec"] if top else "",
            "primary_interviewer_overlap_sec": top["interviewer_overlap_sec"] if top else "",
            "primary_mapping_confidence": top["mapping_confidence"] if top else "",
            "target_cluster_count": len(target_clusters),
            "cluster_count": len(rows),
            "ambiguous_mapping": bool(ambiguous_reasons),
            "ambiguous_reasons": "|".join(ambiguous_reasons),
        })

    out_dir.mkdir(parents=True, exist_ok=True)
    write_csv(out_dir / "nemo_target_cluster_mapping.csv", cluster_rows, fieldnames=list(cluster_rows[0].keys()) if cluster_rows else ["speaker_id"])
    write_csv(out_dir / "nemo_mapping_by_recording.csv", recording_rows, fieldnames=list(recording_rows[0].keys()) if recording_rows else ["speaker_id"])
    write_csv(
        out_dir / "benchmark_cluster_mapping.csv",
        benchmark_mapping_rows,
        fieldnames=list(benchmark_mapping_rows[0].keys()) if benchmark_mapping_rows else ["dataset_id"],
    )
    return {
        "cluster_rows": cluster_rows,
        "benchmark_mapping_rows": benchmark_mapping_rows,
        "recording_rows": recording_rows,
        "ambiguous_recording_ids": [row["recording_id"] for row in recording_rows if row["ambiguous_mapping"]],
    }


def choose_review_timestamps(cluster_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    review_rows: list[dict[str, Any]] = []
    for row in cluster_rows[:20]:
        review_rows.append({
            "speaker_id": row["speaker_id"],
            "recording_id": row["recording_id"],
            "nemo_cluster": row["nemo_cluster"],
            "review_reason": "cluster_mapping_review",
            "target_overlap_sec": row["target_speech_overlap_sec"],
            "interviewer_overlap_sec": row["interviewer_overlap_sec"],
            "mapping_confidence": row["mapping_confidence"],
        })
    return review_rows


def run_speaker_smoke_benchmark(
    *,
    eval_run: Path,
    normalized_speaker_dir: Path,
    cluster_mapping_csv: Path,
    out_root: Path,
) -> list[Path]:
    shared_cache_root = out_root / "shared_cache"
    run_dirs = []
    for detector_name in ("vad_percentile_rms", "uniform_grid_250ms"):
        run_dirs.append(
            run_repaired_slicer_dry_run(
                eval_run=eval_run,
                normalized_speaker_dir=normalized_speaker_dir,
                cluster_mapping_csv=cluster_mapping_csv,
                out_root=out_root,
                detector_name=detector_name,
                shared_cache_root=shared_cache_root,
                write_heavy_tables=False,
            )
        )
    return run_dirs
