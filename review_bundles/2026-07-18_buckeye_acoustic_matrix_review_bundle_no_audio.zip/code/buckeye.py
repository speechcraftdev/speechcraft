from __future__ import annotations

import csv
import re
import wave
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .io_utils import write_csv


HEADER_SENTINEL = "#"
ANNOTATION_TOLERANCE_SEC = 0.100
TIMELINE_WARN_GAP_SEC = 0.010
BOUNDARY_EPSILON_SEC = 0.001


@dataclass(frozen=True)
class AudioInfo:
    sample_rate: int
    channels: int
    bits_per_sample: int
    duration_sec: float


@dataclass(frozen=True)
class BuckeyePair:
    speaker_id: str
    recording_id: str
    wav_path: Path
    words_path: Path
    phones_path: Path
    phone_extension: str
    log_path: Path | None
    txt_path: Path | None


@dataclass(frozen=True)
class ParsedPhoneLabel:
    raw_label: str
    base_label: str
    annotation_suffix: str
    stress_or_variant_marker: str


_WORDS_ROW_RE = re.compile(r"^\s*([0-9]+(?:\.[0-9]+)?)\s+(\d+)\s+(.*?)\s*$")
_PHONES_ROW_RE = re.compile(r"^\s*([0-9]+(?:\.[0-9]+)?)\s+(\d+)\s+(.*?)\s*$")
_PHONE_SUFFIX_SPLIT_RE = re.compile(r"^(?P<base>[^;]+?)(?P<suffix>\s*;.*)?\s*$")
_PHONE_PLUS1_RE = re.compile(r"^(?P<base>[A-Za-z]+)\+1$")


MANUAL_SPEECH_PHONE_WHITELIST = {
    "aa", "aan", "ae", "aen", "ah", "ahn", "ao", "aon",
    "aw", "awn", "ay", "ayn", "eh", "ehn", "el", "em",
    "en", "er", "ern", "ey", "eyn", "ih", "ihn", "iy",
    "iyn", "ow", "own", "oy", "oyn", "uh", "uhn", "uw", "uwn",
    "b", "ch", "d", "dh", "dx", "f", "g", "hh", "jh",
    "k", "l", "m", "n", "ng", "p", "r", "s", "sh",
    "t", "th", "tq", "v", "w", "y", "z", "zh",
}

# Observed in Buckeye `.phones` data for s01-s04 and treated as genuine speech phones.
OBSERVED_SPEECH_PHONE_ADDITIONS = {
    "nx",   # nasal flap variant
    "eng",  # observed velar nasal variant
}

# Verified against the raw `.phones` suffix inventory observed in s01-s04.
ALLOWED_PHONE_SUFFIXES = frozenset({
    "",
    ";",
    "; *",
    "; *x",
    "; *qqqqa",
})

VERIFIED_PHONE_VARIANT_MARKERS = frozenset({"+1"})

SPEECH_PHONE_WHITELIST = frozenset(MANUAL_SPEECH_PHONE_WHITELIST | OBSERVED_SPEECH_PHONE_ADDITIONS)

SILENCE_PHONE_LABELS = frozenset({"SIL", "PAUSE"})
VOCNOISE_PHONE_LABELS = frozenset({"VOCNOISE"})
NOISE_PHONE_LABELS = frozenset({"NOISE"})
LAUGHTER_PHONE_LABELS = frozenset({"LAUGH"})
INTERVIEWER_PHONE_LABELS = frozenset({"IVER"})
BOUNDARY_PHONE_LABELS = frozenset({"{B_TRANS}", "{E_TRANS}"})
OTHER_PHONE_LABELS = frozenset({
    "UNKNOWN",
    "<EXCLUDE-NAME>",
})

SILENCE_WORD_LABELS = frozenset({"<SIL>", "<PAUSE>"})
WORD_EVENT_PREFIX_TO_TYPE: tuple[tuple[str, str], ...] = (
    ("<IVER", "interviewer"),
    ("<LAUGH", "laughter"),
    ("<VOCNOISE", "vocnoise"),
    ("<NOISE", "noise"),
    ("<BREATH", "breath"),
    ("<CUTOFF", "cutoff"),
    ("<COUGH", "other_annotation"),
    ("<ERROR", "other_annotation"),
    ("<UNKNOWN", "uncertain"),
    ("<EXCLUDE", "other_annotation"),
    ("<EXT-", "other_annotation"),
    ("<EXT_", "other_annotation"),
    ("<HES-", "other_annotation"),
    ("<NAME", "other_annotation"),
    ("<ADDRESS", "other_annotation"),
    ("<PHONE", "other_annotation"),
    ("<SSN", "other_annotation"),
    ("<ZIP", "other_annotation"),
    ("{B_TRANS}", "boundary_marker"),
    ("{E_TRANS}", "boundary_marker"),
)

PHONE_CLASS_ORDER = (
    "speech",
    "silence",
    "laughter",
    "vocnoise",
    "noise",
    "interviewer",
    "boundary_marker",
    "other_annotation",
    "unknown",
)


def inspect_wav(path: Path) -> AudioInfo:
    with wave.open(str(path), "rb") as handle:
        sample_rate = int(handle.getframerate())
        channels = int(handle.getnchannels())
        sample_width = int(handle.getsampwidth())
        frames = int(handle.getnframes())
    return AudioInfo(
        sample_rate=sample_rate,
        channels=channels,
        bits_per_sample=sample_width * 8,
        duration_sec=frames / sample_rate,
    )


def find_recording_pairs(extracted_speaker_root: Path) -> list[BuckeyePair]:
    if not extracted_speaker_root.exists():
        raise ValueError(f"speaker root does not exist: {extracted_speaker_root}")
    speaker_id = extracted_speaker_root.name
    pairs: list[BuckeyePair] = []
    seen_recordings: set[str] = set()
    for part_dir in sorted(path for path in extracted_speaker_root.iterdir() if path.is_dir()):
        if not _looks_like_recording_dir(part_dir):
            continue
        recording_id = part_dir.name
        if recording_id in seen_recordings:
            raise ValueError(f"duplicate recording id: {recording_id}")
        seen_recordings.add(recording_id)
        wav_path = part_dir / f"{recording_id}.wav"
        words_path = part_dir / f"{recording_id}.words"
        phones_path, phone_extension = _resolve_phone_path(part_dir, recording_id)
        log_path = part_dir / f"{recording_id}.log"
        txt_path = part_dir / f"{recording_id}.txt"
        missing = [
            name
            for name, path in (
                (wav_path.name, wav_path),
                (words_path.name, words_path),
                (phones_path.name if phones_path is not None else f"{recording_id}.phones|.phons", phones_path),
            )
            if path is None or not path.exists()
        ]
        if missing:
            raise ValueError(f"missing WAV/word/phone pair for {recording_id}: {missing}")
        pairs.append(
            BuckeyePair(
                speaker_id=speaker_id,
                recording_id=recording_id,
                wav_path=wav_path,
                words_path=words_path,
                phones_path=phones_path,
                phone_extension=phone_extension,
                log_path=log_path if log_path.exists() else None,
                txt_path=txt_path if txt_path.exists() else None,
            )
        )
    if not pairs:
        raise ValueError(f"no recording directories found under {extracted_speaker_root}")
    return pairs


def _looks_like_recording_dir(part_dir: Path) -> bool:
    recording_id = part_dir.name
    return any(
        (part_dir / filename).exists()
        for filename in (
            f"{recording_id}.wav",
            f"{recording_id}.words",
            f"{recording_id}.phones",
            f"{recording_id}.phons",
        )
    )


def _resolve_phone_path(part_dir: Path, recording_id: str) -> tuple[Path | None, str]:
    phones_path = part_dir / f"{recording_id}.phones"
    phons_path = part_dir / f"{recording_id}.phons"
    if phones_path.exists() and phons_path.exists():
        raise ValueError(f"ambiguous phone annotation files for {recording_id}: both .phones and .phons exist")
    if phones_path.exists():
        return phones_path, ".phones"
    if phons_path.exists():
        return phons_path, ".phons"
    return None, ""


def _iter_annotation_lines(path: Path) -> list[str]:
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    try:
        start_index = lines.index(HEADER_SENTINEL) + 1
    except ValueError as exc:
        raise ValueError(f"{path} is missing header sentinel '#'") from exc
    return [line for line in lines[start_index:] if line.strip()]


def parse_words_file(path: Path) -> list[dict[str, Any]]:
    rows, _ = parse_words_file_with_issues(path)
    return rows


def parse_words_file_with_issues(path: Path) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    rows: list[dict[str, Any]] = []
    issues: list[dict[str, Any]] = []
    previous_end = 0.0
    seen_rows: set[tuple[float, str]] = set()
    for row_index, line in enumerate(_iter_annotation_lines(path)):
        parts = [part.strip() for part in line.split(";")]
        if not parts:
            continue
        match = _WORDS_ROW_RE.match(parts[0])
        if not match:
            raise ValueError(f"{path} malformed .words row {row_index}: {line!r}")
        end_sec = float(match.group(1))
        raw_label = match.group(3).strip()
        if end_sec < 0.0:
            raise ValueError(f"{path} row {row_index} has negative timestamp: {end_sec}")
        duplicate_key = (end_sec, raw_label)
        if duplicate_key in seen_rows:
            raise ValueError(f"{path} row {row_index} duplicates earlier word row: {duplicate_key}")
        seen_rows.add(duplicate_key)
        interval = _reconstruct_interval(path, row_index, previous_end, end_sec, raw_label=raw_label, strict_zero=False)
        if interval is None:
            issues.append({
                "table": "words",
                "row_index": row_index,
                "raw_label": raw_label,
                "end_sec": end_sec,
                "issue_type": "zero_length_interval_dropped",
            })
            continue
        start_sec, end_sec = interval
        previous_end = end_sec
        pos_tag = parts[3].strip() if len(parts) >= 4 else ""
        normalized_label = normalize_word_label(raw_label)
        event_type = classify_word_event_type(raw_label)
        rows.append(
            {
                "row_index": row_index,
                "raw_label": raw_label,
                "normalized_label": normalized_label,
                "start_sec": start_sec,
                "end_sec": end_sec,
                "duration_sec": round(end_sec - start_sec, 6),
                "pos_tag": pos_tag,
                "is_lexical_word": is_lexical_word_label(raw_label, pos_tag=pos_tag),
                "is_event": event_type is not None,
                "event_type": event_type or "",
            }
        )
    return rows, issues


def parse_phones_file(path: Path) -> list[dict[str, Any]]:
    rows, _ = parse_phones_file_with_issues(path)
    return rows


def parse_phones_file_with_issues(path: Path) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    rows: list[dict[str, Any]] = []
    issues: list[dict[str, Any]] = []
    previous_end = 0.0
    seen_rows: set[tuple[float, str]] = set()
    for row_index, line in enumerate(_iter_annotation_lines(path)):
        match = _PHONES_ROW_RE.match(line)
        if not match:
            raise ValueError(f"{path} malformed .phones row {row_index}: {line!r}")
        end_sec = float(match.group(1))
        raw_label = match.group(3).strip()
        if end_sec < 0.0:
            raise ValueError(f"{path} row {row_index} has negative timestamp: {end_sec}")
        if raw_label == "":
            issues.append({
                "table": "phones",
                "row_index": row_index,
                "raw_label": raw_label,
                "end_sec": end_sec,
                "issue_type": "empty_phone_label_dropped",
            })
            continue
        duplicate_key = (end_sec, raw_label)
        if duplicate_key in seen_rows:
            raise ValueError(f"{path} row {row_index} duplicates earlier phone row: {duplicate_key}")
        seen_rows.add(duplicate_key)
        parsed_label = parse_phone_label(raw_label)
        interval = _reconstruct_interval(path, row_index, previous_end, end_sec, raw_label=raw_label, strict_zero=False)
        if interval is None:
            issues.append({
                "table": "phones",
                "row_index": row_index,
                "raw_label": raw_label,
                "end_sec": end_sec,
                "issue_type": "zero_length_interval_dropped",
            })
            continue
        start_sec, end_sec = interval
        previous_end = end_sec
        phone_class = classify_phone_class(raw_label)
        normalized_label = normalize_phone_label(raw_label)
        is_speech_phone = phone_class == "speech"
        rows.append(
            {
                "row_index": row_index,
                "raw_label": raw_label,
                "base_label": parsed_label.base_label,
                "annotation_suffix": parsed_label.annotation_suffix,
                "stress_or_variant_marker": parsed_label.stress_or_variant_marker,
                "normalized_label": normalized_label,
                "phone_class": phone_class,
                "start_sec": start_sec,
                "end_sec": end_sec,
                "duration_sec": round(end_sec - start_sec, 6),
                "is_speech_phone": is_speech_phone,
                "is_silence_or_event": not is_speech_phone,
            }
        )
    return rows, issues


def _policy_tables_dir(readiness_audit_root: Path | None) -> Path | None:
    if readiness_audit_root is None:
        return None
    tables_dir = readiness_audit_root / "tables"
    if tables_dir.exists():
        return tables_dir
    return readiness_audit_root if readiness_audit_root.exists() else None


def _load_reviewed_policy(
    *,
    readiness_audit_root: Path | None,
    speaker_id: str,
) -> dict[str, Any]:
    tables_dir = _policy_tables_dir(readiness_audit_root)
    if tables_dir is None:
        return {
            "excluded_recordings": {},
            "phone_uncertainty_by_recording": defaultdict(dict),
            "word_corrections_by_recording": defaultdict(dict),
            "phone_corrections_by_recording": defaultdict(dict),
        }
    excluded_rows = []
    excluded_path = tables_dir / "excluded_recordings.csv"
    if excluded_path.exists():
        with excluded_path.open() as handle:
            excluded_rows = [row for row in csv.DictReader(handle) if row["speaker_id"] == speaker_id]
    uncertainty_rows = []
    uncertainty_path = tables_dir / "uncertainty_intervals.csv"
    if uncertainty_path.exists():
        with uncertainty_path.open() as handle:
            uncertainty_rows = [
                row for row in csv.DictReader(handle)
                if row["speaker_id"] == speaker_id and row["table"] == "phones"
            ]
    correction_rows = []
    correction_path = tables_dir / "correction_manifest.csv"
    if correction_path.exists():
        with correction_path.open() as handle:
            correction_rows = [row for row in csv.DictReader(handle) if row["speaker_id"] == speaker_id]

    phone_uncertainty_by_recording: dict[str, dict[int, dict[str, Any]]] = defaultdict(dict)
    for row in uncertainty_rows:
        phone_uncertainty_by_recording[str(row["recording_id"])][int(row["row_index"])] = row
    phone_corrections_by_recording: dict[str, dict[int, dict[str, Any]]] = defaultdict(dict)
    word_corrections_by_recording: dict[str, dict[int, dict[str, Any]]] = defaultdict(dict)
    for row in correction_rows:
        target = phone_corrections_by_recording if row["table"] == "phones" else word_corrections_by_recording
        target[str(row["recording_id"])][int(row["row_index"])] = row
    return {
        "excluded_recordings": {str(row["recording_id"]): row for row in excluded_rows},
        "phone_uncertainty_by_recording": phone_uncertainty_by_recording,
        "word_corrections_by_recording": word_corrections_by_recording,
        "phone_corrections_by_recording": phone_corrections_by_recording,
    }


def _parse_words_file_with_policy(
    path: Path,
    *,
    correction_rows_by_index: dict[int, dict[str, Any]] | None = None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    rows: list[dict[str, Any]] = []
    issues: list[dict[str, Any]] = []
    correction_rows: list[dict[str, Any]] = []
    previous_end = 0.0
    seen_rows: set[tuple[float, str]] = set()
    for row_index, line in enumerate(_iter_annotation_lines(path)):
        parts = [part.strip() for part in line.split(";")]
        if not parts:
            continue
        match = _WORDS_ROW_RE.match(parts[0])
        if not match:
            raise ValueError(f"{path} malformed .words row {row_index}: {line!r}")
        original_end_sec = float(match.group(1))
        end_sec = original_end_sec
        raw_label = match.group(3).strip()
        if row_index in (correction_rows_by_index or {}):
            correction = correction_rows_by_index[row_index]
            end_sec = float(correction["corrected_value"])
            correction_rows.append(
                {
                    "speaker_id": path.parent.parent.name,
                    "recording_id": path.stem,
                    "table": "words",
                    "row_index": row_index,
                    "raw_value": correction["raw_value"],
                    "corrected_value": correction["corrected_value"],
                    "reason": correction["reason"],
                    "source_evidence": correction["source_evidence"],
                }
            )
        if end_sec < 0.0:
            raise ValueError(f"{path} row {row_index} has negative timestamp: {end_sec}")
        duplicate_key = (end_sec, raw_label)
        if duplicate_key in seen_rows:
            raise ValueError(f"{path} row {row_index} duplicates earlier word row: {duplicate_key}")
        seen_rows.add(duplicate_key)
        interval = _reconstruct_interval(path, row_index, previous_end, end_sec, raw_label=raw_label, strict_zero=False)
        if interval is None:
            issues.append({"table": "words", "row_index": row_index, "raw_label": raw_label, "end_sec": end_sec, "issue_type": "zero_length_interval_dropped"})
            continue
        start_sec, end_sec = interval
        previous_end = end_sec
        pos_tag = parts[3].strip() if len(parts) >= 4 else ""
        normalized_label = normalize_word_label(raw_label)
        event_type = classify_word_event_type(raw_label)
        rows.append(
            {
                "row_index": row_index,
                "raw_label": raw_label,
                "normalized_label": normalized_label,
                "start_sec": start_sec,
                "end_sec": end_sec,
                "duration_sec": round(end_sec - start_sec, 6),
                "original_end_sec": original_end_sec,
                "correction_reason": correction_rows_by_index[row_index]["reason"] if row_index in (correction_rows_by_index or {}) else "",
                "pos_tag": pos_tag,
                "is_lexical_word": is_lexical_word_label(raw_label, pos_tag=pos_tag),
                "is_event": event_type is not None,
                "event_type": event_type or "",
            }
        )
    return rows, issues, correction_rows


def _parse_phones_file_with_policy(
    path: Path,
    *,
    uncertainty_rows_by_index: dict[int, dict[str, Any]] | None = None,
    correction_rows_by_index: dict[int, dict[str, Any]] | None = None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    rows: list[dict[str, Any]] = []
    issues: list[dict[str, Any]] = []
    uncertainty_rows: list[dict[str, Any]] = []
    correction_rows: list[dict[str, Any]] = []
    previous_end = 0.0
    seen_rows: set[tuple[float, str]] = set()
    for row_index, line in enumerate(_iter_annotation_lines(path)):
        match = _PHONES_ROW_RE.match(line)
        if not match:
            raise ValueError(f"{path} malformed .phones row {row_index}: {line!r}")
        original_end_sec = float(match.group(1))
        end_sec = original_end_sec
        raw_label = match.group(3).strip()
        if row_index in (correction_rows_by_index or {}):
            correction = correction_rows_by_index[row_index]
            end_sec = float(correction["corrected_value"])
            correction_rows.append(
                {
                    "speaker_id": path.parent.parent.name,
                    "recording_id": path.stem,
                    "table": "phones",
                    "row_index": row_index,
                    "raw_value": correction["raw_value"],
                    "corrected_value": correction["corrected_value"],
                    "reason": correction["reason"],
                    "source_evidence": correction["source_evidence"],
                }
            )
        if end_sec < 0.0:
            raise ValueError(f"{path} row {row_index} has negative timestamp: {end_sec}")
        interval = _reconstruct_interval(path, row_index, previous_end, end_sec, raw_label=raw_label, strict_zero=False)
        if interval is None:
            issues.append({"table": "phones", "row_index": row_index, "raw_label": raw_label, "end_sec": end_sec, "issue_type": "zero_length_interval_dropped"})
            continue
        start_sec, end_sec = interval
        previous_end = end_sec
        if row_index in (uncertainty_rows_by_index or {}):
            policy_row = uncertainty_rows_by_index[row_index]
            uncertainty_rows.append(
                {
                    "speaker_id": path.parent.parent.name,
                    "recording_id": path.stem,
                    "table": "phones",
                    "row_index": row_index,
                    "raw_label": raw_label,
                    "start_sec": round(start_sec, 6),
                    "end_sec": round(end_sec, 6),
                    "duration_sec": round(end_sec - start_sec, 6),
                    "reason": policy_row["reason"],
                }
            )
            continue
        if raw_label == "":
            raise ValueError(f"{path} row {row_index} has empty phone label outside uncertainty policy")
        duplicate_key = (end_sec, raw_label)
        if duplicate_key in seen_rows:
            raise ValueError(f"{path} row {row_index} duplicates earlier phone row: {duplicate_key}")
        seen_rows.add(duplicate_key)
        parsed_label = parse_phone_label(raw_label)
        phone_class = classify_phone_class(raw_label)
        if phone_class == "unknown":
            raise ValueError(f"{path} row {row_index} has unknown phone label outside uncertainty policy: {raw_label!r}")
        rows.append(
            {
                "row_index": row_index,
                "raw_label": raw_label,
                "base_label": parsed_label.base_label,
                "annotation_suffix": parsed_label.annotation_suffix,
                "stress_or_variant_marker": parsed_label.stress_or_variant_marker,
                "normalized_label": normalize_phone_label(raw_label),
                "phone_class": phone_class,
                "start_sec": start_sec,
                "end_sec": end_sec,
                "duration_sec": round(end_sec - start_sec, 6),
                "original_end_sec": original_end_sec,
                "correction_reason": correction_rows_by_index[row_index]["reason"] if row_index in (correction_rows_by_index or {}) else "",
                "is_speech_phone": phone_class == "speech",
                "is_silence_or_event": phone_class != "speech",
            }
        )
    return rows, issues, uncertainty_rows, correction_rows


def split_phone_label(raw_label: str) -> tuple[str, str]:
    parsed = parse_phone_label(raw_label)
    return parsed.base_label, parsed.annotation_suffix


def parse_phone_label(raw_label: str) -> ParsedPhoneLabel:
    stripped = raw_label.strip()
    match = _PHONE_SUFFIX_SPLIT_RE.match(stripped)
    if not match:
        raise ValueError(f"malformed phone suffix grammar: {raw_label!r}")
    base = match.group("base").strip()
    suffix = match.group("suffix") or ""
    suffix = _normalize_phone_suffix(suffix)
    stress_or_variant_marker = ""
    plus1_match = _PHONE_PLUS1_RE.match(base)
    if plus1_match:
        normalized_base = plus1_match.group("base").lower()
        if normalized_base not in SPEECH_PHONE_WHITELIST:
            raise ValueError(f"unrecognized +1 phone base: {raw_label!r}")
        base = normalized_base
        stress_or_variant_marker = "+1"
    if suffix not in ALLOWED_PHONE_SUFFIXES:
        raise ValueError(f"unrecognized phone suffix form: {raw_label!r}")
    return ParsedPhoneLabel(
        raw_label=raw_label,
        base_label=base,
        annotation_suffix=suffix,
        stress_or_variant_marker=stress_or_variant_marker,
    )


def _normalize_phone_suffix(raw_suffix: str) -> str:
    suffix = raw_suffix.strip()
    if not suffix:
        return ""
    if not suffix.startswith(";"):
        raise ValueError(f"malformed phone suffix grammar: {raw_suffix!r}")
    suffix_body = suffix[1:].strip()
    if not suffix_body:
        return ";"
    return f"; {suffix_body}"


def _reconstruct_interval(
    path: Path,
    row_index: int,
    previous_end: float,
    end_sec: float,
    *,
    raw_label: str,
    strict_zero: bool,
) -> tuple[float, float] | None:
    if end_sec < previous_end:
        raise ValueError(f"{path} row {row_index} timestamp regressed: {end_sec} < {previous_end}")
    if end_sec == previous_end:
        if strict_zero:
            raise ValueError(f"{path} row {row_index} has zero-length interval at {end_sec}")
        return None
    return previous_end, end_sec


def is_lexical_word_label(raw_label: str, *, pos_tag: str = "") -> bool:
    stripped = raw_label.strip()
    return not (stripped.startswith("<") or stripped.startswith("{") or pos_tag.upper() == "NULL")


def is_speech_phone_label(raw_label: str) -> bool:
    return classify_phone_class(raw_label) == "speech"


def normalize_word_label(raw_label: str) -> str:
    stripped = raw_label.strip()
    if stripped.startswith("<") or stripped.startswith("{"):
        return stripped
    return stripped.lower()


def normalize_phone_label(raw_label: str) -> str:
    parsed = parse_phone_label(raw_label)
    base_lower = parsed.base_label.lower()
    if base_lower in SPEECH_PHONE_WHITELIST:
        return base_lower
    return parsed.base_label.upper()


def classify_word_event_type(raw_label: str) -> str | None:
    stripped = raw_label.strip()
    if is_lexical_word_label(stripped):
        return None
    if stripped in SILENCE_WORD_LABELS:
        return "silence"
    for prefix, event_type in WORD_EVENT_PREFIX_TO_TYPE:
        if stripped == prefix or stripped.startswith(prefix):
            return event_type
    if stripped.startswith("<") or stripped.startswith("{"):
        return "other_annotation"
    return "unknown"


def classify_phone_event_type(raw_label: str) -> str | None:
    phone_class = classify_phone_class(raw_label)
    if phone_class == "speech":
        return None
    if phone_class == "interviewer":
        return "interviewer_speech"
    return phone_class


def classify_phone_class(raw_label: str) -> str:
    parsed = parse_phone_label(raw_label)
    upper = parsed.base_label.upper()
    lower = parsed.base_label.lower()
    if lower in SPEECH_PHONE_WHITELIST:
        return "speech"
    if upper in SILENCE_PHONE_LABELS:
        return "silence"
    if upper in LAUGHTER_PHONE_LABELS:
        return "laughter"
    if upper in VOCNOISE_PHONE_LABELS:
        return "vocnoise"
    if upper in NOISE_PHONE_LABELS:
        return "noise"
    if upper in INTERVIEWER_PHONE_LABELS:
        return "interviewer"
    if upper in BOUNDARY_PHONE_LABELS:
        return "boundary_marker"
    if upper in OTHER_PHONE_LABELS or upper.startswith("<EXCLUDE"):
        return "other_annotation"
    return "unknown"


def normalize_buckeye_speaker(
    extracted_speaker_root: Path,
    normalized_root: Path,
    manifests_root: Path,
    readiness_audit_root: Path | None = None,
) -> dict[str, Any]:
    pairs = find_recording_pairs(extracted_speaker_root)
    speaker_id = pairs[0].speaker_id
    normalized_speaker_root = normalized_root / speaker_id
    normalized_speaker_root.mkdir(parents=True, exist_ok=True)
    manifests_root.mkdir(parents=True, exist_ok=True)
    policy = _load_reviewed_policy(readiness_audit_root=readiness_audit_root, speaker_id=speaker_id)

    words_rows: list[dict[str, Any]] = []
    phones_rows: list[dict[str, Any]] = []
    phone_inventory_counter: dict[tuple[str, str, str, str], int] = {}
    word_inventory_counter: dict[tuple[str, str, str], int] = {}
    unknown_rows: list[dict[str, Any]] = []
    malformed_rows: list[dict[str, Any]] = []
    annotation_coverage_rows: list[dict[str, Any]] = []
    uncertainty_mask_rows: list[dict[str, Any]] = []
    applied_correction_rows: list[dict[str, Any]] = []
    excluded_recording_rows: list[dict[str, Any]] = []
    reconciliation_rows: list[dict[str, Any]] = []
    validation: dict[str, Any] = {
        "selected_speaker": speaker_id,
        "recording_parts": [],
        "excluded_recordings": [],
        "total_audio_duration_sec": 0.0,
        "reference_word_count": 0,
        "reference_phone_count": 0,
        "lexical_word_count": 0,
        "speech_phone_count": 0,
        "event_count": 0,
        "unknown_label_count": 0,
        "missing_file_pairs": 0,
        "malformed_rows": 0,
        "non_monotonic_timestamps": 0,
        "zero_or_negative_intervals": 0,
        "annotation_beyond_wav_rows": 0,
        "pairs": [],
    }

    for pair in pairs:
        if pair.recording_id in policy["excluded_recordings"]:
            excluded_row = policy["excluded_recordings"][pair.recording_id]
            excluded_recording_rows.append(excluded_row)
            validation["excluded_recordings"].append(pair.recording_id)
            continue
        audio_info = inspect_wav(pair.wav_path)
        part_words, word_issues, word_corrections = _parse_words_file_with_policy(
            pair.words_path,
            correction_rows_by_index=policy["word_corrections_by_recording"].get(pair.recording_id, {}),
        )
        part_phones, phone_issues, phone_uncertainty_rows, phone_corrections = _parse_phones_file_with_policy(
            pair.phones_path,
            uncertainty_rows_by_index=policy["phone_uncertainty_by_recording"].get(pair.recording_id, {}),
            correction_rows_by_index=policy["phone_corrections_by_recording"].get(pair.recording_id, {}),
        )
        _validate_sorted_positive(part_words, annotation_name=f"{pair.recording_id}.words")
        _validate_sorted_positive(part_phones, annotation_name=f"{pair.recording_id}{pair.phone_extension}")
        _validate_annotation_against_audio(part_words, audio_info.duration_sec, annotation_name=f"{pair.recording_id}.words")
        _validate_annotation_against_audio(part_phones, audio_info.duration_sec, annotation_name=f"{pair.recording_id}{pair.phone_extension}")
        applied_correction_rows.extend(word_corrections)
        applied_correction_rows.extend(phone_corrections)
        uncertainty_mask_rows.extend(phone_uncertainty_rows)

        coverage_row = _build_annotation_coverage_row(
            speaker_id=speaker_id,
            recording_id=pair.recording_id,
            audio_info=audio_info,
            words_rows=part_words,
            phones_rows=part_phones,
        )
        annotation_coverage_rows.append(coverage_row)

        for issue in [*word_issues, *phone_issues]:
            malformed_rows.append(
                {
                    "speaker_id": speaker_id,
                    "recording_id": pair.recording_id,
                    "annotation_path": str((pair.words_path if issue["table"] == "words" else pair.phones_path).resolve()),
                    **issue,
                }
            )
        final_word_end = part_words[-1]["end_sec"] if part_words else 0.0
        final_phone_end = part_phones[-1]["end_sec"] if part_phones else 0.0
        final_annotation_end = max(final_word_end, final_phone_end)
        masked_uncertainty_sec = round(sum(float(row["duration_sec"]) for row in phone_uncertainty_rows), 6)
        validation["recording_parts"].append(pair.recording_id)
        validation["total_audio_duration_sec"] += audio_info.duration_sec
        validation["pairs"].append(
            {
                "recording_id": pair.recording_id,
                "phone_extension": pair.phone_extension,
                "wav_duration_sec": round(audio_info.duration_sec, 6),
                "sample_rate": audio_info.sample_rate,
                "channels": audio_info.channels,
                "bits_per_sample": audio_info.bits_per_sample,
                "final_word_end_sec": round(final_word_end, 6),
                "final_phone_end_sec": round(final_phone_end, 6),
                "final_annotation_end_sec": round(final_annotation_end, 6),
                "uncertainty_mask_sec": masked_uncertainty_sec,
                "applied_corrections": len(word_corrections) + len(phone_corrections),
            }
        )
        reconciliation_rows.append(
            {
                "speaker_id": speaker_id,
                "recording_id": pair.recording_id,
                "wav_duration_sec": round(audio_info.duration_sec, 6),
                "reference_word_count": len(part_words),
                "reference_phone_count": len(part_phones),
                "uncertainty_interval_count": len(phone_uncertainty_rows),
                "uncertain_reference_sec": masked_uncertainty_sec,
                "applied_correction_count": len(word_corrections) + len(phone_corrections),
                "final_word_end_sec": round(final_word_end, 6),
                "final_phone_end_sec": round(final_phone_end, 6),
            }
        )

        for row in part_words:
            if row["event_type"] == "unknown":
                unknown_rows.append(
                    {
                        "speaker_id": speaker_id,
                        "recording_id": pair.recording_id,
                        "table": "words",
                        "row_index": row["row_index"],
                        "raw_label": row["raw_label"],
                    }
                )
            if row["is_event"]:
                validation["event_count"] += 1
            words_rows.append(
                {
                    "speaker_id": speaker_id,
                    "recording_id": pair.recording_id,
                    "audio_path": str(pair.wav_path.resolve()),
                    "annotation_path": str(pair.words_path.resolve()),
                    **row,
                }
            )
            inventory_key = (row["raw_label"], row["normalized_label"], row["event_type"] or ("lexical_word" if row["is_lexical_word"] else "other"))
            word_inventory_counter[inventory_key] = word_inventory_counter.get(inventory_key, 0) + 1

        for row in part_phones:
            if row["phone_class"] == "unknown":
                unknown_rows.append(
                    {
                        "speaker_id": speaker_id,
                        "recording_id": pair.recording_id,
                        "table": "phones",
                        "row_index": row["row_index"],
                        "raw_label": row["raw_label"],
                    }
                )
            phones_rows.append(
                {
                    "speaker_id": speaker_id,
                    "recording_id": pair.recording_id,
                    "audio_path": str(pair.wav_path.resolve()),
                    "annotation_path": str(pair.phones_path.resolve()),
                    **row,
                }
            )
            inventory_key = (
                row["raw_label"],
                row["base_label"],
                row["annotation_suffix"],
                row["phone_class"],
            )
            phone_inventory_counter[inventory_key] = phone_inventory_counter.get(inventory_key, 0) + 1

    validation["reference_word_count"] = len(words_rows)
    validation["reference_phone_count"] = len(phones_rows)
    validation["lexical_word_count"] = sum(1 for row in words_rows if bool(row["is_lexical_word"]))
    validation["speech_phone_count"] = sum(1 for row in phones_rows if bool(row["is_speech_phone"]))
    validation["unknown_label_count"] = len(unknown_rows)
    validation["malformed_rows"] = len(malformed_rows)
    validation["total_audio_duration_sec"] = round(float(validation["total_audio_duration_sec"]), 6)

    write_csv(
        normalized_speaker_root / "reference_words.csv",
        words_rows,
        fieldnames=[
            "speaker_id",
            "recording_id",
            "audio_path",
            "annotation_path",
            "row_index",
            "raw_label",
            "normalized_label",
            "start_sec",
            "end_sec",
            "duration_sec",
            "original_end_sec",
            "correction_reason",
            "pos_tag",
            "is_lexical_word",
            "is_event",
            "event_type",
        ],
    )
    write_csv(
        normalized_speaker_root / "reference_phones.csv",
        phones_rows,
        fieldnames=[
            "speaker_id",
            "recording_id",
            "audio_path",
            "annotation_path",
            "row_index",
            "raw_label",
            "base_label",
            "annotation_suffix",
            "stress_or_variant_marker",
            "normalized_label",
            "phone_class",
            "start_sec",
            "end_sec",
            "duration_sec",
            "original_end_sec",
            "correction_reason",
            "is_speech_phone",
            "is_silence_or_event",
        ],
    )
    write_csv(
        normalized_speaker_root / "phone_label_inventory.csv",
        [
            {
                "speaker_id": speaker_id,
                "raw_label": raw_label,
                "base_label": base_label,
                "annotation_suffix": annotation_suffix,
                "phone_class": phone_class,
                "count": count,
            }
            for (raw_label, base_label, annotation_suffix, phone_class), count in sorted(phone_inventory_counter.items())
        ],
        fieldnames=["speaker_id", "raw_label", "base_label", "annotation_suffix", "phone_class", "count"],
    )
    write_csv(
        normalized_speaker_root / "word_annotation_inventory.csv",
        [
            {
                "speaker_id": speaker_id,
                "raw_label": raw_label,
                "normalized_label": normalized_label,
                "word_class": word_class,
                "count": count,
            }
            for (raw_label, normalized_label, word_class), count in sorted(word_inventory_counter.items())
        ],
        fieldnames=["speaker_id", "raw_label", "normalized_label", "word_class", "count"],
    )
    write_csv(
        normalized_speaker_root / "annotation_coverage_by_recording.csv",
        annotation_coverage_rows,
        fieldnames=list(annotation_coverage_rows[0].keys()) if annotation_coverage_rows else ["speaker_id"],
    )
    write_csv(
        normalized_speaker_root / "uncertainty_masks.csv",
        uncertainty_mask_rows,
        fieldnames=list(uncertainty_mask_rows[0].keys()) if uncertainty_mask_rows else ["speaker_id", "recording_id", "table", "row_index", "raw_label", "start_sec", "end_sec", "duration_sec", "reason"],
    )
    write_csv(
        normalized_speaker_root / "correction_manifest.csv",
        applied_correction_rows,
        fieldnames=list(applied_correction_rows[0].keys()) if applied_correction_rows else ["speaker_id", "recording_id", "table", "row_index", "raw_value", "corrected_value", "reason", "source_evidence"],
    )
    write_csv(
        normalized_speaker_root / "excluded_recordings.csv",
        excluded_recording_rows,
        fieldnames=list(excluded_recording_rows[0].keys()) if excluded_recording_rows else ["speaker_id", "recording_id", "classification", "reason"],
    )
    write_csv(
        normalized_speaker_root / "reference_reconciliation.csv",
        reconciliation_rows,
        fieldnames=list(reconciliation_rows[0].keys()) if reconciliation_rows else ["speaker_id", "recording_id"],
    )
    write_csv(
        normalized_speaker_root / "unknown_labels.csv",
        unknown_rows,
        fieldnames=["speaker_id", "recording_id", "table", "row_index", "raw_label"],
    )
    write_csv(
        normalized_speaker_root / "malformed_rows.csv",
        malformed_rows,
        fieldnames=["speaker_id", "recording_id", "annotation_path", "table", "row_index", "raw_label", "end_sec", "issue_type"],
    )
    _write_ingest_validation(
        manifests_root / "BUCKEYE_INGEST_VALIDATION.md",
        validation=validation,
        extracted_speaker_root=extracted_speaker_root,
        normalized_speaker_root=normalized_speaker_root,
        unknown_rows=unknown_rows,
        malformed_rows=malformed_rows,
        annotation_coverage_rows=annotation_coverage_rows,
    )
    _write_ingest_validation(
        normalized_speaker_root / "BUCKEYE_INGEST_VALIDATION.md",
        validation=validation,
        extracted_speaker_root=extracted_speaker_root,
        normalized_speaker_root=normalized_speaker_root,
        unknown_rows=unknown_rows,
        malformed_rows=malformed_rows,
        annotation_coverage_rows=annotation_coverage_rows,
    )
    if unknown_rows:
        labels = sorted({row["raw_label"] for row in unknown_rows})
        raise ValueError(f"Buckeye ingest found unknown labels for {speaker_id}: {labels}")
    return {
        "speaker_id": speaker_id,
        "recording_count": len(validation["recording_parts"]),
        "normalized_speaker_root": str(normalized_speaker_root.resolve()),
        "words_csv": str((normalized_speaker_root / "reference_words.csv").resolve()),
        "phones_csv": str((normalized_speaker_root / "reference_phones.csv").resolve()),
        "phone_label_inventory_csv": str((normalized_speaker_root / "phone_label_inventory.csv").resolve()),
        "word_annotation_inventory_csv": str((normalized_speaker_root / "word_annotation_inventory.csv").resolve()),
        "annotation_coverage_csv": str((normalized_speaker_root / "annotation_coverage_by_recording.csv").resolve()),
        "uncertainty_masks_csv": str((normalized_speaker_root / "uncertainty_masks.csv").resolve()),
        "correction_manifest_csv": str((normalized_speaker_root / "correction_manifest.csv").resolve()),
        "excluded_recordings_csv": str((normalized_speaker_root / "excluded_recordings.csv").resolve()),
        "reference_reconciliation_csv": str((normalized_speaker_root / "reference_reconciliation.csv").resolve()),
        "unknown_labels_csv": str((normalized_speaker_root / "unknown_labels.csv").resolve()),
        "malformed_rows_csv": str((normalized_speaker_root / "malformed_rows.csv").resolve()),
        "validation_report": str((manifests_root / "BUCKEYE_INGEST_VALIDATION.md").resolve()),
    }


def _validate_sorted_positive(rows: list[dict[str, Any]], *, annotation_name: str) -> None:
    previous_start = -1.0
    for row in rows:
        start_sec = float(row["start_sec"])
        end_sec = float(row["end_sec"])
        if start_sec < 0.0:
            raise ValueError(f"{annotation_name} has negative start: {start_sec}")
        if end_sec <= start_sec:
            raise ValueError(f"{annotation_name} has non-positive interval: {start_sec}-{end_sec}")
        if start_sec < previous_start - BOUNDARY_EPSILON_SEC:
            raise ValueError(f"{annotation_name} timestamp ordering regressed at {start_sec}")
        previous_start = start_sec


def _validate_annotation_against_audio(rows: list[dict[str, Any]], wav_duration_sec: float, *, annotation_name: str) -> None:
    if not rows:
        return
    if float(rows[-1]["end_sec"]) > wav_duration_sec + ANNOTATION_TOLERANCE_SEC:
        raise ValueError(
            f"{annotation_name} end {rows[-1]['end_sec']} exceeds wav duration {wav_duration_sec:.6f}"
        )


def _build_annotation_coverage_row(
    *,
    speaker_id: str,
    recording_id: str,
    audio_info: AudioInfo,
    words_rows: list[dict[str, Any]],
    phones_rows: list[dict[str, Any]],
) -> dict[str, Any]:
    phone_gap_count, largest_phone_gap, phone_overlap_count = _timeline_gap_overlap_stats(phones_rows)
    word_gap_count, largest_word_gap, word_overlap_count = _timeline_gap_overlap_stats(words_rows)
    final_phone_end = float(phones_rows[-1]["end_sec"]) if phones_rows else 0.0
    final_word_end = float(words_rows[-1]["end_sec"]) if words_rows else 0.0
    return {
        "speaker_id": speaker_id,
        "recording_id": recording_id,
        "wav_duration_sec": round(audio_info.duration_sec, 6),
        "phone_timeline_end_sec": round(final_phone_end, 6),
        "word_timeline_end_sec": round(final_word_end, 6),
        "phone_coverage_ratio": round(final_phone_end / audio_info.duration_sec, 6) if audio_info.duration_sec > 0 else "",
        "word_coverage_ratio": round(final_word_end / audio_info.duration_sec, 6) if audio_info.duration_sec > 0 else "",
        "phone_gap_count_gt_10ms": phone_gap_count,
        "largest_phone_gap_sec": round(largest_phone_gap, 6),
        "phone_overlap_count_gt_1ms": phone_overlap_count,
        "word_gap_count_gt_10ms": word_gap_count,
        "largest_word_gap_sec": round(largest_word_gap, 6),
        "word_overlap_count_gt_1ms": word_overlap_count,
    }


def _timeline_gap_overlap_stats(rows: list[dict[str, Any]]) -> tuple[int, float, int]:
    if not rows:
        return 0, 0.0, 0
    gap_count = 0
    overlap_count = 0
    largest_gap = 0.0
    previous_end = 0.0
    for row in rows:
        start_sec = float(row["start_sec"])
        end_sec = float(row["end_sec"])
        gap = start_sec - previous_end
        if gap > TIMELINE_WARN_GAP_SEC:
            gap_count += 1
            largest_gap = max(largest_gap, gap)
        if previous_end - start_sec > BOUNDARY_EPSILON_SEC:
            overlap_count += 1
        previous_end = end_sec
    return gap_count, largest_gap, overlap_count


def _write_ingest_validation(
    path: Path,
    *,
    validation: dict[str, Any],
    extracted_speaker_root: Path,
    normalized_speaker_root: Path,
    unknown_rows: list[dict[str, Any]],
    malformed_rows: list[dict[str, Any]],
    annotation_coverage_rows: list[dict[str, Any]],
) -> None:
    lines = [
        "# BUCKEYE_INGEST_VALIDATION",
        "",
        f"- selected speaker: `{validation['selected_speaker']}`",
        f"- extracted root: `{extracted_speaker_root}`",
        f"- normalized root: `{normalized_speaker_root}`",
        f"- recording parts: `{', '.join(validation['recording_parts'])}`",
        f"- total audio duration sec: `{validation['total_audio_duration_sec']}`",
        f"- reference word count: `{validation['reference_word_count']}`",
        f"- reference phone count: `{validation['reference_phone_count']}`",
        f"- lexical word count: `{validation['lexical_word_count']}`",
        f"- speech-phone count: `{validation['speech_phone_count']}`",
        f"- event count: `{validation['event_count']}`",
        f"- unknown label count: `{validation['unknown_label_count']}`",
        f"- malformed rows: `{validation['malformed_rows']}`",
        "",
        "## Recording Parts",
        "",
    ]
    for part in validation["pairs"]:
        lines.append(
            f"- `{part['recording_id']}`: wav `{part['wav_duration_sec']}`s, phones `{part['phone_extension']}`, "
            f"final word `{part['final_word_end_sec']}`s, final phone `{part['final_phone_end_sec']}`s, "
            f"final annotation `{part['final_annotation_end_sec']}`s, {part['sample_rate']} Hz, "
            f"{part['channels']} ch, {part['bits_per_sample']}-bit"
        )
    lines.extend(["", "## Annotation Coverage", ""])
    for row in annotation_coverage_rows:
        lines.append(
            f"- `{row['recording_id']}`: phone coverage `{row['phone_coverage_ratio']}`, word coverage `{row['word_coverage_ratio']}`, "
            f"phone gaps>10ms `{row['phone_gap_count_gt_10ms']}`, phone overlaps>1ms `{row['phone_overlap_count_gt_1ms']}`, "
            f"word gaps>10ms `{row['word_gap_count_gt_10ms']}`, word overlaps>1ms `{row['word_overlap_count_gt_1ms']}`"
        )
    if unknown_rows:
        lines.extend(["", "## Unknown Labels", ""])
        for row in unknown_rows[:100]:
            lines.append(f"- `{row['recording_id']}` `{row['table']}` row `{row['row_index']}` raw `{row['raw_label']}`")
    else:
        lines.extend(["", "## Unknown Labels", "", "- none"])
    if malformed_rows:
        lines.extend(["", "## Malformed Rows", ""])
        for row in malformed_rows[:100]:
            lines.append(
                f"- `{row['recording_id']}` `{row['table']}` row `{row['row_index']}` `{row['raw_label']}` at `{row['end_sec']}` -> `{row['issue_type']}`"
            )
    else:
        lines.extend(["", "## Malformed Rows", "", "- none"])
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
