from __future__ import annotations

import argparse
from pathlib import Path

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Evaluate Speechcraft speaker purity against trusted timestamps.")
    subparsers = parser.add_subparsers(dest="command", required=True)
    evaluate_parser = subparsers.add_parser("evaluate")
    evaluate_parser.add_argument("--reference", required=True)
    evaluate_parser.add_argument("--runs", required=True)
    evaluate_parser.add_argument("--out-root", required=True)
    evaluate_parser.add_argument("--run-name", required=True)
    evaluate_parser.add_argument("--overwrite", action="store_true")
    audit_parser = subparsers.add_parser("export-audit")
    audit_parser.add_argument("--eval-run", required=True)
    audit_parser.add_argument("--threshold", type=float, required=True)
    audit_parser.add_argument("--kind", required=True)
    audit_parser.add_argument("--limit", type=int)
    audit_parser.add_argument("--out", required=True)
    slicer_parser = subparsers.add_parser("analyze-slicer-yield")
    slicer_parser.add_argument("--eval-run", required=True)
    vad_gap_parser = subparsers.add_parser("analyze-vad-word-gaps")
    vad_gap_parser.add_argument("--eval-run", required=True)
    buckeye_parser = subparsers.add_parser("ingest-buckeye")
    buckeye_parser.add_argument("--extracted-speaker-root", required=True)
    buckeye_parser.add_argument("--normalized-root", required=True)
    buckeye_parser.add_argument("--manifests-root", required=True)
    buckeye_parser.add_argument("--readiness-audit-root")
    buckeye_readiness_parser = subparsers.add_parser("audit-buckeye-readiness")
    buckeye_readiness_parser.add_argument("--raw-root", required=True)
    buckeye_readiness_parser.add_argument("--normalized-root", required=True)
    buckeye_readiness_parser.add_argument("--out-root", required=True)
    buckeye_readiness_parser.add_argument("--speaker-id", action="append", required=True)
    buckeye_eval_parser = subparsers.add_parser("evaluate-buckeye-safecut")
    buckeye_eval_parser.add_argument("--eval-run", required=True)
    buckeye_eval_parser.add_argument("--normalized-speaker-dir", required=True)
    repaired_scope_parser = subparsers.add_parser("validate-repaired-buckeye-scope")
    repaired_scope_parser.add_argument("--speaker-id", required=True)
    repaired_scope_parser.add_argument("--eval-run", required=True)
    repaired_scope_parser.add_argument("--normalized-speaker-dir", required=True)
    repaired_scope_parser.add_argument("--cluster-mapping-csv", required=True)
    repaired_scope_parser.add_argument("--out-dir", required=True)
    repaired_dry_run_parser = subparsers.add_parser("run-repaired-slicer-dry-run")
    repaired_dry_run_parser.add_argument("--eval-run", required=True)
    repaired_dry_run_parser.add_argument("--normalized-speaker-dir", required=True)
    repaired_dry_run_parser.add_argument("--cluster-mapping-csv", required=True)
    repaired_dry_run_parser.add_argument("--out-root", required=True)
    repaired_dry_run_parser.add_argument("--detector-name", default="legacy_vad_rms")
    repaired_production_parser = subparsers.add_parser("run-repaired-production-dry-run")
    repaired_production_parser.add_argument("--eval-run", required=True)
    repaired_production_parser.add_argument("--normalized-speaker-dir", required=True)
    repaired_production_parser.add_argument("--cluster-mapping-csv", required=True)
    repaired_production_parser.add_argument("--out-root", required=True)
    repaired_matrix_parser = subparsers.add_parser("run-repaired-detector-matrix")
    repaired_matrix_parser.add_argument("--speaker-fixture", action="append", required=True, help="speaker_id:eval_run:normalized_speaker_dir")
    repaired_matrix_parser.add_argument("--cluster-mapping-csv", required=True)
    repaired_matrix_parser.add_argument("--out-root", required=True)
    repaired_matrix_parser.add_argument("--detector-name", action="append")
    slicer_daddy_parser = subparsers.add_parser("run-slicer-daddy-test")
    slicer_daddy_parser.add_argument("--eval-run", required=True)
    slicer_daddy_parser.add_argument("--normalized-speaker-dir", required=True)
    slicer_daddy_parser.add_argument("--out-root", required=True)
    multispeaker_parser = subparsers.add_parser("run-multispeaker-slicer-daddy-test")
    multispeaker_parser.add_argument("--speaker-fixture", action="append", required=True, help="speaker_id:eval_run:normalized_speaker_dir")
    multispeaker_parser.add_argument("--out-root", required=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "evaluate":
        from .evaluator import evaluate
        root = evaluate(
            reference_path=Path(args.reference),
            runs_path=Path(args.runs),
            out_root=Path(args.out_root),
            run_name=args.run_name,
            overwrite=bool(args.overwrite),
        )
        print(root)
        return 0
    if args.command == "export-audit":
        from .audit_export import export_audit
        out_dir = export_audit(
            eval_run=Path(args.eval_run),
            threshold=float(args.threshold),
            kind=str(args.kind),
            limit=args.limit,
            out_dir=Path(args.out),
        )
        print(out_dir)
        return 0
    if args.command == "analyze-slicer-yield":
        from .slicer_yield_analysis import analyze_slicer_yield
        out_dir = analyze_slicer_yield(eval_run=Path(args.eval_run))
        print(out_dir)
        return 0
    if args.command == "analyze-vad-word-gaps":
        from .vad_gap_analysis import analyze_vad_word_gaps
        out_dir = analyze_vad_word_gaps(eval_run=Path(args.eval_run))
        print(out_dir)
        return 0
    if args.command == "ingest-buckeye":
        from .buckeye import normalize_buckeye_speaker
        result = normalize_buckeye_speaker(
            extracted_speaker_root=Path(args.extracted_speaker_root),
            normalized_root=Path(args.normalized_root),
            manifests_root=Path(args.manifests_root),
            readiness_audit_root=Path(args.readiness_audit_root) if args.readiness_audit_root else None,
        )
        print(result["validation_report"])
        return 0
    if args.command == "audit-buckeye-readiness":
        from .buckeye_readiness_audit import run_buckeye_readiness_audit
        out_dir = run_buckeye_readiness_audit(
            raw_root=Path(args.raw_root),
            normalized_root=Path(args.normalized_root),
            out_root=Path(args.out_root),
            speaker_ids=list(args.speaker_id),
        )
        print(out_dir)
        return 0
    if args.command == "evaluate-buckeye-safecut":
        from .buckeye_safecut_benchmark import evaluate_buckeye_safecut
        out_dir = evaluate_buckeye_safecut(
            eval_run=Path(args.eval_run),
            normalized_speaker_dir=Path(args.normalized_speaker_dir),
        )
        print(out_dir)
        return 0
    if args.command == "validate-repaired-buckeye-scope":
        from .repaired_buckeye_benchmark import write_repaired_scope_validation
        out_dir = write_repaired_scope_validation(
            speaker_id=str(args.speaker_id),
            eval_run=Path(args.eval_run),
            normalized_speaker_dir=Path(args.normalized_speaker_dir),
            cluster_mapping_csv=Path(args.cluster_mapping_csv),
            out_dir=Path(args.out_dir),
        )
        print(out_dir)
        return 0
    if args.command == "run-repaired-slicer-dry-run":
        from .repaired_buckeye_benchmark import run_repaired_slicer_dry_run
        out_dir = run_repaired_slicer_dry_run(
            eval_run=Path(args.eval_run),
            normalized_speaker_dir=Path(args.normalized_speaker_dir),
            cluster_mapping_csv=Path(args.cluster_mapping_csv),
            out_root=Path(args.out_root),
            detector_name=str(args.detector_name),
        )
        print(out_dir)
        return 0
    if args.command == "run-repaired-production-dry-run":
        from .repaired_buckeye_benchmark import run_repaired_production_dry_run
        out_dir = run_repaired_production_dry_run(
            eval_run=Path(args.eval_run),
            normalized_speaker_dir=Path(args.normalized_speaker_dir),
            cluster_mapping_csv=Path(args.cluster_mapping_csv),
            out_root=Path(args.out_root),
        )
        print(out_dir)
        return 0
    if args.command == "run-repaired-detector-matrix":
        from .repaired_buckeye_benchmark import RepairedMatrixFixture, run_repaired_detector_matrix
        fixtures = []
        for item in args.speaker_fixture:
            speaker_id, eval_run, normalized_speaker_dir = item.split(":", 2)
            fixtures.append(
                RepairedMatrixFixture(
                    speaker_id=speaker_id,
                    eval_run=Path(eval_run),
                    normalized_speaker_dir=Path(normalized_speaker_dir),
                )
            )
        out_dir = run_repaired_detector_matrix(
            fixtures=fixtures,
            cluster_mapping_csv=Path(args.cluster_mapping_csv),
            out_root=Path(args.out_root),
            detector_names=list(args.detector_name) if args.detector_name else None,
        )
        print(out_dir)
        return 0
    if args.command == "run-slicer-daddy-test":
        from .slicer_daddy_test import run_slicer_daddy_test
        out_dir = run_slicer_daddy_test(
            eval_run=Path(args.eval_run),
            normalized_speaker_dir=Path(args.normalized_speaker_dir),
            out_root=Path(args.out_root),
        )
        print(out_dir)
        return 0
    if args.command == "run-multispeaker-slicer-daddy-test":
        from .multispeaker_slicer_daddy_test import MultiSpeakerFixture, run_multispeaker_slicer_daddy_test
        fixtures = []
        for item in args.speaker_fixture:
            speaker_id, eval_run, normalized_speaker_dir = item.split(":", 2)
            fixtures.append(
                MultiSpeakerFixture(
                    speaker_id=speaker_id,
                    eval_run=Path(eval_run),
                    normalized_speaker_dir=Path(normalized_speaker_dir),
                )
            )
        out_zip = run_multispeaker_slicer_daddy_test(
            fixtures=fixtures,
            out_root=Path(args.out_root),
        )
        print(out_zip)
        return 0
    raise ValueError(f"unknown command {args.command}")


if __name__ == "__main__":
    raise SystemExit(main())
