from __future__ import annotations

import csv
import hashlib
import json
import shutil
import subprocess
import sys
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .buckeye import inspect_wav
from .buckeye_safecut_benchmark import _read_csv
from .buckeye_nemo_preflight import _disk_free_bytes, _dir_size_bytes, _import_speechcraft_dataset
from .io_utils import write_csv, write_json
from .repaired_buckeye_benchmark import build_interviewer_mask, build_target_speech_reference, load_uncertainty_masks_by_recording


DISK_ABORT_FLOOR_BYTES = 15 * 1024 * 1024 * 1024
TARGET_PURITY_THRESHOLD = 0.80
LEAKAGE_THRESHOLD = 0.05
TARGET_RECALL_THRESHOLD = 0.95
MIN_INCREMENTAL_RECALL = 0.05


@dataclass(frozen=True)
class Interval:
    start: float
    end: float

    @property
    def duration(self) -> float:
        return max(0.0, self.end - self.start)


def _sha256_file(path: Path, *, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return f"sha256:{digest.hexdigest()}"


def _merge(intervals: list[Interval], *, eps: float = 1e-9) -> list[Interval]:
    ordered = sorted((iv for iv in intervals if iv.end > iv.start), key=lambda iv: (iv.start, iv.end))
    out: list[Interval] = []
    for iv in ordered:
        if not out or iv.start > out[-1].end + eps:
            out.append(iv)
        else:
            out[-1] = Interval(out[-1].start, max(out[-1].end, iv.end))
    return out


def _duration(intervals: list[Interval]) -> float:
    return sum(iv.duration for iv in _merge(intervals))


def _intersect(a: Interval, b: Interval) -> Interval | None:
    start = max(a.start, b.start)
    end = min(a.end, b.end)
    if end <= start:
        return None
    return Interval(start, end)


def _overlap_duration(a: list[Interval], b: list[Interval]) -> float:
    aa = _merge(a)
    bb = _merge(b)
    total = 0.0
    j = 0
    for iv in aa:
        while j < len(bb) and bb[j].end <= iv.start:
            j += 1
        k = j
        while k < len(bb) and bb[k].start < iv.end:
            overlap = _intersect(iv, bb[k])
            if overlap:
                total += overlap.duration
            k += 1
    return total


def _discover_raw_recordings(raw_root: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for speaker_dir in sorted(path for path in raw_root.iterdir() if path.is_dir()):
        speaker_id = speaker_dir.name
        for recording_dir in sorted(path for path in speaker_dir.iterdir() if path.is_dir()):
            recording_id = recording_dir.name
            wav_path = recording_dir / f"{recording_id}.wav"
            word_path = recording_dir / f"{recording_id}.words"
            phone_path = recording_dir / f"{recording_id}.phones"
            phons_path = recording_dir / f"{recording_id}.phons"
            if not wav_path.exists():
                continue
            rows.append(
                {
                    "speaker_id": speaker_id,
                    "recording_id": recording_id,
                    "wav_path": str(wav_path.resolve()),
                    "word_path": str(word_path.resolve()) if word_path.exists() else "",
                    "phone_path": str(phone_path.resolve()) if phone_path.exists() else "",
                    "phons_path": str(phons_path.resolve()) if phons_path.exists() else "",
                }
            )
    return rows


def _load_reference_availability(normalized_root: Path, discovered_rows: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], dict[tuple[str, str], dict[str, Any]]]:
    discovered_index = {(str(row["speaker_id"]), str(row["recording_id"])): row for row in discovered_rows}
    by_key: dict[tuple[str, str], dict[str, Any]] = {}
    all_speakers = sorted({str(row["speaker_id"]) for row in discovered_rows})
    for speaker_id in all_speakers:
        speaker_dir = normalized_root / speaker_id
        if not speaker_dir.exists():
            continue
        reconciliation_rows = _read_csv(speaker_dir / "reference_reconciliation.csv")
        excluded_rows = _read_csv(speaker_dir / "excluded_recordings.csv")
        for row in reconciliation_rows:
            key = (speaker_id, str(row["recording_id"]))
            if key not in discovered_index:
                continue
            by_key[key] = {
                "speaker_id": speaker_id,
                "recording_id": key[1],
                "reference_available": True,
                "reference_eligible": True,
                "reference_reason": "included",
                "normalized_phone_path": str((speaker_dir / "reference_phones.csv").resolve()),
                "normalized_word_path": str((speaker_dir / "reference_words.csv").resolve()),
                "uncertainty_mask_path": str((speaker_dir / "uncertainty_masks.csv").resolve()),
            }
        for row in excluded_rows:
            key = (speaker_id, str(row["recording_id"]))
            if key not in discovered_index:
                continue
            by_key[key] = {
                "speaker_id": speaker_id,
                "recording_id": key[1],
                "reference_available": True,
                "reference_eligible": False,
                "reference_reason": str(row.get("reason") or row.get("classification") or "excluded"),
                "normalized_phone_path": str((speaker_dir / "reference_phones.csv").resolve()),
                "normalized_word_path": str((speaker_dir / "reference_words.csv").resolve()),
                "uncertainty_mask_path": str((speaker_dir / "uncertainty_masks.csv").resolve()),
            }
    rows: list[dict[str, Any]] = []
    for row in discovered_rows:
        key = (str(row["speaker_id"]), str(row["recording_id"]))
        ref = by_key.get(key)
        if ref is None:
            rows.append(
                {
                    "speaker_id": key[0],
                    "recording_id": key[1],
                    "reference_available": False,
                    "reference_eligible": False,
                    "reference_reason": "no_normalized_reference",
                    "normalized_phone_path": "",
                    "normalized_word_path": "",
                    "uncertainty_mask_path": "",
                }
            )
        else:
            rows.append(ref)
    return rows, { (str(r["speaker_id"]), str(r["recording_id"])): r for r in rows }


def _build_reference_sets(normalized_root: Path, speaker_id: str) -> tuple[dict[str, list[Interval]], dict[str, list[Interval]]]:
    speaker_dir = normalized_root / speaker_id
    phones = _read_csv(speaker_dir / "reference_phones.csv")
    words = _read_csv(speaker_dir / "reference_words.csv")
    uncertainty = load_uncertainty_masks_by_recording(speaker_dir / "uncertainty_masks.csv")
    interviewer_mask = build_interviewer_mask(reference_words=words, reference_phones=phones)
    target_speech = build_target_speech_reference(
        reference_phones=phones,
        interviewer_mask_by_recording=interviewer_mask,
        uncertainty_mask_by_recording=uncertainty,
    )
    return (
        {rid: [Interval(start, end) for start, end in ivs] for rid, ivs in target_speech.items()},
        {rid: [Interval(start, end) for start, end in ivs] for rid, ivs in interviewer_mask.items()},
    )


def _load_run_rows(run_root: Path) -> tuple[list[dict[str, Any]], dict[str, str]]:
    manifest = json.loads((run_root / "artifacts/source_audio_manifest.json").read_text(encoding="utf-8"))
    source_to_recording = {str(row["source_audio_id"]): str(row["source_recording_id"]) for row in manifest["sources"]}
    rows: list[dict[str, Any]] = []
    with (run_root / "artifacts" / "speaker_regions.jsonl").open(encoding="utf-8") as handle:
        for line in handle:
            if not line.strip():
                continue
            row = json.loads(line)
            row["recording_id"] = source_to_recording[str(row["source_audio_id"])]
            rows.append(row)
    return rows, source_to_recording


def _load_rttm_labels(run_root: Path) -> dict[str, set[str]]:
    labels_by_recording: dict[str, set[str]] = defaultdict(set)
    manifest = json.loads((run_root / "artifacts/source_audio_manifest.json").read_text(encoding="utf-8"))
    source_to_recording = {str(row["source_audio_id"]): str(row["source_recording_id"]) for row in manifest["sources"]}
    diar_root = run_root / "artifacts" / "diarization"
    for rttm in diar_root.rglob("*.rttm"):
        with rttm.open(encoding="utf-8") as handle:
            for line in handle:
                parts = line.strip().split()
                if len(parts) < 8 or parts[0] != "SPEAKER":
                    continue
                file_id = parts[1]
                speaker_label = parts[7]
                recording_id = source_to_recording.get(file_id)
                if recording_id is None and "_window_" in file_id:
                    recording_id = source_to_recording.get(file_id.split("_window_", 1)[0])
                if recording_id:
                    labels_by_recording[recording_id].add(speaker_label)
    return labels_by_recording


def _run_single_recording_nemo(
    *,
    run_root: Path,
    recording_row: dict[str, Any],
    template_config_path: Path,
) -> dict[str, Any]:
    worker = _import_speechcraft_dataset()
    wav_path = Path(str(recording_row["wav_path"]))
    audio_hash = _sha256_file(wav_path)
    runtime_versions = worker["runtime_versions"]()
    git_commit = subprocess.run(["git", "rev-parse", "HEAD"], cwd="/home/aaravthegreat/Projects/speechcraft", capture_output=True, text=True, check=False).stdout.strip()
    if run_root.exists():
        prior = run_root / "provenance.json"
        prior_config_path = run_root / "config.json"
        if prior.exists():
            prior_data = json.loads(prior.read_text(encoding="utf-8"))
            desired_config_hash = None
            if template_config_path.exists():
                config = worker["default_config"]([wav_path], single_speaker=False, target_speaker_label="speaker_0")
                template = json.loads(template_config_path.read_text(encoding="utf-8"))
                config.update({k: v for k, v in template.items() if k not in {"source_wavs", "target_speaker_label", "config_hash"}})
                config["source_wavs"] = [str(wav_path.resolve())]
                config["target_speaker_label"] = "speaker_0"
                desired_config_hash = worker["config_hash"](config)
            elif prior_config_path.exists():
                desired_config_hash = str(json.loads(prior_config_path.read_text(encoding="utf-8")).get("config_hash") or "")
            if (
                prior_data.get("audio_hash") == audio_hash
                and prior_data.get("config_hash") == desired_config_hash
                and prior_data.get("runtime_versions") == runtime_versions
                and prior_data.get("git_commit") == git_commit
                and (run_root / "artifacts" / "speaker_regions.jsonl").exists()
            ):
                return {
                    "reused": True,
                    "run_root": str(run_root),
                    "peak_run_root_size_bytes": _dir_size_bytes(run_root),
                    "peak_temp_growth_bytes": 0,
                    "free_bytes_after": _disk_free_bytes(run_root),
                    "config_hash": desired_config_hash,
                    "audio_hash": audio_hash,
                }
        shutil.rmtree(run_root)

    if not template_config_path.exists():
        raise FileNotFoundError(str(template_config_path))

    config = worker["default_config"]([wav_path], single_speaker=False, target_speaker_label="speaker_0")
    template = json.loads(template_config_path.read_text(encoding="utf-8"))
    config.update({k: v for k, v in template.items() if k not in {"source_wavs", "target_speaker_label", "config_hash"}})
    config["source_wavs"] = [str(wav_path.resolve())]
    config["target_speaker_label"] = "speaker_0"
    config["config_hash"] = worker["config_hash"](config)
    provenance = {
        "audio_hash": audio_hash,
        "config_hash": config["config_hash"],
        "runtime_versions": runtime_versions,
        "git_commit": git_commit,
    }

    (run_root / "artifacts").mkdir(parents=True, exist_ok=True)
    (run_root / "logs").mkdir(parents=True, exist_ok=True)
    write_json(run_root / "config.json", config)
    write_json(run_root / "provenance.json", provenance)
    free_before = _disk_free_bytes(run_root)
    peak_size = 0
    peak_growth = 0
    stage_sizes: list[dict[str, Any]] = []

    def mark(stage: str) -> None:
        nonlocal peak_size, peak_growth
        size = _dir_size_bytes(run_root)
        peak_size = max(peak_size, size)
        peak_growth = max(peak_growth, free_before - _disk_free_bytes(run_root))
        stage_sizes.append({"stage": stage, "run_root_size_bytes": size, "free_bytes": _disk_free_bytes(run_root)})

    worker["run_prepare_sources"](run_root, config)
    mark("source_audio")
    worker["run_audio_variants"](run_root, config)
    mark("audio_variants")
    worker["run_silero_vad"](run_root, config)
    mark("vad")
    worker["run_diarization"](run_root, config)
    mark("diarization")
    return {
        "reused": False,
        "run_root": str(run_root),
        "peak_run_root_size_bytes": peak_size,
        "peak_temp_growth_bytes": peak_growth,
        "free_bytes_after": _disk_free_bytes(run_root),
        "config_hash": provenance["config_hash"],
        "audio_hash": provenance["audio_hash"],
        "stage_sizes": stage_sizes,
    }


def _validate_run_outputs(run_root: Path, wav_duration_sec: float) -> dict[str, Any]:
    rows, _ = _load_run_rows(run_root)
    rttm_labels = _load_rttm_labels(run_root)
    cluster_labels = sorted({str(row["speaker_id"]) for row in rows})
    all_rttm_labels = sorted({label for labels in rttm_labels.values() for label in labels})
    segments_outside_wav = 0
    zero_duration_segments = 0
    diarized_duration = 0.0
    for row in rows:
        start_sec = float(row["start_sec"])
        end_sec = float(row["end_sec"])
        if end_sec <= start_sec:
            zero_duration_segments += 1
        if start_sec < -1e-6 or end_sec > wav_duration_sec + 1e-6:
            segments_outside_wav += 1
        diarized_duration += max(0.0, end_sec - start_sec)
    return {
        "raw_rttm_labels": "|".join(all_rttm_labels),
        "raw_cluster_count": len(cluster_labels),
        "diarized_duration_sec": round(diarized_duration, 6),
        "segments_outside_wav": segments_outside_wav,
        "zero_duration_segments": zero_duration_segments,
        "cluster_labels": cluster_labels,
        "rttm_labels": all_rttm_labels,
    }


def _prune_working_files(run_root: Path) -> None:
    removable_patterns = [
        "artifacts/diarization/_concat/*.wav",
        "artifacts/diarization/concat/window_*/concat_window_*.wav",
        "artifacts/diarization/concat/window_*/speaker_outputs/*",
    ]
    for pattern in removable_patterns:
        for path in run_root.glob(pattern):
            if path.is_file():
                path.unlink(missing_ok=True)
    for path in sorted(run_root.glob("artifacts/diarization/concat/window_*/speaker_outputs")):
        if path.is_dir():
            shutil.rmtree(path, ignore_errors=True)
    for path in sorted(run_root.glob("artifacts/diarization/_concat")):
        if path.is_dir():
            shutil.rmtree(path, ignore_errors=True)


def _compute_mapping_for_recording(
    *,
    speaker_id: str,
    recording_id: str,
    run_root: Path,
    normalized_root: Path,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    target_by_recording, interviewer_by_recording = _build_reference_sets(normalized_root, speaker_id)
    target_ref = _merge(target_by_recording.get(recording_id, []))
    interviewer_ref = _merge(interviewer_by_recording.get(recording_id, []))
    total_target = _duration(target_ref)
    total_interviewer = _duration(interviewer_ref)
    rows, _ = _load_run_rows(run_root)
    cluster_intervals: dict[str, list[Interval]] = defaultdict(list)
    for row in rows:
        if str(row["recording_id"]) != recording_id:
            continue
        cluster_intervals[str(row["speaker_id"])].append(Interval(float(row["start_sec"]), float(row["end_sec"])))
    cluster_intervals = {cid: _merge(ivs) for cid, ivs in cluster_intervals.items()}
    cluster_metrics: list[dict[str, Any]] = []
    for cid, ivs in sorted(cluster_intervals.items()):
        cluster_duration_sec = _duration(ivs)
        target_overlap_sec = _overlap_duration(ivs, target_ref)
        interviewer_overlap_sec = _overlap_duration(ivs, interviewer_ref)
        target_recall = target_overlap_sec / total_target if total_target else 0.0
        interviewer_recall = interviewer_overlap_sec / total_interviewer if total_interviewer else 0.0
        target_purity = target_overlap_sec / cluster_duration_sec if cluster_duration_sec else 0.0
        interviewer_leakage_rate = interviewer_overlap_sec / cluster_duration_sec if cluster_duration_sec else 0.0
        metrics_row = {
            "speaker_id": speaker_id,
            "recording_id": recording_id,
            "cluster_id": cid,
            "cluster_duration_sec": round(cluster_duration_sec, 6),
            "target_overlap_sec": round(target_overlap_sec, 6),
            "target_recall": round(target_recall, 6),
            "target_purity": round(target_purity, 6),
            "interviewer_overlap_sec": round(interviewer_overlap_sec, 6),
            "interviewer_leakage_rate": round(interviewer_leakage_rate, 6),
            "interviewer_recall": round(interviewer_recall, 6),
        }
        for field in ("target_recall", "target_purity", "interviewer_leakage_rate", "interviewer_recall"):
            value = float(metrics_row[field])
            if value < -1e-6 or value > 1.0 + 1e-6:
                raise ValueError(f"{speaker_id}/{recording_id}/{cid} {field} out of bounds: {value}")
        cluster_metrics.append(metrics_row)
    cluster_metrics.sort(key=lambda row: (float(row["target_overlap_sec"]), -float(row["interviewer_overlap_sec"])), reverse=True)

    candidate_rows: list[dict[str, Any]] = []
    best_single = cluster_metrics[0] if cluster_metrics else None
    selected_multi: list[str] = []
    prev_target_recall = 0.0
    prev_interviewer_overlap = 0.0
    if cluster_metrics:
        for row in cluster_metrics:
            cid = str(row["cluster_id"])
            if float(row["target_purity"]) < TARGET_PURITY_THRESHOLD or float(row["interviewer_leakage_rate"]) > LEAKAGE_THRESHOLD:
                continue
            selected_multi.append(cid)
            selected_intervals = _merge([iv for current_id in selected_multi for iv in cluster_intervals[current_id]])
            target_overlap_sec = _overlap_duration(selected_intervals, target_ref)
            interviewer_overlap_sec = _overlap_duration(selected_intervals, interviewer_ref)
            selected_duration = _duration(selected_intervals)
            target_recall = target_overlap_sec / total_target if total_target else 0.0
            interviewer_leakage_rate = interviewer_overlap_sec / selected_duration if selected_duration else 0.0
            candidate_rows.append(
                {
                    "speaker_id": speaker_id,
                    "recording_id": recording_id,
                    "added_cluster_id": cid,
                    "selected_cluster_ids": "|".join(selected_multi),
                    "incremental_target_recall": round(target_recall - prev_target_recall, 6),
                    "incremental_interviewer_leakage": round(interviewer_overlap_sec - prev_interviewer_overlap, 6),
                    "union_target_recall": round(target_recall, 6),
                    "union_interviewer_leakage_rate": round(interviewer_leakage_rate, 6),
                }
            )
            prev_target_recall = target_recall
            prev_interviewer_overlap = interviewer_overlap_sec

    status = "REVIEW_REQUIRED"
    selected_cluster_ids = ""
    chosen_multi_row: dict[str, Any] | None = None
    if best_single is None:
        status = "NEMO_FAILED"
    elif (
        float(best_single["target_recall"]) >= TARGET_RECALL_THRESHOLD
        and float(best_single["target_purity"]) >= TARGET_PURITY_THRESHOLD
        and float(best_single["interviewer_leakage_rate"]) <= LEAKAGE_THRESHOLD
    ):
        status = "AUTO_ACCEPT_SINGLE"
        selected_cluster_ids = str(best_single["cluster_id"])
    else:
        qualifying_rows = [
            row
            for row in candidate_rows
            if float(row["incremental_target_recall"]) >= MIN_INCREMENTAL_RECALL
        ]
        valid_multi_rows = [
            row
            for row in qualifying_rows
            if float(row["union_target_recall"]) >= TARGET_RECALL_THRESHOLD
            and float(row["union_interviewer_leakage_rate"]) <= LEAKAGE_THRESHOLD
        ]
        if valid_multi_rows:
            chosen = valid_multi_rows[0]
            status = "AUTO_ACCEPT_MULTI"
            selected_cluster_ids = str(chosen["selected_cluster_ids"])
            chosen_multi_row = chosen

    decision_row = {
        "speaker_id": speaker_id,
        "recording_id": recording_id,
        "mapping_status": status,
        "selected_cluster_ids": selected_cluster_ids,
        "best_single_cluster_id": str(best_single["cluster_id"]) if best_single else "",
        "best_single_target_recall": float(best_single["target_recall"]) if best_single else "",
        "best_single_target_purity": float(best_single["target_purity"]) if best_single else "",
        "best_single_interviewer_leakage_rate": float(best_single["interviewer_leakage_rate"]) if best_single else "",
        "best_multi_cluster_ids": chosen_multi_row["selected_cluster_ids"] if chosen_multi_row else "",
        "best_multi_target_recall": chosen_multi_row["union_target_recall"] if chosen_multi_row else "",
        "best_multi_interviewer_leakage_rate": chosen_multi_row["union_interviewer_leakage_rate"] if chosen_multi_row else "",
    }
    return cluster_metrics, candidate_rows, decision_row


def run_buckeye_nemo_batch(
    *,
    raw_root: Path,
    normalized_root: Path,
    template_config_path: Path,
    out_root: Path,
) -> dict[str, Any]:
    if _disk_free_bytes(out_root) < DISK_ABORT_FLOOR_BYTES:
        raise RuntimeError("not enough free disk before batch start")
    discovered_rows = _discover_raw_recordings(raw_root)
    if not discovered_rows:
        raise RuntimeError("no raw Buckeye recordings discovered")
    reference_rows, reference_index = _load_reference_availability(normalized_root, discovered_rows)
    write_csv(out_root / "reference_availability.csv", reference_rows, fieldnames=list(reference_rows[0].keys()))

    cluster_metrics_rows: list[dict[str, Any]] = []
    candidate_rows: list[dict[str, Any]] = []
    decision_rows: list[dict[str, Any]] = []
    failure_rows: list[dict[str, Any]] = []
    reconciliation_rows: list[dict[str, Any]] = []
    status_rows: list[dict[str, Any]] = []
    disk_by_speaker: dict[str, int] = defaultdict(int)
    review_manifest_rows: list[dict[str, Any]] = []

    for row in discovered_rows:
        if _disk_free_bytes(out_root) < DISK_ABORT_FLOOR_BYTES:
            raise RuntimeError("disk floor reached during batch")
        speaker_id = str(row["speaker_id"])
        recording_id = str(row["recording_id"])
        run_root = out_root / "runs" / speaker_id / recording_id
        ref = reference_index[(speaker_id, recording_id)]
        wav_path = Path(str(row["wav_path"]))
        wav_info = inspect_wav(wav_path)
        try:
            nemo_summary = _run_single_recording_nemo(
                run_root=run_root,
                recording_row=row,
                template_config_path=template_config_path,
            )
            validation = _validate_run_outputs(run_root, wav_info.duration_sec)
            if validation["zero_duration_segments"] or validation["segments_outside_wav"]:
                raise ValueError(
                    f"invalid raw segments for {speaker_id}/{recording_id}: "
                    f"outside={validation['segments_outside_wav']} zero={validation['zero_duration_segments']}"
                )
            diag_cluster_ids = set(validation["cluster_labels"])
            raw_rttm_ids = set(validation["rttm_labels"])
            if diag_cluster_ids != raw_rttm_ids:
                raise ValueError(f"cluster id mismatch for {speaker_id}/{recording_id}: diag={sorted(diag_cluster_ids)} rttm={sorted(raw_rttm_ids)}")
            mapping_status = "NO_VALID_REFERENCE"
            selected_cluster_ids = ""
            if ref["reference_available"] and ref["reference_eligible"]:
                cluster_rows, mapping_candidates, mapping_decision = _compute_mapping_for_recording(
                    speaker_id=speaker_id,
                    recording_id=recording_id,
                    run_root=run_root,
                    normalized_root=normalized_root,
                )
                cluster_metrics_rows.extend(cluster_rows)
                candidate_rows.extend(mapping_candidates)
                decision_rows.append(mapping_decision)
                mapping_status = str(mapping_decision["mapping_status"])
                selected_cluster_ids = str(mapping_decision["selected_cluster_ids"])
            else:
                decision_rows.append(
                    {
                        "speaker_id": speaker_id,
                        "recording_id": recording_id,
                        "mapping_status": "NO_VALID_REFERENCE",
                        "selected_cluster_ids": "",
                        "best_single_cluster_id": "",
                        "best_single_target_recall": "",
                        "best_single_target_purity": "",
                        "best_single_interviewer_leakage_rate": "",
                        "best_multi_cluster_ids": "",
                        "best_multi_target_recall": "",
                        "best_multi_interviewer_leakage_rate": "",
                    }
                )

            _prune_working_files(run_root)

            reconciliation_rows.append(
                {
                    "speaker_id": speaker_id,
                    "recording_id": recording_id,
                    "raw_rttm_labels": validation["raw_rttm_labels"],
                    "raw_cluster_count": validation["raw_cluster_count"],
                    "diarized_duration_sec": validation["diarized_duration_sec"],
                    "wav_duration_sec": round(wav_info.duration_sec, 6),
                    "segments_outside_wav": validation["segments_outside_wav"],
                    "zero_duration_segments": validation["zero_duration_segments"],
                }
            )
            status_rows.append(
                {
                    "speaker_id": speaker_id,
                    "recording_id": recording_id,
                    "reference_available": ref["reference_available"],
                    "reference_eligible": ref["reference_eligible"],
                    "reference_reason": ref["reference_reason"],
                    "nemo_status": "SUCCESS",
                    "mapping_status": mapping_status,
                    "selected_cluster_ids": selected_cluster_ids,
                    "run_root": str(run_root),
                    "reused_run": nemo_summary["reused"],
                }
            )
            if mapping_status == "REVIEW_REQUIRED":
                review_manifest_rows.append(
                    {
                        "speaker_id": speaker_id,
                        "recording_id": recording_id,
                        "review_kind": "mapping_review",
                        "timestamp_sec": round(wav_info.duration_sec / 2.0, 6),
                        "window_start_sec": round(max(0.0, wav_info.duration_sec / 2.0 - 2.0), 6),
                        "window_end_sec": round(min(wav_info.duration_sec, wav_info.duration_sec / 2.0 + 2.0), 6),
                        "note": "review required by automatic mapping triage",
                    }
                )
            disk_by_speaker[speaker_id] += _dir_size_bytes(run_root)
        except Exception as exc:
            failure_rows.append(
                {
                    "speaker_id": speaker_id,
                    "recording_id": recording_id,
                    "failure_stage": "nemo_or_mapping",
                    "error": str(exc),
                }
            )
            status_rows.append(
                {
                    "speaker_id": speaker_id,
                    "recording_id": recording_id,
                    "reference_available": ref["reference_available"],
                    "reference_eligible": ref["reference_eligible"],
                    "reference_reason": ref["reference_reason"],
                    "nemo_status": "FAILED",
                    "mapping_status": "NEMO_FAILED",
                    "selected_cluster_ids": "",
                    "run_root": str(run_root),
                    "reused_run": False,
                }
            )

    if len(status_rows) != len(discovered_rows):
        raise RuntimeError("not every discovered recording received a final status")

    write_csv(out_root / "nemo_recording_status.csv", status_rows, fieldnames=list(status_rows[0].keys()))
    write_csv(out_root / "nemo_failures.csv", failure_rows, fieldnames=list(failure_rows[0].keys()) if failure_rows else ["speaker_id", "recording_id", "failure_stage", "error"])
    write_csv(out_root / "nemo_cluster_metrics.csv", cluster_metrics_rows, fieldnames=list(cluster_metrics_rows[0].keys()) if cluster_metrics_rows else ["speaker_id"])
    write_csv(out_root / "nemo_mapping_candidates.csv", candidate_rows, fieldnames=list(candidate_rows[0].keys()) if candidate_rows else ["speaker_id"])
    write_csv(
        out_root / "nemo_mapping_decisions.csv",
        decision_rows,
        fieldnames=list(decision_rows[0].keys())
        if decision_rows
        else [
            "speaker_id",
            "recording_id",
            "mapping_status",
            "selected_cluster_ids",
            "best_single_cluster_id",
            "best_single_target_recall",
            "best_single_target_purity",
            "best_single_interviewer_leakage_rate",
            "best_multi_cluster_ids",
            "best_multi_target_recall",
            "best_multi_interviewer_leakage_rate",
        ],
    )
    write_csv(out_root / "raw_output_reconciliation.csv", reconciliation_rows, fieldnames=list(reconciliation_rows[0].keys()) if reconciliation_rows else ["speaker_id"])
    write_csv(
        out_root / "disk_usage_by_speaker.csv",
        [{"speaker_id": speaker_id, "run_disk_bytes": size_bytes} for speaker_id, size_bytes in sorted(disk_by_speaker.items())],
        fieldnames=["speaker_id", "run_disk_bytes"],
    )
    write_csv(
        out_root / "review_required_listening_manifest.csv",
        review_manifest_rows,
        fieldnames=list(review_manifest_rows[0].keys()) if review_manifest_rows else ["speaker_id", "recording_id", "review_kind", "timestamp_sec", "window_start_sec", "window_end_sec", "note"],
    )

    counts = defaultdict(int)
    for row in status_rows:
        counts[str(row["mapping_status"])] += 1
    batch_summary = {
        "speakers_discovered": len(sorted({str(row['speaker_id']) for row in discovered_rows})),
        "recordings_discovered": len(discovered_rows),
        "nemo_successes": counts["AUTO_ACCEPT_SINGLE"] + counts["AUTO_ACCEPT_MULTI"] + counts["REVIEW_REQUIRED"] + counts["NO_VALID_REFERENCE"],
        "nemo_failures": counts["NEMO_FAILED"],
        "AUTO_ACCEPT_SINGLE": counts["AUTO_ACCEPT_SINGLE"],
        "AUTO_ACCEPT_MULTI": counts["AUTO_ACCEPT_MULTI"],
        "REVIEW_REQUIRED": counts["REVIEW_REQUIRED"],
        "NO_VALID_REFERENCE": counts["NO_VALID_REFERENCE"],
        "free_disk_remaining_bytes": _disk_free_bytes(out_root),
    }
    write_csv(out_root / "nemo_batch_summary.csv", [batch_summary], fieldnames=list(batch_summary.keys()))
    write_json(
        out_root / "provenance.json",
        {
            "analysis_date": "2026-07-18",
            "template_config_path": str(template_config_path),
            "raw_root": str(raw_root),
            "normalized_root": str(normalized_root),
            "recordings_discovered": len(discovered_rows),
            "free_disk_remaining_bytes": _disk_free_bytes(out_root),
        },
    )
    return batch_summary
