from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from speaker_ts_eval.buckeye import classify_phone_class, split_phone_label
from speaker_ts_eval.repaired_buckeye_benchmark import (
    BOUNDARY_EPSILON_SEC,
    NemoScopeBuffer,
    RepairedMatrixFixture,
    build_boundary_classification_rows,
    build_raw_nemo_target_buffers,
    build_interviewer_mask,
    build_nemo_scope_rows,
    build_phone_annotations,
    build_target_speech_reference,
    classify_boundary,
    compute_clip_coverage_metrics,
    cutpoints_strictly_inside_buffers,
    default_repaired_matrix_detector_names,
    generate_legal_candidate_clips_in_buffers,
    load_recording_eligibility,
    require_parser_artifacts,
    run_repaired_detector_matrix,
    run_repaired_slicer_dry_run,
    schedule_candidates_by_buffer,
    summarize_boundary_severity_by_speaker,
    summarize_boundary_severity_by_speaker_and_source,
    supported_repaired_detectors,
    write_repaired_scope_validation,
)
from speaker_ts_eval.slicer_daddy_test import BenchmarkConfig, CandidateClip, Clip, Cutpoint, DetectorRunResult, PackingConstraints


class RepairedBuckeyeBenchmarkTests(unittest.TestCase):
    def test_phone_suffix_and_classification(self) -> None:
        self.assertEqual(split_phone_label("aa; *"), ("aa", "; *"))
        self.assertEqual(split_phone_label("d ; *"), ("d", "; *"))
        self.assertEqual(classify_phone_class("SIL"), "silence")
        self.assertEqual(classify_phone_class("IVER"), "interviewer")
        self.assertEqual(classify_phone_class("{B_TRANS}"), "boundary_marker")
        self.assertEqual(classify_phone_class("<exclude-name>"), "other_annotation")

    def test_target_speech_reference_subtracts_interviewer_by_duration(self) -> None:
        phones = [
            {"recording_id": "rec", "start_sec": "0.0", "end_sec": "1.0", "is_speech_phone": "True", "normalized_label": "aa", "phone_class": "speech"},
            {"recording_id": "rec", "start_sec": "1.0", "end_sec": "2.0", "is_speech_phone": "True", "normalized_label": "ae", "phone_class": "speech"},
        ]
        interviewer = {"rec": [(0.5, 1.25)]}
        target = build_target_speech_reference(reference_phones=phones, interviewer_mask_by_recording=interviewer)
        self.assertEqual(target["rec"], [(0.0, 0.5), (1.25, 2.0)])

    def test_target_speech_reference_subtracts_uncertainty_by_duration(self) -> None:
        phones = [
            {"recording_id": "rec", "start_sec": "0.0", "end_sec": "2.0", "is_speech_phone": "True", "normalized_label": "aa", "phone_class": "speech"},
        ]
        target = build_target_speech_reference(
            reference_phones=phones,
            interviewer_mask_by_recording={"rec": []},
            uncertainty_mask_by_recording={"rec": [(0.25, 0.75)]},
        )
        self.assertEqual(target["rec"], [(0.0, 0.25), (0.75, 2.0)])

    def test_build_interviewer_mask_unions_word_and_phone_iver(self) -> None:
        words = [
            {"recording_id": "rec", "start_sec": "1.0", "end_sec": "2.0", "event_type": "interviewer", "raw_label": "<IVER>"},
        ]
        phones = [
            {"recording_id": "rec", "start_sec": "2.0", "end_sec": "2.5", "phone_class": "interviewer", "raw_label": "IVER"},
        ]
        mask = build_interviewer_mask(reference_words=words, reference_phones=phones)
        self.assertEqual(mask["rec"], [(1.0, 2.5)])

    def test_touching_nemo_segments_merge_but_positive_gap_does_not(self) -> None:
        buffers = [
            NemoScopeBuffer("s01", "rec", "src", "/tmp/a.wav", "b0", 0.0, 1.0, 1.0, ("c0",), 0.9),
            NemoScopeBuffer("s01", "rec", "src", "/tmp/a.wav", "b1", 1.0, 2.0, 1.0, ("c1",), 0.8),
            NemoScopeBuffer("s01", "rec", "src", "/tmp/a.wav", "b2", 2.1, 3.0, 0.9, ("c2",), 0.7),
        ]
        target = {"rec": [(0.0, 3.0)]}
        interviewer = {"rec": []}
        recording_rows, _speaker_rows = build_nemo_scope_rows(
            buffers=buffers,
            target_reference_by_recording=target,
            interviewer_mask_by_recording=interviewer,
        )
        self.assertEqual(recording_rows[0]["raw_nemo_buffer_count"], 3)
        self.assertAlmostEqual(recording_rows[0]["total_buffer_duration_sec"], 2.9)

    def test_cutpoint_must_be_strictly_inside_single_buffer(self) -> None:
        buffers = [NemoScopeBuffer("s01", "rec", "src", "/tmp/a.wav", "buf", 1.0, 3.0, 2.0, ("c0",), 0.9)]
        good = Cutpoint("det", "src", "rec", "orig", "good", 2.0, 1.9, 2.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {})
        assigned = cutpoints_strictly_inside_buffers([good], buffers)
        self.assertEqual(assigned[0].buffer_id, "buf")
        edge = Cutpoint("det", "src", "rec", "orig", "edge", 1.0, 0.9, 1.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {})
        with self.assertRaises(ValueError):
            cutpoints_strictly_inside_buffers([edge], buffers)

    def test_candidate_generation_cannot_cross_buffers(self) -> None:
        constraints = PackingConstraints(
            min_clip_sec=3.0,
            preferred_min_sec=6.0,
            preferred_max_sec=8.0,
            target_clip_sec=8.0,
            max_clip_sec=15.0,
            allow_overlap=False,
            max_overlap_sec=0.0,
            max_duplication_ratio=1.0,
            eligible_regions_by_recording={"rec": ((0.0, 10.0),)},
        )
        cuts = [
            Cutpoint("det", "src", "rec", "buf_a", "a0", 1.0, 0.9, 1.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf_a", "a1", 5.0, 4.9, 5.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf_b", "b0", 5.1, 5.0, 5.2, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf_b", "b1", 9.0, 8.9, 9.1, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
        ]
        candidates = generate_legal_candidate_clips_in_buffers(cutpoints=cuts, constraints=constraints)
        self.assertEqual([(row.buffer_id, row.start_sec, row.end_sec) for row in candidates], [("buf_a", 1.0, 5.0), ("buf_b", 5.1, 9.0)])

    def test_packing_is_independent_per_recording_and_buffer(self) -> None:
        selected = schedule_candidates_by_buffer(
            [
                CandidateClip("det", "src_a", "rec_a", "buf_a", "cand_a", 3.0, 10.0, 7.0, "a0", "a1", 1.0),
                CandidateClip("det", "src_b", "rec_b", "buf_b", "cand_b", 3.0, 10.0, 7.0, "b0", "b1", 1.0),
            ]
        )
        self.assertEqual({row.candidate_id for row in selected}, {"cand_a", "cand_b"})

    def test_packing_is_independent_for_different_buffers_in_same_recording(self) -> None:
        selected = schedule_candidates_by_buffer(
            [
                CandidateClip("det", "src", "rec", "buf_a", "cand_a", 3.0, 10.0, 7.0, "a0", "a1", 1.0),
                CandidateClip("det", "src", "rec", "buf_b", "cand_b", 3.0, 10.0, 7.0, "b0", "b1", 1.0),
            ]
        )
        self.assertEqual({row.candidate_id for row in selected}, {"cand_a", "cand_b"})

    def test_excluded_recording_is_removed_from_nemo_scope(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            base = Path(temp_dir)
            eval_run = base / "eval"
            artifacts = eval_run / "artifacts"
            artifacts.mkdir(parents=True)
            (artifacts / "source_audio_manifest.json").write_text(
                '{\n'
                '  "sources": [\n'
                '    {"source_audio_id": "src_good", "source_recording_id": "rec_good", "path": "/tmp/good.wav", "duration_sec": 20.0, "sample_rate": 16000, "num_samples": 320000},\n'
                '    {"source_audio_id": "src_bad", "source_recording_id": "rec_bad", "path": "/tmp/bad.wav", "duration_sec": 20.0, "sample_rate": 16000, "num_samples": 320000}\n'
                '  ]\n'
                '}\n',
                encoding="utf-8",
            )
            (artifacts / "speaker_regions.jsonl").write_text(
                '\n'.join(
                    [
                        '{"source_audio_id":"src_good","speaker_id":"speaker_0","start_sec":1.0,"end_sec":8.0}',
                        '{"source_audio_id":"src_bad","speaker_id":"speaker_0","start_sec":1.0,"end_sec":8.0}',
                    ]
                ) + '\n',
                encoding="utf-8",
            )
            tables = base / "tables"
            tables.mkdir()
            (tables / "reference_reconciliation.csv").write_text(
                "speaker_id,recording_id,wav_duration_sec,reference_word_count,reference_phone_count,uncertainty_interval_count,uncertain_reference_sec,applied_correction_count,final_word_end_sec,final_phone_end_sec\n"
                "s01,rec_good,20.0,1,1,0,0.0,0,8.0,8.0\n",
                encoding="utf-8",
            )
            (tables / "excluded_recordings.csv").write_text(
                "speaker_id,recording_id,classification,reason\n"
                "s01,rec_bad,CORPUS_ANNOTATION_DEFECT,bad reference\n",
                encoding="utf-8",
            )
            included, excluded = load_recording_eligibility(
                reference_reconciliation_csv=tables / "reference_reconciliation.csv",
                excluded_recordings_csv=tables / "excluded_recordings.csv",
            )
            buffers = build_raw_nemo_target_buffers(
                speaker_id="s01",
                eval_run=eval_run,
                cluster_mapping={
                    ("rec_good", "speaker_0"): {"assigned_role": "target", "mapping_confidence": "0.9"},
                    ("rec_bad", "speaker_0"): {"assigned_role": "target", "mapping_confidence": "0.9"},
                },
                included_recording_ids=included,
                excluded_recording_ids=excluded,
            )
            self.assertEqual([row.recording_id for row in buffers], ["rec_good"])

    def test_boundary_classification_uses_independent_flags(self) -> None:
        buffer = NemoScopeBuffer("s01", "rec", "src", "/tmp/a.wav", "buf", 0.0, 3.0, 3.0, ("c0",), 0.9)
        annotations = {
            "rec": [
                {"recording_id": "rec", "start_sec": 0.0, "end_sec": 1.0, "label": "aa", "annotation_class": "speech"},
                {"recording_id": "rec", "start_sec": 1.0, "end_sec": 1.5, "label": "SIL", "annotation_class": "silence"},
                {"recording_id": "rec", "start_sec": 1.5, "end_sec": 2.0, "label": "LAUGH", "annotation_class": "laughter"},
                {"recording_id": "rec", "start_sec": 2.0, "end_sec": 2.5, "label": "NOISE", "annotation_class": "noise"},
            ]
        }
        interviewer = {"rec": [(2.4, 2.8)]}
        speech_row = classify_boundary(
            speaker_id="s01",
            recording_id="rec",
            buffer=buffer,
            timestamp_sec=0.25,
            annotation_rows_by_recording=annotations,
            interviewer_mask_by_recording=interviewer,
        )
        self.assertTrue(speech_row["inside_target_speech_phone"])
        self.assertEqual(speech_row["speech_phone_label"], "aa")
        silence_row = classify_boundary(
            speaker_id="s01",
            recording_id="rec",
            buffer=buffer,
            timestamp_sec=1.25,
            annotation_rows_by_recording=annotations,
            interviewer_mask_by_recording=interviewer,
        )
        self.assertTrue(silence_row["inside_annotated_silence"])
        self.assertFalse(silence_row["inside_target_speech_phone"])
        interviewer_row = classify_boundary(
            speaker_id="s01",
            recording_id="rec",
            buffer=buffer,
            timestamp_sec=2.45,
            annotation_rows_by_recording=annotations,
            interviewer_mask_by_recording=interviewer,
        )
        self.assertTrue(interviewer_row["inside_interviewer"])
        self.assertTrue(interviewer_row["inside_noise"])

    def test_boundary_summary_excludes_interviewer_from_denominator(self) -> None:
        buffer = NemoScopeBuffer("s01", "rec", "src", "/tmp/a.wav", "buf", 0.0, 3.0, 3.0, ("c0",), 0.9)
        cutpoints = [
            Cutpoint("det", "src", "rec", "buf", "speech", 0.25, 0.2, 0.3, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
            Cutpoint("det", "src", "rec", "buf", "interviewer", 2.45, 2.4, 2.5, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
        ]
        annotations = {"rec": [{"recording_id": "rec", "start_sec": 0.0, "end_sec": 1.0, "label": "aa", "annotation_class": "speech"}]}
        interviewer = {"rec": [(2.4, 2.8)]}
        rows = build_boundary_classification_rows(
            detector_name="det",
            boundary_source="detector",
            selected_cutpoints=cutpoints,
            buffers=[buffer],
            annotation_rows_by_recording=annotations,
            interviewer_mask_by_recording=interviewer,
        )
        summary = summarize_boundary_severity_by_speaker(rows)[0]
        self.assertEqual(summary["selected_boundary_count"], 1)
        self.assertEqual(summary["inside_interviewer_count_excluded_from_denominator"], 1)
        self.assertEqual(summary["inside_target_speech_phone_count"], 1)
        self.assertAlmostEqual(summary["inside_target_speech_phone_rate"], 1.0)

    def test_boundary_summary_separates_unique_cutpoints_from_final_edges(self) -> None:
        rows = [
            {
                "speaker_id": "s01",
                "detector_name": "det",
                "boundary_source": "detector_selected_cutpoint",
                "cutpoint_id": "c1",
                "inside_interviewer": False,
                "inside_target_speech_phone": True,
                "inside_annotated_silence": False,
                "inside_laughter": False,
                "inside_vocnoise": False,
                "inside_noise": False,
                "inside_boundary_marker": False,
                "inside_other_annotation": False,
                "outside_all_annotations": False,
                "speech_phone_leak_depth_sec": 0.03,
                "gt_20ms": True,
                "gt_50ms": False,
                "gt_100ms": False,
                "gt_25pct_phone": False,
                "gt_50pct_phone": False,
            },
            {
                "speaker_id": "s01",
                "detector_name": "det",
                "boundary_source": "final_clip_start",
                "cutpoint_id": "c1",
                "inside_interviewer": False,
                "inside_target_speech_phone": True,
                "inside_annotated_silence": False,
                "inside_laughter": False,
                "inside_vocnoise": False,
                "inside_noise": False,
                "inside_boundary_marker": False,
                "inside_other_annotation": False,
                "outside_all_annotations": False,
                "speech_phone_leak_depth_sec": 0.03,
                "gt_20ms": True,
                "gt_50ms": False,
                "gt_100ms": False,
                "gt_25pct_phone": False,
                "gt_50pct_phone": False,
            },
            {
                "speaker_id": "s01",
                "detector_name": "det",
                "boundary_source": "final_clip_end",
                "cutpoint_id": "c1",
                "inside_interviewer": False,
                "inside_target_speech_phone": True,
                "inside_annotated_silence": False,
                "inside_laughter": False,
                "inside_vocnoise": False,
                "inside_noise": False,
                "inside_boundary_marker": False,
                "inside_other_annotation": False,
                "outside_all_annotations": False,
                "speech_phone_leak_depth_sec": 0.03,
                "gt_20ms": True,
                "gt_50ms": False,
                "gt_100ms": False,
                "gt_25pct_phone": False,
                "gt_50pct_phone": False,
            },
        ]
        grouped = summarize_boundary_severity_by_speaker_and_source(rows)
        self.assertEqual(grouped["unique_selected_cutpoints"][0]["selected_boundary_count"], 1)
        self.assertEqual(grouped["final_edge_occurrences"][0]["selected_boundary_count"], 2)

    def test_coverage_metrics_use_union_and_density(self) -> None:
        buffers = [
            NemoScopeBuffer("s01", "rec", "src", "/tmp/a.wav", "buf0", 0.0, 4.0, 4.0, ("c0",), 0.9),
            NemoScopeBuffer("s01", "rec", "src", "/tmp/a.wav", "buf1", 5.0, 9.0, 4.0, ("c1",), 0.9),
        ]
        clips = [
            Clip("det", "packer", "src", "rec", "buf0", "clip0", 0.5, 3.5, 3.0, "a", "b", 1.0, 2),
            Clip("det", "packer", "src", "rec", "buf1", "clip1", 5.5, 8.5, 3.0, "c", "d", 1.0, 2),
        ]
        target_in_scope = {"rec": [(0.0, 2.0), (6.0, 7.0)]}
        all_target = {"rec": [(0.0, 2.0), (3.5, 4.5), (6.0, 7.0)]}
        metrics = compute_clip_coverage_metrics(
            clips=clips,
            buffers=buffers,
            target_reference_by_recording=target_in_scope,
            all_target_reference_by_recording=all_target,
        )
        self.assertAlmostEqual(metrics["conditional_target_phone_coverage"], 2.5 / 3.0, places=6)
        self.assertAlmostEqual(metrics["end_to_end_target_phone_coverage"], 2.5 / 4.0, places=6)
        self.assertAlmostEqual(metrics["pooled_target_speech_density"], 2.5 / 6.0, places=6)
        self.assertAlmostEqual(metrics["target_speech_stranded_in_unusable_nemo_buffers_sec"], 0.5, places=6)

    def test_boundary_inside_uncertainty_is_excluded_from_severity(self) -> None:
        buffer = NemoScopeBuffer("s01", "rec", "src", "/tmp/a.wav", "buf0", 0.0, 4.0, 4.0, ("c0",), 0.9)
        annotations = {
            "rec": [
                {"recording_id": "rec", "start_sec": 0.0, "end_sec": 1.0, "label": "aa", "annotation_class": "speech"},
            ]
        }
        row = classify_boundary(
            speaker_id="s01",
            recording_id="rec",
            buffer=buffer,
            timestamp_sec=0.5,
            annotation_rows_by_recording=annotations,
            interviewer_mask_by_recording={"rec": []},
            uncertainty_mask_by_recording={"rec": [(0.4, 0.6)]},
        )
        self.assertTrue(row["inside_uncertainty"])
        summary = summarize_boundary_severity_by_speaker(
            [{**row, "detector_name": "det", "boundary_source": "detector_selected_cutpoint", "cutpoint_id": "c0", "clip_id": ""}]
        )
        self.assertEqual(summary[0]["selected_boundary_count"], 0)

    def test_write_repaired_scope_validation_emits_expected_files(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            normalized = root / "normalized" / "s01"
            normalized.mkdir(parents=True)
            (normalized / "reference_words.csv").write_text(
                "speaker_id,recording_id,audio_path,annotation_path,row_index,raw_label,normalized_label,start_sec,end_sec,duration_sec,pos_tag,is_lexical_word,is_event,event_type\n"
                "s01,rec,/tmp/a.wav,/tmp/a.words,0,<IVER>,<IVER>,2.0,3.0,1.0,NULL,False,True,interviewer\n",
                encoding="utf-8",
            )
            (normalized / "reference_phones.csv").write_text(
                "speaker_id,recording_id,audio_path,annotation_path,row_index,raw_label,base_label,annotation_suffix,normalized_label,phone_class,start_sec,end_sec,duration_sec,is_speech_phone,is_silence_or_event\n"
                "s01,rec,/tmp/a.wav,/tmp/a.phones,0,aa,aa,,aa,speech,0.0,2.0,2.0,True,False\n"
                "s01,rec,/tmp/a.wav,/tmp/a.phones,1,IVER,IVER,,IVER,interviewer,2.0,3.0,1.0,False,True\n",
                encoding="utf-8",
            )
            for name in (
                "phone_label_inventory.csv",
                "word_annotation_inventory.csv",
                "unknown_labels.csv",
                "malformed_rows.csv",
                "annotation_coverage_by_recording.csv",
                "BUCKEYE_INGEST_VALIDATION.md",
            ):
                (normalized / name).write_text("stub\n", encoding="utf-8")
            (normalized / "uncertainty_masks.csv").write_text(
                "speaker_id,recording_id,table,row_index,raw_label,start_sec,end_sec,duration_sec,reason\n",
                encoding="utf-8",
            )
            (normalized / "correction_manifest.csv").write_text(
                "speaker_id,recording_id,table,row_index,raw_value,corrected_value,reason,source_evidence\n",
                encoding="utf-8",
            )
            (normalized / "excluded_recordings.csv").write_text(
                "speaker_id,recording_id,classification,reason\n",
                encoding="utf-8",
            )
            (normalized / "reference_reconciliation.csv").write_text(
                "speaker_id,recording_id,wav_duration_sec,reference_word_count,reference_phone_count,uncertainty_interval_count,uncertain_reference_sec,applied_correction_count,final_word_end_sec,final_phone_end_sec\n"
                "s01,rec,3.0,1,2,0,0.0,0,3.0,3.0\n",
                encoding="utf-8",
            )
            eval_run = root / "eval_run" / "speechcraft_run" / "artifacts"
            eval_run.mkdir(parents=True)
            (eval_run / "source_audio_manifest.json").write_text(
                '{"sources":[{"source_audio_id":"src","source_recording_id":"rec","path":"/tmp/a.wav"}]}\n',
                encoding="utf-8",
            )
            (eval_run / "speaker_regions.jsonl").write_text(
                '{"source_audio_id":"src","speaker_id":"speaker_0","start_sec":0.0,"end_sec":1.0}\n'
                '{"source_audio_id":"src","speaker_id":"speaker_0","start_sec":1.0,"end_sec":2.0}\n'
                '{"source_audio_id":"src","speaker_id":"speaker_1","start_sec":2.0,"end_sec":3.0}\n',
                encoding="utf-8",
            )
            mapping_csv = root / "mapping.csv"
            mapping_csv.write_text(
                "dataset_id,recording_id,nemo_cluster,assigned_role,mapping_confidence\n"
                "s01,rec,speaker_0,target,0.91\n"
                "s01,rec,speaker_1,interviewer,0.83\n",
                encoding="utf-8",
            )
            out_dir = write_repaired_scope_validation(
                speaker_id="s01",
                eval_run=root / "eval_run",
                normalized_speaker_dir=normalized,
                cluster_mapping_csv=mapping_csv,
                out_dir=root / "out",
            )
            self.assertTrue((out_dir / "nemo_target_buffers.csv").exists())
            self.assertTrue((out_dir / "nemo_scope_by_recording.csv").exists())
            self.assertTrue((out_dir / "nemo_scope_by_speaker.csv").exists())
            self.assertTrue((out_dir / "parser_artifact_manifest.csv").exists())
            report = (out_dir / "REPAIRED_SCOPE_VALIDATION.md").read_text(encoding="utf-8")
            self.assertIn("target recall", report)
            self.assertIn("interviewer overlap", report)

    def test_require_parser_artifacts_fails_when_inventory_missing(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            normalized = Path(temp_dir) / "normalized" / "s01"
            normalized.mkdir(parents=True)
            (normalized / "reference_words.csv").write_text("x\n", encoding="utf-8")
            (normalized / "reference_phones.csv").write_text("x\n", encoding="utf-8")
            with self.assertRaises(ValueError):
                require_parser_artifacts(normalized)

    def test_repaired_dry_run_writes_selected_clips_from_legal_cutpoints(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            normalized = root / "normalized" / "s01"
            normalized.mkdir(parents=True)
            (normalized / "reference_words.csv").write_text(
                (
                    "speaker_id,recording_id,audio_path,annotation_path,row_index,raw_label,normalized_label,start_sec,end_sec,duration_sec,pos_tag,is_lexical_word,is_event,event_type\n"
                    "s01,rec,/tmp/a.wav,/tmp/a.words,0,hello,hello,0.0,1.0,1.0,NN,True,False,\n"
                    "s01,rec,/tmp/a.wav,/tmp/a.words,1,there,there,4.0,5.0,1.0,NN,True,False,\n"
                ),
                encoding="utf-8",
            )
            (normalized / "reference_phones.csv").write_text(
                "speaker_id,recording_id,audio_path,annotation_path,row_index,raw_label,base_label,annotation_suffix,normalized_label,phone_class,start_sec,end_sec,duration_sec,is_speech_phone,is_silence_or_event\n"
                "s01,rec,/tmp/a.wav,/tmp/a.phones,0,aa,aa,,aa,speech,0.0,0.5,0.5,True,False\n"
                "s01,rec,/tmp/a.wav,/tmp/a.phones,1,SIL,SIL,,SIL,silence,0.5,4.5,4.0,False,True\n"
                "s01,rec,/tmp/a.wav,/tmp/a.phones,2,ae,ae,,ae,speech,4.5,5.0,0.5,True,False\n",
                encoding="utf-8",
            )
            for name, text in (
                ("phone_label_inventory.csv", "speaker_id,raw_label,base_label,annotation_suffix,phone_class,count\ns01,aa,aa,,speech,1\n"),
                ("word_annotation_inventory.csv", "speaker_id,raw_label,normalized_label,word_class,count\ns01,hello,hello,lexical_word,1\n"),
                ("unknown_labels.csv", "speaker_id,recording_id,table,row_index,raw_label\n"),
                ("malformed_rows.csv", "speaker_id,recording_id,annotation_path,table,row_index,raw_label,end_sec,issue_type\n"),
                ("annotation_coverage_by_recording.csv", "speaker_id,recording_id,wav_duration_sec,phone_timeline_end_sec,word_timeline_end_sec,phone_coverage_ratio,word_coverage_ratio,phone_gap_count_gt_10ms,largest_phone_gap_sec,phone_overlap_count_gt_1ms,word_gap_count_gt_10ms,largest_word_gap_sec,word_overlap_count_gt_1ms\ns01,rec,5.0,5.0,5.0,1.0,1.0,0,0,0,1,3.0,0\n"),
                ("uncertainty_masks.csv", "speaker_id,recording_id,table,row_index,raw_label,start_sec,end_sec,duration_sec,reason\n"),
                ("correction_manifest.csv", "speaker_id,recording_id,table,row_index,raw_value,corrected_value,reason,source_evidence\n"),
                ("excluded_recordings.csv", "speaker_id,recording_id,classification,reason\n"),
                ("reference_reconciliation.csv", "speaker_id,recording_id,wav_duration_sec,reference_word_count,reference_phone_count,uncertainty_interval_count,uncertain_reference_sec,applied_correction_count,final_word_end_sec,final_phone_end_sec\ns01,rec,5.0,2,3,0,0.0,0,5.0,5.0\n"),
                ("BUCKEYE_INGEST_VALIDATION.md", "# validation\n"),
            ):
                (normalized / name).write_text(text, encoding="utf-8")
            eval_run = root / "eval_run" / "artifacts"
            eval_run.mkdir(parents=True)
            (eval_run / "source_audio_manifest.json").write_text(
                '{"sources":[{"source_audio_id":"src","source_recording_id":"rec","path":"/tmp/a.wav","duration_sec":5.0,"sample_rate":16000,"num_samples":80000}]}\n',
                encoding="utf-8",
            )
            (eval_run / "speaker_regions.jsonl").write_text(
                '{"source_audio_id":"src","speaker_id":"speaker_0","start_sec":0.0,"end_sec":5.0}\n',
                encoding="utf-8",
            )
            mapping_csv = root / "mapping.csv"
            mapping_csv.write_text(
                "dataset_id,recording_id,nemo_cluster,assigned_role,mapping_confidence\n"
                "s01,rec,speaker_0,target,0.91\n",
                encoding="utf-8",
            )

            class _FakeDetector:
                name = "legacy_vad_rms"

                def find_cutpoints(self, contexts: object) -> DetectorRunResult:
                    return DetectorRunResult(
                        cutpoints=[
                            Cutpoint(self.name, "src", "rec", "unknown", "c1", 0.25, 0.2, 0.3, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
                            Cutpoint(self.name, "src", "rec", "unknown", "c2", 4.75, 4.7, 4.8, 1.0, None, None, None, None, None, None, None, None, 0.0, False, {}),
                        ],
                        compute_metric=type("Metric", (), {"detector_name": self.name})(),  # unused in dry run
                        searched_buffer_ids=frozenset({"buf"}),
                        searched_duration_sec=5.0,
                        searched_interval_count=1,
                        uses_asr=False,
                        uses_mfa=False,
                        uses_aligned_words=False,
                        uses_alignment_qc=False,
                        validity_notes="",
                    )

            with patch("speaker_ts_eval.repaired_buckeye_benchmark.supported_repaired_detectors", return_value={"legacy_vad_rms": _FakeDetector()}):
                with patch("speaker_ts_eval.repaired_buckeye_benchmark._load_or_reuse_vad_frame_indices", return_value={"rec": {"frames": [], "centers": [], "mode": "mock"}}):
                    with patch("speaker_ts_eval.repaired_buckeye_benchmark._build_audio_feature_cache_stdlib", return_value={"rec": {"frames": [], "centers": []}}):
                        out_dir = run_repaired_slicer_dry_run(
                            eval_run=root / "eval_run",
                            normalized_speaker_dir=normalized,
                            cluster_mapping_csv=mapping_csv,
                            out_root=root / "out",
                            detector_name="legacy_vad_rms",
                            write_heavy_tables=False,
                        )
            self.assertFalse((out_dir / "tables" / "all_cutpoints.csv").exists())
            self.assertFalse((out_dir / "tables" / "all_candidates.csv").exists())
            self.assertFalse((out_dir / "tables" / "selected_boundaries.csv").exists())
            self.assertTrue((out_dir / "tables" / "boundary_severity_unique_cutpoints.csv").exists())
            self.assertTrue((out_dir / "tables" / "boundary_severity_final_edge_occurrences.csv").exists())
            self.assertTrue((out_dir / "tables" / "candidate_support_by_recording.csv").exists())
            self.assertTrue((out_dir / "tables" / "emitted_clips.csv").exists())
            clips_csv = (out_dir / "tables" / "emitted_clips.csv").read_text(encoding="utf-8")
            self.assertIn("0.25", clips_csv)
            self.assertIn("4.75", clips_csv)
            invariants = (out_dir / "tables" / "invariant_report.csv").read_text(encoding="utf-8")
            self.assertIn("clips_using_nemo_edges,0", invariants)
            self.assertIn("candidate_group_count,1", invariants)
            self.assertIn("selected_group_count,1", invariants)

    def test_supported_repaired_detectors_contains_expanded_field(self) -> None:
        supported = supported_repaired_detectors()
        expected = {
            "vad_only",
            "rms_only",
            "percentile_rms_only",
            "local_prominence_rms_only",
            "legacy_vad_rms",
            "vad_percentile_rms",
            "vad_local_prominence_rms",
            "rms_vad_veto",
            "vad_or_percentile_rms",
            "vad_or_local_prominence_rms",
            "vad_or_adaptive_rms",
            "vad_and_percentile_rms",
            "vad_and_local_prominence_rms",
            "all_local_rms_minima",
            "uniform_grid_250ms",
            "uniform_grid_500ms",
        }
        self.assertTrue(expected.issubset(set(supported)))
        self.assertEqual(default_repaired_matrix_detector_names()[0], "production_safecut_optimal")

    def test_repaired_matrix_requires_unique_speaker_ids(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            fixture = RepairedMatrixFixture(
                speaker_id="s01",
                eval_run=root / "eval_run",
                normalized_speaker_dir=root / "normalized" / "s01",
            )
            with self.assertRaises(ValueError):
                run_repaired_detector_matrix(
                    fixtures=[fixture, fixture],
                    cluster_mapping_csv=root / "mapping.csv",
                    out_root=root / "out",
                    detector_names=["uniform_grid_250ms"],
                )


if __name__ == "__main__":
    unittest.main()
