from __future__ import annotations

import json
import tempfile
import unittest
import wave
from pathlib import Path

from speaker_ts_eval.buckeye_nemo_batch import (
    _compute_mapping_for_recording,
    _discover_raw_recordings,
    _load_reference_availability,
    _load_rttm_labels,
)


def _write_wav(path: Path, *, sample_rate: int = 16000, duration_sec: float = 2.0) -> None:
    frames = int(sample_rate * duration_sec)
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), "wb") as handle:
        handle.setnchannels(1)
        handle.setsampwidth(2)
        handle.setframerate(sample_rate)
        handle.writeframes(b"\x00\x00" * frames)


class BuckeyeNemoBatchTests(unittest.TestCase):
    def test_load_rttm_labels_maps_window_ids_back_to_source_recording(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            base = Path(temp_dir)
            run_root = base / "run"
            (run_root / "artifacts" / "diarization" / "source_audio_0000" / "window_000" / "pred_rttms").mkdir(parents=True)
            (run_root / "artifacts" / "source_audio_manifest.json").write_text(
                json.dumps(
                    {
                        "sources": [
                            {
                                "source_audio_id": "source_audio_0000",
                                "source_recording_id": "rec1",
                                "path": str(base / "rec1.wav"),
                            }
                        ]
                    }
                ),
                encoding="utf-8",
            )
            (
                run_root
                / "artifacts"
                / "diarization"
                / "source_audio_0000"
                / "window_000"
                / "pred_rttms"
                / "source_audio_0000_window_000.rttm"
            ).write_text(
                "SPEAKER source_audio_0000_window_000 1 0.000 1.000 <NA> <NA> speaker_0 <NA> <NA>\n"
                "SPEAKER source_audio_0000_window_000 1 1.000 1.000 <NA> <NA> speaker_1 <NA> <NA>\n",
                encoding="utf-8",
            )
            labels = _load_rttm_labels(run_root)
            self.assertEqual(labels, {"rec1": {"speaker_0", "speaker_1"}})

    def test_load_reference_availability_marks_included_excluded_and_missing(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            base = Path(temp_dir)
            raw_root = base / "raw"
            normalized_root = base / "normalized"
            for rec in ("rec1", "rec2", "rec3"):
                wav_path = raw_root / "s99" / rec / f"{rec}.wav"
                _write_wav(wav_path)
                (wav_path.parent / f"{rec}.words").write_text("#\n", encoding="utf-8")
                (wav_path.parent / f"{rec}.phones").write_text("#\n", encoding="utf-8")
            speaker_dir = normalized_root / "s99"
            speaker_dir.mkdir(parents=True)
            (speaker_dir / "reference_reconciliation.csv").write_text(
                "speaker_id,recording_id\n"
                "s99,rec1\n",
                encoding="utf-8",
            )
            (speaker_dir / "excluded_recordings.csv").write_text(
                "speaker_id,recording_id,classification,reason\n"
                "s99,rec2,excluded,bad_reference\n",
                encoding="utf-8",
            )
            discovered = _discover_raw_recordings(raw_root)
            rows, index = _load_reference_availability(normalized_root, discovered)
            self.assertEqual(len(rows), 3)
            self.assertTrue(index[("s99", "rec1")]["reference_eligible"])
            self.assertFalse(index[("s99", "rec2")]["reference_eligible"])
            self.assertEqual(index[("s99", "rec3")]["reference_reason"], "no_normalized_reference")

    def test_compute_mapping_for_recording_auto_accept_single(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            base = Path(temp_dir)
            normalized_root = base / "normalized"
            speaker_dir = normalized_root / "s99"
            speaker_dir.mkdir(parents=True)
            wav = base / "raw" / "s99" / "rec1" / "rec1.wav"
            words = wav.parent / "rec1.words"
            phones = wav.parent / "rec1.phones"
            _write_wav(wav, duration_sec=10.0)
            words.write_text("#\n", encoding="utf-8")
            phones.write_text("#\n", encoding="utf-8")
            (speaker_dir / "reference_words.csv").write_text(
                f"speaker_id,recording_id,audio_path,annotation_path,row_index,raw_label,normalized_label,start_sec,end_sec,duration_sec,original_end_sec,correction_reason,pos_tag,is_lexical_word,is_event,event_type\n"
                f"s99,rec1,{wav},{words},0,<IVER>,<IVER>,8.0,10.0,2.0,10.0,,NULL,False,True,interviewer\n",
                encoding="utf-8",
            )
            (speaker_dir / "reference_phones.csv").write_text(
                f"speaker_id,recording_id,audio_path,annotation_path,row_index,raw_label,base_label,annotation_suffix,stress_or_variant_marker,normalized_label,phone_class,start_sec,end_sec,duration_sec,original_end_sec,correction_reason,is_speech_phone,is_silence_or_event\n"
                f"s99,rec1,{wav},{phones},0,aa,aa,,,aa,speech,0.0,8.0,8.0,8.0,,True,False\n"
                f"s99,rec1,{wav},{phones},1,IVER,IVER,,,IVER,interviewer,8.0,10.0,2.0,10.0,,False,True\n",
                encoding="utf-8",
            )
            (speaker_dir / "uncertainty_masks.csv").write_text(
                "speaker_id,recording_id,table,row_index,raw_label,start_sec,end_sec,duration_sec,reason\n",
                encoding="utf-8",
            )
            run_root = base / "run"
            (run_root / "artifacts").mkdir(parents=True)
            (run_root / "artifacts" / "source_audio_manifest.json").write_text(
                json.dumps({"sources": [{"source_audio_id": "src1", "source_recording_id": "rec1", "path": str(wav)}]}),
                encoding="utf-8",
            )
            (run_root / "artifacts" / "speaker_regions.jsonl").write_text(
                json.dumps({"source_audio_id": "src1", "speaker_id": "speaker_0", "start_sec": 0.0, "end_sec": 8.0}) + "\n"
                + json.dumps({"source_audio_id": "src1", "speaker_id": "speaker_1", "start_sec": 8.0, "end_sec": 10.0}) + "\n",
                encoding="utf-8",
            )
            (run_root / "artifacts" / "diarization").mkdir(parents=True)
            rttm = run_root / "artifacts" / "diarization" / "rec1.rttm"
            rttm.write_text(
                "SPEAKER src1 1 0.000 8.000 <NA> <NA> speaker_0 <NA> <NA>\n"
                "SPEAKER src1 1 8.000 2.000 <NA> <NA> speaker_1 <NA> <NA>\n",
                encoding="utf-8",
            )
            cluster_rows, candidate_rows, decision = _compute_mapping_for_recording(
                speaker_id="s99",
                recording_id="rec1",
                run_root=run_root,
                normalized_root=normalized_root,
            )
            self.assertEqual(decision["mapping_status"], "AUTO_ACCEPT_SINGLE")
            self.assertEqual(decision["best_single_cluster_id"], "speaker_0")
            self.assertEqual(len(cluster_rows), 2)
            self.assertGreaterEqual(float(decision["best_single_target_recall"]), 0.95)

    def test_compute_mapping_for_recording_auto_accept_multi_chooses_smallest_qualifying_set(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            base = Path(temp_dir)
            normalized_root = base / "normalized"
            speaker_dir = normalized_root / "s99"
            speaker_dir.mkdir(parents=True)
            wav = base / "raw" / "s99" / "rec1" / "rec1.wav"
            words = wav.parent / "rec1.words"
            phones = wav.parent / "rec1.phones"
            _write_wav(wav, duration_sec=11.0)
            words.write_text("#\n", encoding="utf-8")
            phones.write_text("#\n", encoding="utf-8")
            (speaker_dir / "reference_words.csv").write_text(
                "speaker_id,recording_id,audio_path,annotation_path,row_index,raw_label,normalized_label,start_sec,end_sec,duration_sec,original_end_sec,correction_reason,pos_tag,is_lexical_word,is_event,event_type\n",
                encoding="utf-8",
            )
            (speaker_dir / "reference_phones.csv").write_text(
                f"speaker_id,recording_id,audio_path,annotation_path,row_index,raw_label,base_label,annotation_suffix,stress_or_variant_marker,normalized_label,phone_class,start_sec,end_sec,duration_sec,original_end_sec,correction_reason,is_speech_phone,is_silence_or_event\n"
                f"s99,rec1,{wav},{phones},0,aa,aa,,,aa,speech,0.0,10.0,10.0,10.0,,True,False\n",
                encoding="utf-8",
            )
            (speaker_dir / "uncertainty_masks.csv").write_text(
                "speaker_id,recording_id,table,row_index,raw_label,start_sec,end_sec,duration_sec,reason\n",
                encoding="utf-8",
            )
            run_root = base / "run"
            (run_root / "artifacts").mkdir(parents=True)
            (run_root / "artifacts" / "source_audio_manifest.json").write_text(
                json.dumps({"sources": [{"source_audio_id": "src1", "source_recording_id": "rec1", "path": str(wav)}]}),
                encoding="utf-8",
            )
            (run_root / "artifacts" / "speaker_regions.jsonl").write_text(
                json.dumps({"source_audio_id": "src1", "speaker_id": "speaker_0", "start_sec": 0.0, "end_sec": 9.1}) + "\n"
                + json.dumps({"source_audio_id": "src1", "speaker_id": "speaker_1", "start_sec": 9.1, "end_sec": 9.8}) + "\n"
                + json.dumps({"source_audio_id": "src1", "speaker_id": "speaker_2", "start_sec": 9.8, "end_sec": 9.99}) + "\n",
                encoding="utf-8",
            )
            (run_root / "artifacts" / "diarization").mkdir(parents=True)
            (run_root / "artifacts" / "diarization" / "rec1.rttm").write_text(
                "SPEAKER src1 1 0.000 9.100 <NA> <NA> speaker_0 <NA> <NA>\n"
                "SPEAKER src1 1 9.100 0.700 <NA> <NA> speaker_1 <NA> <NA>\n"
                "SPEAKER src1 1 9.800 0.190 <NA> <NA> speaker_2 <NA> <NA>\n",
                encoding="utf-8",
            )
            cluster_rows, candidate_rows, decision = _compute_mapping_for_recording(
                speaker_id="s99",
                recording_id="rec1",
                run_root=run_root,
                normalized_root=normalized_root,
            )
            self.assertEqual(decision["mapping_status"], "AUTO_ACCEPT_MULTI")
            self.assertEqual(decision["selected_cluster_ids"], "speaker_0|speaker_1")
            self.assertEqual(decision["best_multi_cluster_ids"], "speaker_0|speaker_1")
            self.assertEqual(len(cluster_rows), 3)
            self.assertEqual(len(candidate_rows), 3)
