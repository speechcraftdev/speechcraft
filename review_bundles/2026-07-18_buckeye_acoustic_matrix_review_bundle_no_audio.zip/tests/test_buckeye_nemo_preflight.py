from __future__ import annotations

import csv
import tempfile
import unittest
import wave
import json
from pathlib import Path

from speaker_ts_eval.buckeye_nemo_preflight import (
    build_included_recording_manifest,
    build_mapping_diagnostics,
)


def _write_wav(path: Path, *, sample_rate: int = 16000, duration_sec: float = 1.0) -> None:
    frames = int(sample_rate * duration_sec)
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), "wb") as handle:
        handle.setnchannels(1)
        handle.setsampwidth(2)
        handle.setframerate(sample_rate)
        handle.writeframes(b"\x00\x00" * frames)


class BuckeyeNemoPreflightTests(unittest.TestCase):
    def test_build_included_recording_manifest_uses_reconciliation_and_exclusions(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            base = Path(temp_dir)
            speaker_dir = base / "normalized" / "s99"
            speaker_dir.mkdir(parents=True)
            wav = base / "raw" / "s99" / "rec1" / "rec1.wav"
            word_path = base / "raw" / "s99" / "rec1" / "rec1.words"
            phone_path = base / "raw" / "s99" / "rec1" / "rec1.phones"
            _write_wav(wav, duration_sec=2.0)
            word_path.write_text("#\n", encoding="utf-8")
            phone_path.write_text("#\n", encoding="utf-8")
            (speaker_dir / "reference_reconciliation.csv").write_text(
                "speaker_id,recording_id,wav_duration_sec,reference_word_count,reference_phone_count,uncertainty_interval_count,uncertain_reference_sec,applied_correction_count,final_word_end_sec,final_phone_end_sec\n"
                "s99,rec1,2.0,1,1,0,0.0,0,2.0,2.0\n",
                encoding="utf-8",
            )
            (speaker_dir / "excluded_recordings.csv").write_text(
                "speaker_id,recording_id,classification,reason\n",
                encoding="utf-8",
            )
            (speaker_dir / "uncertainty_masks.csv").write_text(
                "speaker_id,recording_id,table,row_index,raw_label,start_sec,end_sec,duration_sec,reason\n",
                encoding="utf-8",
            )
            (speaker_dir / "reference_words.csv").write_text(
                f"speaker_id,recording_id,audio_path,annotation_path,row_index,raw_label,normalized_label,start_sec,end_sec,duration_sec,original_end_sec,correction_reason,pos_tag,is_lexical_word,is_event,event_type\n"
                f"s99,rec1,{wav},{word_path},0,<IVER>,<IVER>,1.0,2.0,1.0,2.0,,NULL,False,True,interviewer\n",
                encoding="utf-8",
            )
            (speaker_dir / "reference_phones.csv").write_text(
                f"speaker_id,recording_id,audio_path,annotation_path,row_index,raw_label,base_label,annotation_suffix,stress_or_variant_marker,normalized_label,phone_class,start_sec,end_sec,duration_sec,original_end_sec,correction_reason,is_speech_phone,is_silence_or_event\n"
                f"s99,rec1,{wav},{phone_path},0,aa,aa,,,aa,speech,0.0,1.0,1.0,1.0,,True,False\n"
                f"s99,rec1,{wav},{phone_path},1,IVER,IVER,,,IVER,interviewer,1.0,2.0,1.0,2.0,,False,True\n",
                encoding="utf-8",
            )
            rows = build_included_recording_manifest(normalized_root=base / "normalized", speaker_ids=["s99"])
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["recording_id"], "rec1")
            self.assertEqual(rows[0]["reference_target_speech_sec"], 1.0)
            self.assertEqual(rows[0]["reference_interviewer_sec"], 1.0)

    def test_build_mapping_diagnostics_flags_ambiguous_recording(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            base = Path(temp_dir)
            normalized_root = base / "normalized"
            speaker_dir = normalized_root / "s99"
            speaker_dir.mkdir(parents=True)
            wav = base / "raw" / "s99" / "rec1" / "rec1.wav"
            word_path = base / "raw" / "s99" / "rec1" / "rec1.words"
            phone_path = base / "raw" / "s99" / "rec1" / "rec1.phones"
            _write_wav(wav, duration_sec=20.0)
            word_path.write_text("#\n", encoding="utf-8")
            phone_path.write_text("#\n", encoding="utf-8")
            (speaker_dir / "reference_words.csv").write_text(
                f"speaker_id,recording_id,audio_path,annotation_path,row_index,raw_label,normalized_label,start_sec,end_sec,duration_sec,original_end_sec,correction_reason,pos_tag,is_lexical_word,is_event,event_type\n"
                f"s99,rec1,{wav},{word_path},0,<IVER>,<IVER>,15.0,20.0,5.0,20.0,,NULL,False,True,interviewer\n",
                encoding="utf-8",
            )
            (speaker_dir / "reference_phones.csv").write_text(
                f"speaker_id,recording_id,audio_path,annotation_path,row_index,raw_label,base_label,annotation_suffix,stress_or_variant_marker,normalized_label,phone_class,start_sec,end_sec,duration_sec,original_end_sec,correction_reason,is_speech_phone,is_silence_or_event\n"
                f"s99,rec1,{wav},{phone_path},0,aa,aa,,,aa,speech,0.0,10.0,10.0,10.0,,True,False\n"
                f"s99,rec1,{wav},{phone_path},1,ae,ae,,,ae,speech,10.0,15.0,5.0,15.0,,True,False\n"
                f"s99,rec1,{wav},{phone_path},2,IVER,IVER,,,IVER,interviewer,15.0,20.0,5.0,20.0,,False,True\n",
                encoding="utf-8",
            )
            run_root = base / "run"
            (run_root / "artifacts").mkdir(parents=True)
            (run_root / "artifacts" / "source_audio_manifest.json").write_text(
                json.dumps({"sources": [{"source_audio_id": "src1", "source_recording_id": "rec1", "path": str(wav)}]}) + "\n",
                encoding="utf-8",
            )
            (run_root / "artifacts" / "speaker_regions.jsonl").write_text(
                "\n".join([
                    '{"source_audio_id":"src1","speaker_id":"speaker_0","start_sec":0.0,"end_sec":8.0}',
                    '{"source_audio_id":"src1","speaker_id":"speaker_1","start_sec":8.0,"end_sec":14.0}',
                ]) + "\n",
                encoding="utf-8",
            )
            result = build_mapping_diagnostics(
                speaker_id="s99",
                run_root=run_root,
                normalized_root=normalized_root,
                out_dir=base / "out",
            )
            self.assertEqual(len(result["recording_rows"]), 1)
            self.assertTrue(result["recording_rows"][0]["ambiguous_mapping"])
            with (base / "out" / "benchmark_cluster_mapping.csv").open() as handle:
                mapping_rows = list(csv.DictReader(handle))
            self.assertEqual(len(mapping_rows), 2)
            self.assertEqual(mapping_rows[0]["dataset_id"], "s99")
            self.assertIn(mapping_rows[0]["assigned_role"], {"target", "interviewer", "other"})
