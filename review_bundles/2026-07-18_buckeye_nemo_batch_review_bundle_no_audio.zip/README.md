NeMo Buckeye batch review bundle

Run root:
/home/aaravthegreat/Datasets/buckeye/eval_runs/2026-07-18_buckeye_nemo_batch_v1

Summary:
- speakers discovered: 24
- recordings discovered: 163
- NeMo successes: 163
- NeMo failures: 0
- AUTO_ACCEPT_SINGLE: 117
- AUTO_ACCEPT_MULTI: 3
- REVIEW_REQUIRED: 39
- NO_VALID_REFERENCE: 4

Notes:
- no audio included
- no model files included
- no per-recording code snapshots included
- raw NeMo outputs remain in the run root and were not copied into this bundle
